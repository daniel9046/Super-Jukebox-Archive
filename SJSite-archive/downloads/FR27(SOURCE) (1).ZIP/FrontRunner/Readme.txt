                             FrontRunner 2.7
                             by Marius Fodor
                          (marius.fodor@usa.net)

Introduction
------------

    After trying out some other front ends for DOS, I found out that most
were either unnecessarily too hard to configure, or just didn't look very 
plesant. So I decided to make my own, the design concept was to be as easy 
to setup as possible and to look visualy pleasing. I hope you find it meets 
those goals.

    I just recently learned to program for Windows and decided as my first
project to port FrontRunner. The program is pretty much like any other Windows 
program, except that you still have to specify the filename on the command line.

History
-------

v1.0 (6/20/98) 
- First Public Release

v1.1 (6/25/98) 
- Using VSync before screen redraw, for flicker free updates.
- Pressing an alphanumeric key will take you to the first menu 
  entry that starts with that character.
- Now triming menu entries to 77 characters.

v2.0 (7/11/99) 
- Ported to Windows.

v2.1 (7/14/99)
- Better support for Windows emulators.
- Built-in support for ZIP archives, using ZLib.

v2.2 (7/18/99)
- Numerous major improvements and enhancements. :-)
- Added status bar at the bottom, look here to find out what FrontRunner is doing.

v2.3 (7/19/99)
- Fixed bug of color layout not being processed correctly.
- Fixed bug of background color of nested submenus not being applied.

v2.4 (7/19/99)
- Fixed a stupid bug that made it impossible to scroll up and down using the keyboard.
- Added a new feature, press the F1 key to invoke Notepad in order to edit the curently
  opened file. FrontRunner will reload it once you exit Notepad.

v2.5 (7/27/99)
- Some more internal enhancements.
- Added joystick/gamepad support.

v2.6 (9/23/99)
- Added the ability to detect what OS the emulator is for, and spawn accordingly. So you
  will have to remove the OS descriptors from the parameter files.

v2.7 (10/3/00)
- Fixed a program launching bug.
- Added an Open file dialog box if no file is given on the command line.
- A few other minor changes.

Usage
-----

    The program is simple, one file FrontRunner.exe. Run the program specifying a file 
name as a parameter. The file need only be a plain ASCII text file. The format of the 
parameter file is as follows:

The first line is simply 3 numbers, specifying the color layout of the menu.
The order is, background, text, hilite. They can be seperated with
commas. The colors must be a 24-bit direct color value, bits 0-7 represent red, 
bits 8-15 represent green, and bits 16-23 represent blue.

The next line describes how the file is to be handled. It either contains 
the word "NORMAL" or "ZIPPED".

If the descriptor is "ZIPPED", then the next line is as follows:

The next line specifies the file name of the archive (no path).

The next line specifies the title name to be displayed in the Title Bar.

The next line specifies the directory where the program that is called to
handle the menu items resides. It must contain a trailing backslash.

The next line specifies the directory where the menu item files reside. It
must contain a trailing backslash.

The next line specifies the program name that is called to handle the menu
items. You can even type any parameters you want passed to this program.

From here on is where the menu items are specified. Each entry consists of
2 lines. They are as follows:

The first line specifies the menu entry title to be displayed in the menu.

The second line specifies the menu entry file name to be passed to the
handling program. You can type any additional parameters for this particular
file.

Following is an example of one such file (ZSNES.TXT):

8388608,16777215,128
ZIPPED
games.zip
Super Nintendo Games
c:\console\snes\zsnes\
c:\console\snes\games\
zsnes.exe -c
Super Mario World
mario.smc
Final Fantasy II
ff2.smc -x
Super Street Fighter 2
ssf2.fig

You can even create nested menus with a root file like this (SYSTEMS.TXT):

8388608,16777215,128
NORMAL
Console Systems
c:\console\
c:\console\
FrontRunner.exe
ZSNES
zsnes.txt
NESticle
nesticle.txt
KGen98
kgen98.txt

Navigation
----------

Key                Action
-------------------------
Up                 Move marker up one position
Down               Move marker down one position
Page Up            Move marker up one pagefull
Page Down          Move marker down one pagefull
Home               Move marker to top of menu
End                Move marker to bottom of menu
Enter              Launch specified program for current menu entry
Esc                Back up to previous menu, or if at first menu exit FrontRunner
F1                 Launch Notepad to edit currently openned menu file
[Alphanumerics]    Goto first or next menu entry that starts with the specified character

Mouse button       Action
-------------------------
Left-single click  Move marker to clicked menu entry
Left-double click  Launch specified program for current menu entry

Joystick button    Action
-------------------------
Button 1           Launch specified program for current menu entry
Button 2           Back up to previous menu, or if at first menu exit FrontRunner
Button 3           Launch Notepad to edit currently openned menu file

Using Zipped Archives
---------------------

    In the example ZSNES.TXT you see that it is a ZIPPED configuration. The archive 
is "games.zip". This file is expected to be in the directory "c:\console\snes\games\".

    FrontRunner will extract a menu entry file out of this archive, pass it to the 
handling program, and upon exitting the program the file will be erased.

Notes
-----

FrontRunner will alphabetically sort the menu entries, for easier finding.

The number displayed at the end of the title bar, is the number of menu entries.

To handle special programs such as Callus, which only need the name of the 
game with no directory specification, leave the game directory line empty.

Conclusion
----------

    The DOS port was made with Turbo C++ 1.0, as such it is a Real-Mode program.
This will offer the greatest compatibility with other programs. I tried making
a DJGPP version but it would crash after exiting ZSNES, any ideas why? The Windows
port was made with Visual C++ 6.0. I made it in about one hour for myself, I then 
decided that other people might like to use it as well. So please don't e-mail me 
bitching about how much you hate the damn thing. Enjoy it or leave me alone. Do 
send me e-mail if you like it. :-)

Please, will somebody send me feedback on this thing!

Copyrights
----------

FrontRunner is copyright Marius Fodor.
ZSNES is copyright zsKnight and _Demo_.
NESticle, Callus are copyright Bloodlust Software.
KGen98 is copyright Steve Snake.
Turbo C++ is copyright Borland International.
Visual C++ is copyright Microsoft Corporation.
Super Mario World is copyright Nintendo.
Final Fantasy II is copyright Squaresoft.
Super Street Fighter 2 is copyright Capcom.
ZLib is copyright Jean-loup Gailly and Mark Addler