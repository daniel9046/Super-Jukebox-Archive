#include <windows.h>
#include <stdio.h>
#include <direct.h>
#include <process.h>
#include <commctrl.h>
#include "unzip.h"
#include "resource.h"

#define MAXNESTING 10
#define szAppName "FrontRunner"

int cxChar,cxCaps,cyChar,cxClient,cyClient;
int iEntries,iFirstEntry,iActiveEntry;
int iClr0,iClr1,iClr2;
int iNestedIndex,iNestedActiveEntries[MAXNESTING],iNestedFirstEntries[MAXNESTING];
int iOldNestedIndex=-1;
UINT wXposCentered,wYposCentered;
char szTitle[80],szDir0[MAX_PATH],szDir1[MAX_PATH],szDir2[MAX_PATH],szFilename[MAX_PATH];
char szExeFile[MAX_PATH],szArchive[MAX_PATH];
char (*spTitles)[80],(*spFilenames)[MAX_PATH];
char szInputFile[MAX_PATH],szNestedFiles[MAXNESTING][MAX_PATH];
BOOL bZipped,bLaunched,bDOSMode,bLaunchEditor,bUseJoystick;
HANDLE hChildProcess;
HWND hwndMain,hwndStatusBar,hwndScrollBar;

void fnDisplayError(char *szFormat,...);
BOOL fnExtractFileFromZip(char*,char*);
void fnKeyboardNavigate(HWND,UINT,WPARAM,LPARAM);
void fnMouseNavigate(HWND,UINT,WPARAM,LPARAM);
void fnJoystickNavigate(HWND,UINT,WPARAM,LPARAM);
int fnParseInputFile(PSTR);
void fnRedrawScreen(HWND,HDC,PAINTSTRUCT*);
void fnReprintList(HWND,HDC,PAINTSTRUCT*);
void fnSortList();
void fnSpawningThread(void*);
void fnTrim(char*);
void fnTrimBackslash(char*);
void fnTrimSpace(char*);
LRESULT CALLBACK WindowProc(HWND,UINT,WPARAM,LPARAM);
int WINAPI WinMain(HINSTANCE,HINSTANCE,PSTR,int);