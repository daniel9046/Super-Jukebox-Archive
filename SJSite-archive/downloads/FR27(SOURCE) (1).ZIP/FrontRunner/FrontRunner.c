#include "FrontRunner.h"

void fnDisplayError(char *szFormat,...)
{
	char szBuffer[1024];
	va_list pArgList;

	va_start(pArgList,szFormat);
	_vsnprintf(szBuffer,sizeof(szBuffer),szFormat,pArgList);
	va_end(pArgList);

	MessageBox(hwndMain,szBuffer,szAppName,MB_ICONERROR);
}

BOOL fnExtractFileFromZip(char *szInputFilename,char *szOutputFilename)
{
	voidp vpBuffer;
	uLong l;
	unz_file_info ufiInfo;
	unzFile ufFile;
	FILE *fileOutFileHandle;

	if((ufFile=unzOpen(szInputFilename))==NULL) return FALSE;
	if(unzLocateFile(ufFile,szOutputFilename,2)==UNZ_OK)
	{
		unzGetCurrentFileInfo(ufFile,&ufiInfo,NULL,0,NULL,0,NULL,0);
		if((vpBuffer=malloc(ufiInfo.uncompressed_size))==NULL) return FALSE;
		if(unzOpenCurrentFile(ufFile)!=UNZ_OK) {free(vpBuffer); return FALSE;}
		l=unzReadCurrentFile(ufFile,vpBuffer,ufiInfo.uncompressed_size);
		if(l<=0||l!=ufiInfo.uncompressed_size) {free(vpBuffer); return FALSE;}
		if(unzCloseCurrentFile(ufFile)==UNZ_CRCERROR) {free(vpBuffer); return FALSE;}
		if(unzClose(ufFile)!=UNZ_OK) {free(vpBuffer); return FALSE;}

		if((fileOutFileHandle=fopen(szOutputFilename,"wb"))==NULL) {free(vpBuffer); return FALSE;}
		if(fwrite(vpBuffer,ufiInfo.uncompressed_size,1,fileOutFileHandle)!=1) {free(vpBuffer); return FALSE;}
		if(fclose(fileOutFileHandle)!=0) {free(vpBuffer); return FALSE;}
		free(vpBuffer);
		return TRUE;
	}
	return FALSE;
}

void fnTrim(char *spString)
{
	if(spString[strlen(spString)-1]=='\n')
		spString[strlen(spString)-1]='\0';
}

void fnTrimBackslash(char *spString)
{
	if(spString[strlen(spString)-1]=='\\')
		spString[strlen(spString)-1]='\0';
}

void fnTrimSpace(char *spString)
{
	unsigned int i;

	for(i=0;i<strlen(spString);i++)
		if(spString[i]==' '){spString[i]='\0'; break;}
}

void fnSpawningThread(void *dummy)
{
	char szBuffer[500];
	int iTmp0;

	bLaunched=TRUE;
	if(bLaunchEditor)
	{
		SetWindowText(hwndStatusBar,"Spawning Notepad...");
		_spawnlp(_P_WAIT,"notepad","notepad",szInputFile,NULL);
		bLaunched=bLaunchEditor=FALSE;
		sprintf(szBuffer,"Reloading %s...",szInputFile);
		SetWindowText(hwndStatusBar,szBuffer);
		iActiveEntry=iFirstEntry=0;
		if(fnParseInputFile(szInputFile))SendMessage(hwndMain,WM_CLOSE,0,0);
		iOldNestedIndex=-1;
		InvalidateRect(hwndMain,NULL,FALSE);
		UpdateWindow(hwndMain);
		SetWindowText(hwndStatusBar,"Ready...");
		return;
	}
	getcwd(szDir2,sizeof(szDir2));
	if(iTmp0=bZipped)
	{
		chdir(szDir1);
		strcpy(szFilename, spFilenames[iActiveEntry]);
		fnTrimSpace(szFilename);
		sprintf(szBuffer,"Extracting %s...",szFilename);
		SetWindowText(hwndStatusBar,szBuffer);
		if(fnExtractFileFromZip(szArchive,szFilename)==FALSE)
		{
			fnDisplayError("Cannot extract %s from %s",szFilename,szArchive);
			chdir(szDir2);
			return;
		}
		SetWindowText(hwndStatusBar,"Ready...");
	}
	chdir(szDir0);
	strcpy(szFilename,szDir1);
	strcat(szFilename,spFilenames[iActiveEntry]);
	if(!strcmpi(szExeFile,"FrontRunner.exe"))
	{
		if(iNestedIndex<MAXNESTING)
		{
			sprintf(szBuffer,"Loading %s...",szFilename);
			SetWindowText(hwndStatusBar,szBuffer);
			strcpy(szNestedFiles[iNestedIndex],szInputFile);
			iNestedActiveEntries[iNestedIndex]=iActiveEntry;
			iNestedFirstEntries[iNestedIndex++]=iFirstEntry;
			iActiveEntry=iFirstEntry=0;
			if(fnParseInputFile(szFilename))
			{
				strcpy(szInputFile,szNestedFiles[--iNestedIndex]);
				sprintf(szBuffer,"Loading %s...",szInputFile);
				SetWindowText(hwndStatusBar,szBuffer);
				iActiveEntry=iNestedActiveEntries[iNestedIndex];
				iFirstEntry=iNestedFirstEntries[iNestedIndex];
				chdir(szDir2);
				fnParseInputFile(szInputFile);
			}
			InvalidateRect(hwndMain,NULL,FALSE);
			UpdateWindow(hwndMain);
			SetWindowText(hwndStatusBar,"Ready...");
		}
		else
			fnDisplayError("Nesting is too deep.");
	}
	else
	{
		sprintf(szBuffer,"Spawning %s...",szExeFile);
		SetWindowText(hwndStatusBar,szBuffer);
		if(bDOSMode)
		{
			strcpy(szBuffer,szExeFile);strcat(szBuffer," ");strcat(szBuffer,szFilename);
			system(szBuffer);
		}
		else
			_spawnl(_P_WAIT,szExeFile,szExeFile,szFilename,NULL);
		SetWindowText(hwndStatusBar,"Ready...");
	}
	if(iTmp0)
	{
		sprintf(szBuffer,"Deleting %s...",szFilename);
		SetWindowText(hwndStatusBar,szBuffer);
		fnTrimSpace(szFilename);
		unlink(szFilename);
		SetWindowText(hwndStatusBar,"Ready...");
	}
	chdir(szDir2);
	bLaunched=FALSE;
}

void fnSortList()
{
	int iTop,iSeek;
	char szA[80],szB[MAX_PATH];

	for(iTop=0;iTop<iEntries-1;iTop++)
		for(iSeek=iTop+1;iSeek<iEntries;iSeek++)
			if(strcmpi(spTitles[iTop],spTitles[iSeek])>0)
			{
				strcpy(szA,spTitles[iTop]);
				strcpy(szB,spFilenames[iTop]);
				strcpy(spTitles[iTop],spTitles[iSeek]);
				strcpy(spFilenames[iTop],spFilenames[iSeek]);
				strcpy(spTitles[iSeek],szA);
				strcpy(spFilenames[iSeek],szB);
			}
}

int fnParseInputFile(PSTR szFilename)
{
	char szBuffer[500],szFormat[80];
	FILE *fileInput;
	fpos_t filepos;
	int i,i0;
	DWORD iMode;
	SHFILEINFO shfi;

	strcpy(szInputFile,szFilename);
	if(!strlen(szInputFile))
	{
		OPENFILENAME ofn;
		memset(&ofn,0,sizeof(ofn));
		ofn.lStructSize=sizeof(ofn);
		ofn.hwndOwner=NULL;
		ofn.lpstrTitle="Please open your parameter file...";
		ofn.lpstrFilter="Parameter Files (.TXT)\0*.TXT\0All Files (*.*)\0*.*\0";
		ofn.lpstrFile=szInputFile;
		ofn.nMaxFile=sizeof(szInputFile);
		ofn.lpstrDefExt="TXT";
		ofn.Flags=OFN_FILEMUSTEXIST|OFN_HIDEREADONLY|OFN_NOCHANGEDIR;
		if(!GetOpenFileName(&ofn))return 1;
	}
	if((fileInput=fopen(szInputFile, "rt"))==NULL)
	{
		fnDisplayError("Cannot open file: %s",szFilename);
		return 1;
	}
	fgets(szFormat,sizeof(szFormat),fileInput); fnTrim(szFormat);
	i=i0=0;
	while(szFormat[i]!=','&&szFormat[i]!='\0') szBuffer[i0++]=szFormat[i++];
	szBuffer[i0]='\0';iClr0=atoi(szBuffer);i0=0;i++;
	while(szFormat[i]!=','&&szFormat[i]!='\0') szBuffer[i0++]=szFormat[i++];
	szBuffer[i0]='\0';iClr1=atoi(szBuffer);i0=0;i++;
	while(szFormat[i]!=','&&szFormat[i]!='\0') szBuffer[i0++]=szFormat[i++];
	szBuffer[i0]='\0';iClr2=atoi(szBuffer);i0=0;i++;

	fgets(szFormat,sizeof(szFormat),fileInput);fnTrim(szFormat);
	iMode=0;
	if(!strcmpi(szFormat, "normal")) iMode=1;
	else if(!strcmpi(szFormat, "zipped")) iMode=2;

	if(!iMode)
	{
		fnDisplayError("Unrecognized file format.");
		return 1;
	}
	else if(iMode==1)
		bZipped=FALSE;
	else 
	{
		bZipped=TRUE;
		fgets(szArchive,sizeof(szArchive),fileInput); fnTrim(szArchive);
	}
	fgets(szTitle,sizeof(szTitle),fileInput); fnTrim(szTitle);
	fgets(szDir0,sizeof(szDir0),fileInput); fnTrim(szDir0);
	fgets(szDir1,sizeof(szDir1),fileInput); fnTrim(szDir1);
	fgets(szExeFile,sizeof(szExeFile),fileInput); fnTrim(szExeFile);

	strcpy(szBuffer,szDir0); strcat(szBuffer,szExeFile);
	if(!(iMode=SHGetFileInfo(szBuffer,0,&shfi,sizeof(shfi),SHGFI_EXETYPE)))
	{
		fnDisplayError("Handling program is not a valid executable.");
		return 1;
	}
	szBuffer[0]=(char)iMode&0xFF;szBuffer[1]=(char)((iMode&0xFF00)>>8);szBuffer[2]=0;
	if(!strcmp(szBuffer,"MZ"))
		bDOSMode=TRUE;
	else if(!strcmp(szBuffer,"PE")||!strcmp(szBuffer,"NE"))
		bDOSMode=FALSE;
	else
	{
		fnDisplayError("Handling program is not a valid executable.");
		return 1;
	}
	fgetpos(fileInput,&filepos);

	iEntries=0;
	while(1)
	{
		if(fgets(szBuffer,sizeof(szBuffer),fileInput)==NULL) break;
		if(fgets(szBuffer,sizeof(szBuffer),fileInput)==NULL) break;
		iEntries++;
	}
	fsetpos(fileInput,&filepos);

	if(spTitles)
		free(spTitles);
	if(spFilenames)
		free(spFilenames);
	if((spTitles=malloc(iEntries*sizeof(*spTitles)))==NULL)
	{
		fnDisplayError("Out of memory!");
		return 1;
	}
	if((spFilenames=malloc(iEntries*sizeof(*spFilenames)))==NULL)
	{
		fnDisplayError("Out of memory!");
		return 1;
	}
	for(i=0;i<iEntries;i++)
	{
		fgets(spTitles[i],sizeof(spTitles[i]),fileInput); fnTrim(spTitles[i]);
		fgets(spFilenames[i],sizeof(spFilenames[i]),fileInput); fnTrim(spFilenames[i]);
	}
	
	fclose(fileInput);
	fnSortList();
	return 0;
}

void fnKeyboardNavigate(HWND hwnd,UINT message,WPARAM wParam,LPARAM lParam)
{
	int i,iTmp0,iTmp1,iTmp2;
	char szBuffer[500];
	SCROLLINFO si;

	iTmp0=iActiveEntry;iTmp1=iFirstEntry;iTmp2=iNestedIndex;
	if(message==WM_KEYDOWN)
	switch(wParam)
	{
	case VK_UP:
		if(iActiveEntry>0) iActiveEntry--;
		if(iActiveEntry<iFirstEntry) iFirstEntry=iActiveEntry;
		if(iActiveEntry>iFirstEntry+cyClient/cyChar-1) iFirstEntry=iActiveEntry-cyClient/cyChar+1;
		break;
	case VK_DOWN:
		if(iActiveEntry<iEntries-1) iActiveEntry++;
		if(iActiveEntry<iFirstEntry) iFirstEntry=iActiveEntry;
		if(iActiveEntry>iFirstEntry+cyClient/cyChar-1) iFirstEntry=iActiveEntry-cyClient/cyChar+1;
		break;

	case VK_PRIOR:
		if(iActiveEntry<iFirstEntry) iFirstEntry=iActiveEntry;
		if(iActiveEntry>iFirstEntry+cyClient/cyChar-1) iFirstEntry=iActiveEntry-cyClient/cyChar+1;
		i=iActiveEntry-iFirstEntry;
		iFirstEntry-=cyClient/cyChar;
		if(iFirstEntry<0) iFirstEntry=0;
		iActiveEntry=iFirstEntry+i;
		break;

	case VK_NEXT:
		if(iActiveEntry<iFirstEntry) iFirstEntry=iActiveEntry;
		if(iActiveEntry>iFirstEntry+cyClient/cyChar-1) iFirstEntry=iActiveEntry-cyClient/cyChar+1;
		i=iActiveEntry-iFirstEntry;
		iFirstEntry+=cyClient/cyChar;
		if(iFirstEntry>iEntries-cyClient/cyChar) iFirstEntry=iEntries-cyClient/cyChar;
		if(iFirstEntry<0) iFirstEntry=0;
		iActiveEntry=iFirstEntry+i;
		break;

	case VK_HOME:
		iActiveEntry=iFirstEntry=0;
		break;

	case VK_END:
		iFirstEntry=iEntries-cyClient/cyChar; iActiveEntry=iEntries-1;
		if(iFirstEntry<0) iFirstEntry=0;
		break;

	case VK_RETURN:
		if(bLaunched)
		{
			MessageBox(hwnd,"You must first close previously launched program.",szAppName,MB_ICONEXCLAMATION);
			break;
		}
		_beginthread(fnSpawningThread,0,NULL);
		break;

	case VK_ESCAPE:
		if(bLaunched)
		{
			MessageBox(hwnd,"You must first close previously launched program.",szAppName,MB_ICONEXCLAMATION);
			break;
		}
		if(iNestedIndex>0)
		{
			strcpy(szInputFile,szNestedFiles[--iNestedIndex]);
			sprintf(szBuffer,"Loading %s...",szInputFile);
			SetWindowText(hwndStatusBar,szBuffer);
			iActiveEntry=iNestedActiveEntries[iNestedIndex];
			iFirstEntry=iNestedFirstEntries[iNestedIndex];
			fnParseInputFile(szInputFile);
			SetWindowText(hwndStatusBar,"Ready...");
		}
		else
			SendMessage(hwnd,WM_CLOSE,0,0);
		break;
	}
	else if(wParam>=32&&wParam<=126)
	{
		for(i=iActiveEntry+1;i<iEntries;i++)
			if(toupper(spTitles[i][0])==toupper(wParam))
			{
				iActiveEntry=i;
				if(iActiveEntry<iFirstEntry) iFirstEntry=iActiveEntry;
				else if(iActiveEntry>iFirstEntry+cyClient/cyChar-1) iFirstEntry=iActiveEntry-cyClient/cyChar+1;
				if(iFirstEntry>iEntries-cyClient/cyChar) iFirstEntry=iEntries-cyClient/cyChar;
				if(iFirstEntry<0) iFirstEntry=0;
				break;
			}
			if(i==iEntries)
				for(i=0;i<iActiveEntry;i++)
					if(toupper(spTitles[i][0])==toupper(wParam))
					{
						iActiveEntry=i;
						if(iActiveEntry<iFirstEntry) iFirstEntry=iActiveEntry;
						else if(iActiveEntry>iFirstEntry+cyClient/cyChar-1) iFirstEntry=iActiveEntry-cyClient/cyChar+1;
						if(iFirstEntry>iEntries-cyClient/cyChar) iFirstEntry=iEntries-cyClient/cyChar;
						if(iFirstEntry<0) iFirstEntry=0;
						break;
					}
	}
	if(iTmp0!=iActiveEntry||iTmp1!=iFirstEntry||iTmp2!=iNestedIndex)
		InvalidateRect(hwnd,NULL,FALSE);
	if(iTmp1!=iFirstEntry)
	{
		si.cbSize=sizeof(si);
		si.fMask=SIF_POS;
		si.nPos=iFirstEntry;
		SetScrollInfo(hwndScrollBar,SB_CTL,&si,TRUE);
	}
}

void fnMouseNavigate(HWND hwnd,UINT message,WPARAM wParam,LPARAM lParam)
{
	int iMouseX,iMouseY,iTmp0;

	iMouseX=LOWORD(lParam);
	iMouseY=HIWORD(lParam);
	iTmp0=iActiveEntry;

	if(iMouseX>cxClient-1)return;

	switch(message)
	{
	case WM_LBUTTONDOWN:
		if(iMouseY/cyChar+iFirstEntry<iEntries)
		iActiveEntry=iMouseY/cyChar+iFirstEntry;
		break;
	case WM_LBUTTONDBLCLK:
		if(iMouseY/cyChar+iFirstEntry<iEntries)
		SendMessage(hwnd,WM_KEYDOWN,VK_RETURN,0);
		break;
	}
	if(iTmp0!=iActiveEntry) 
	{
		InvalidateRect(hwnd,NULL,FALSE);
		UpdateWindow(hwnd);
	}
}

void fnJoystickNavigate(HWND hwnd,UINT message,WPARAM wParam,LPARAM lParam)
{
	if(HIWORD(lParam)>wXposCentered)SendMessage(hwnd,WM_KEYDOWN,VK_DOWN,0);
	else if(HIWORD(lParam)<wXposCentered)SendMessage(hwnd,WM_KEYDOWN,VK_UP,0);
	if(wParam&JOY_BUTTON1)SendMessage(hwnd,WM_KEYDOWN,VK_RETURN,0);
	if(wParam&JOY_BUTTON2)SendMessage(hwnd,WM_KEYDOWN,VK_ESCAPE,0);	
	if(wParam&JOY_BUTTON3)SendMessage(hwnd,WM_COMMAND,IDA_F1,0);
}

void fnReprintList(HWND hwnd,HDC hdc,PAINTSTRUCT *ps)
{
	int y,i,iPaintBeg,iPaintEnd;
	SCROLLINFO si;

	si.cbSize=sizeof(si);
	si.fMask=SIF_POS;
	GetScrollInfo(hwndScrollBar,SB_CTL,&si);
	iFirstEntry=si.nPos;

	iPaintBeg=max(0,iFirstEntry+ps->rcPaint.top/cyChar);
	iPaintEnd=min(iEntries-1,iFirstEntry+ps->rcPaint.bottom/cyChar);

	for(i=iPaintBeg;i<=iPaintEnd;i++)
	{
		y=cyChar*(i-iFirstEntry);
		if(i==iActiveEntry)SetBkColor(hdc,iClr2);else SetBkColor(hdc,iClr0);
		TextOut(hdc,cxClient/2,y,spTitles[i],strlen(spTitles[i]));
	}
}

void fnRedrawScreen(HWND hwnd,HDC hdc,PAINTSTRUCT *ps)
{
	char szBuffer[500];
	SCROLLINFO si;

	if(iOldNestedIndex!=iNestedIndex)
	{
		sprintf(szBuffer,"%s - %s - [%d]",szAppName,szTitle,iEntries);
		SetWindowText(hwnd,szBuffer);
		DeleteObject(SelectObject(hdc,CreateSolidBrush(iClr0)));
		DeleteObject(SelectObject(hdc,CreatePen(PS_SOLID,0,iClr0)));
		SetTextColor(hdc,iClr1);
		si.cbSize=sizeof(si);
		si.fMask=SIF_RANGE|SIF_PAGE|SIF_POS;
		si.nMin=0;
		si.nMax=iEntries-1;
		si.nPage=cyClient/cyChar;
		si.nPos=iFirstEntry;
		SetScrollInfo(hwndScrollBar,SB_CTL,&si,TRUE);
		iOldNestedIndex=iNestedIndex;
	}

	Rectangle(hdc,0,0,cxClient,cyClient);
	fnReprintList(hwnd,hdc,ps);
}

int WINAPI WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,PSTR szCmdLine,int iCmdShow)
{
	MSG msg;
	WNDCLASS wndclass;
	HACCEL hAccel;

	if(fnParseInputFile(szCmdLine))
		return 1;

	wndclass.style=CS_HREDRAW|CS_VREDRAW|CS_DBLCLKS;
	wndclass.lpfnWndProc=WindowProc;
	wndclass.cbClsExtra=0;
	wndclass.cbWndExtra=0;
	wndclass.hInstance=hInstance;
	wndclass.hIcon=LoadIcon(hInstance,szAppName);
	wndclass.hCursor=LoadCursor(NULL,IDC_ARROW);
	wndclass.hbrBackground=NULL;
	wndclass.lpszMenuName=NULL;
	wndclass.lpszClassName=szAppName;

	if(!RegisterClass(&wndclass))
	{
		fnDisplayError("Unable to register window class.");
		return 1;
	}

	hwndMain=CreateWindow(szAppName,szAppName,
		              WS_OVERLAPPEDWINDOW,
					  GetSystemMetrics(SM_CXSCREEN)/4,GetSystemMetrics(SM_CYSCREEN)/4,
					  GetSystemMetrics(SM_CXSCREEN)/2,GetSystemMetrics(SM_CYSCREEN)/2,
					  NULL,NULL,hInstance,NULL);

	ShowWindow(hwndMain,iCmdShow);
	UpdateWindow(hwndMain);

	if((hAccel=LoadAccelerators(hInstance,szAppName))==NULL)
	{
		fnDisplayError("Cannot load accelerator.");
		return 1;
	}

	while(GetMessage(&msg,NULL,0,0))
		if(!TranslateAccelerator(hwndMain,hAccel,&msg))
		{
			TranslateMessage(&msg);
			DispatchMessage(&msg);
		}

	return msg.wParam;
}

LRESULT CALLBACK WindowProc(HWND hwnd,UINT message,WPARAM wParam,LPARAM lParam)
{
	static HDC hdc,hdc0;
	static HBITMAP hbmp,hbmp0;
	RECT rect;
	PAINTSTRUCT ps;
	TEXTMETRIC tm;
	SCROLLINFO si;
	JOYINFO jiJoy1;
	JOYCAPS jcJoy1;
	INITCOMMONCONTROLSEX icc;
	static int iPass,cyStatusBar,cxScrollBar;

	ZeroMemory(&jcJoy1,sizeof(jcJoy1));

	switch(message)
	{
	case WM_CREATE:
		icc.dwSize=sizeof(icc);
		icc.dwICC=ICC_BAR_CLASSES;
		if(InitCommonControlsEx(&icc)==FALSE)
		{
			fnDisplayError("Can't initialize common controls.");
			return -1;
		}

		hwndStatusBar=CreateWindow(STATUSCLASSNAME,"Ready...",WS_CHILD|WS_VISIBLE,
			                       0,0,0,0,
								   hwnd,0,((LPCREATESTRUCT)lParam)->hInstance,NULL);
		if(!hwndStatusBar)
			return -1;
		hwndScrollBar=CreateWindow("scrollbar",NULL,WS_CHILD|WS_VISIBLE|SBS_VERT,
							       0,0,0,0,
								   hwnd,(HMENU)1,((LPCREATESTRUCT)lParam)->hInstance,NULL);
		if(!hwndScrollBar)
			return -1;

		cxScrollBar=GetSystemMetrics(SM_CXVSCROLL);
		GetWindowRect(hwndStatusBar,&rect);
		cyStatusBar=rect.bottom-rect.top;

		hdc=GetDC(hwnd);
		hdc0=CreateCompatibleDC(hdc);
		ReleaseDC(hwnd,hdc);
		SetTextAlign(hdc0,TA_CENTER);

		GetTextMetrics(hdc0,&tm);
		cxChar=tm.tmAveCharWidth;
		cxCaps=(tm.tmPitchAndFamily&1?3:2)*cxChar/2;
		cyChar=tm.tmHeight+tm.tmExternalLeading;

		bUseJoystick=TRUE;
		if(!joyGetNumDevs())bUseJoystick=FALSE;
		if(bUseJoystick&&joyGetDevCaps(JOYSTICKID1,&jcJoy1,sizeof(jcJoy1))!=JOYERR_NOERROR)bUseJoystick=FALSE;
		if(bUseJoystick&&joyGetPos(JOYSTICKID1,&jiJoy1)!=JOYERR_NOERROR)bUseJoystick=FALSE;
		wXposCentered=jiJoy1.wXpos;wYposCentered=jiJoy1.wYpos;
		return 0;

	case WM_SIZE:
		cxClient=LOWORD(lParam)-cxScrollBar;
		cyClient=HIWORD(lParam)-cyStatusBar;
		si.cbSize=sizeof(si);
		si.fMask=SIF_RANGE|SIF_PAGE|SIF_DISABLENOSCROLL;
		si.nMin=0;
		si.nMax=iEntries-1;
		si.nPage=cyClient/cyChar;
		SetScrollInfo(hwndScrollBar,SB_CTL,&si,TRUE);
		MoveWindow(hwndScrollBar,cxClient,0,cxScrollBar,cyClient,TRUE);
		SendMessage(hwndStatusBar,message,wParam,lParam);
		hdc=GetDC(hwnd);
		if(iPass){SelectObject(hdc0,hbmp0);DeleteObject(hbmp);}else iPass=1;
		hbmp=CreateCompatibleBitmap(hdc,cxClient,cyClient);
		hbmp0=SelectObject(hdc0,hbmp);
		ReleaseDC(hwnd,hdc);
		return 0;

	case WM_VSCROLL:
		si.cbSize=sizeof(si);
		si.fMask=SIF_ALL;
		GetScrollInfo(hwndScrollBar,SB_CTL,&si);
		iFirstEntry=si.nPos;
		switch(LOWORD(wParam))
		{
		case SB_TOP:
			si.nPos=si.nMin;
			break;
		case SB_BOTTOM:
			si.nPos=si.nMax;
			break;
		case SB_LINEUP:
			si.nPos-=1;
			break;
		case SB_LINEDOWN:
			si.nPos+=1;
			break;
		case SB_PAGEUP:
			si.nPos-=si.nPage;
			break;
		case SB_PAGEDOWN:
			si.nPos+=si.nPage;
			break;
		case SB_THUMBTRACK:
			si.nPos=si.nTrackPos;
			break;
		}
		si.fMask=SIF_POS;
		SetScrollInfo(hwndScrollBar,SB_CTL,&si,TRUE);
		GetScrollInfo(hwndScrollBar,SB_CTL,&si);
		if(si.nPos!=iFirstEntry)
		{
			rect.left=rect.top=0;
			rect.right=cxClient;rect.bottom=cyClient;
			ScrollWindow(hwnd,0,cyChar*(iFirstEntry-si.nPos),&rect,&rect);
			UpdateWindow(hwnd);
		}
		return 0;

	case WM_KEYDOWN:
	case WM_CHAR:
		fnKeyboardNavigate(hwnd,message,wParam,lParam);
		return 0;

	case WM_LBUTTONDOWN:
	case WM_LBUTTONDBLCLK:
		fnMouseNavigate(hwnd,message,wParam,lParam);
		return 0;

	case MM_JOY1BUTTONDOWN:
	case MM_JOY1MOVE:
		fnJoystickNavigate(hwnd,message,wParam,lParam);
		return 0;

	case WM_PAINT:
		hdc=BeginPaint(hwnd,&ps);
		fnRedrawScreen(hwnd,hdc0,&ps);
		BitBlt(hdc,0,0,cxClient,cyClient,hdc0,0,0,SRCCOPY);
		EndPaint(hwnd,&ps);
		return 0;

	case WM_COMMAND:
		switch(LOWORD(wParam))
		{
		case IDA_F1:
			if(bLaunched)
			{
				MessageBox(hwnd,"You must first close previously launched program.",szAppName,MB_ICONEXCLAMATION);
				return 0;
			}
			bLaunchEditor=TRUE;
			_beginthread(fnSpawningThread,0,NULL);
			return 0;
		}
		break;

	case WM_CLOSE:
		if(bLaunched)
		{
			MessageBox(hwnd,"You must first close previously launched program.",szAppName,MB_ICONEXCLAMATION);
			return 0;
		}
		DestroyWindow(hwnd);
		return 0;

	case WM_DESTROY:
		DeleteDC(hdc0);
		DeleteObject(hbmp);
		PostQuitMessage(0);
		return 0;

	case WM_SETFOCUS:
		if(bUseJoystick)
		{
			while(joyGetPos(JOYSTICKID1,&jiJoy1)!=JOYERR_NOERROR);
			joySetCapture(hwnd,JOYSTICKID1,jcJoy1.wPeriodMin,TRUE);
		}
		return 0;

	case WM_KILLFOCUS:
		if(bUseJoystick)
			joyReleaseCapture(JOYSTICKID1);
		return 0;
	}
	return DefWindowProc(hwnd,message,wParam,lParam);
}