//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SJ.rc
//
#define IDS_STRING1                     101
#define IDD_DIALOG1                     102
#define IDR_ZIP_DATA1                   103
#define IDS_STRING2                     103
#define IDI_ICON1                       104
#define IDS_STRING3                     104
#define IDC_EDIT1                       1000
#define IDC_BUTTON1                     1001
#define IDC_PROGRESS1                   1002
#define IDC_CHECK1                      1003
#define IDC_CHECK2                      1004
#define IDC_CHECK3                      1005
#define IDC_CHECK4                      1006
#define IDC_CHECK5                      1007
#define IDC_CHECK6                      1008

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        113
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1009
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
