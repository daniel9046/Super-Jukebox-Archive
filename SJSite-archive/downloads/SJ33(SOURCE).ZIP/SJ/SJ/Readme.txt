                               Installation Program for Super Jukebox
                                        by Marius Fodor
                                    (marius.fodor@usa.net)


        This is the installation program for Super Jukebox. You must place all the files
needed by the installer in the SJ.ZIP archive which will become part of the executable once
compiled.
