#if !defined(AFX_SONGPROPSDLG_H__CE61B4C2_6EB6_11D4_8925_009027C5CF93__INCLUDED_)
#define AFX_SONGPROPSDLG_H__CE61B4C2_6EB6_11D4_8925_009027C5CF93__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// SongPropsDlg.h : header file
//

#include "Globals.h"

/////////////////////////////////////////////////////////////////////////////
// CSongPropsDlg dialog

class CSongPropsDlg : public CDialog
{
// Construction
public:
	int iOldSelection;
	std::vector<SongEntry>seSpareList;
	BOOL m_bModified;
	CSongPropsDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CSongPropsDlg)
	enum { IDD = IDD_DIALOG4 };
	CSpinButtonCtrl	m_ctlSpin4_1;
	CSpinButtonCtrl	m_ctlSpin4_2;
	CSpinButtonCtrl	m_ctlSpin4_3;
	CEdit	m_edRepetitions;
	CEdit	m_edFade;
	CEdit	m_edLength;
	CEdit	m_edComment;
	CEdit	m_edDate;
	CEdit	m_edDumper;
	CEdit	m_edArtist;
	CEdit	m_edGame;
	CEdit	m_edTitle;
	CListBox	m_lbList4_1;
	CString	m_strTitle;
	CString	m_strGame;
	CString	m_strArtist;
	CString	m_strDumper;
	CString	m_strDate;
	CString	m_strComment;
	CString	m_strLength;
	CString	m_strFade;
	CString	m_strRepetitions;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSongPropsDlg)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CSongPropsDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSelchangeList4_1();
	afx_msg void OnDeltaposSpin4_1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpin4_2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SONGPROPSDLG_H__CE61B4C2_6EB6_11D4_8925_009027C5CF93__INCLUDED_)
