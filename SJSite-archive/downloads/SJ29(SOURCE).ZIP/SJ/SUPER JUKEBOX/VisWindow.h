#if !defined(AFX_VISWINDOW_H__D708D761_5C10_11D4_8925_009027C572AB__INCLUDED_)
#define AFX_VISWINDOW_H__D708D761_5C10_11D4_8925_009027C572AB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// VisWindow.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CVisWindow window

class CVisWindow : public CWnd
{
// Construction
public:
	CVisWindow();
	BOOL Create(DWORD dwStyle,const RECT& rect,CWnd* pParentWnd,UINT nID);

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CVisWindow)
	protected:
	virtual BOOL OnCommand(WPARAM wParam, LPARAM lParam);
	//}}AFX_VIRTUAL

// Implementation
public:
	void SetThreadPriority(DWORD dwPriority);
	static BOOL bActive;
	void Suspend();
	void Resume();
	static VIS_PARAMS VP;
	void Start();
	void Stop();
	static int Render();
	CWinThread *THand;
	static int KillThread;
	static UINT Thread(LPVOID lpParameter);
	static HDC hdcWnd;
	static BOOL bDrawAll;
	HWND hwndParent;
	CButton CheckBoxes[8];
	static CStatusBarCtrl *m_StatusBar;
	void DrawChannelGauge(int nSndVal,int nMax,HDC pDC,int nXPos,int nYPos,int nWidth,int nHeight);
	static HDC hdcGroup[10];
	HBITMAP hbmpGroup[10];
	static WORD GetSample(PVOID lpBuf,INT nSmp,INT nChn);
	static HPEN Pens[10];
	static HBRUSH Brushes[10];
	static int iWidth,iHeight,iWaveWidth,iWaveHeight;
	int iXPos,iYPos;
	virtual ~CVisWindow();

	// Generated message map functions
protected:
	//{{AFX_MSG(CVisWindow)
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnMove(int x, int y);
	afx_msg void OnPaint();
	afx_msg void OnDestroy();
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_VISWINDOW_H__D708D761_5C10_11D4_8925_009027C572AB__INCLUDED_)
