// GoToDlg.cpp : implementation file
//

#include "stdafx.h"
#include "super jukebox.h"
#include "GoToDlg.h"
#include "Globals.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGoToDlg dialog


CGoToDlg::CGoToDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CGoToDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CGoToDlg)
	m_uiSongNumber = 0;
	uiTotalSongs=0;
	//}}AFX_DATA_INIT
}


void CGoToDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CGoToDlg)
	DDX_Text(pDX, IDC_EDIT_SONG_NUMBER, m_uiSongNumber);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CGoToDlg, CDialog)
	//{{AFX_MSG_MAP(CGoToDlg)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGoToDlg message handlers

BOOL CGoToDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	// TODO: Add your message handler code here and/or call default
	if(pHelpInfo->iContextType==HELPINFO_WINDOW)
	{
		WinHelp(pHelpInfo->dwContextId,HELP_CONTEXTPOPUP);
	}
	
	return CDialog::OnHelpInfo(pHelpInfo);
}

void CGoToDlg::OnOK() 
{
	// TODO: Add extra validation here
	UINT uiNum=GetDlgItemInt(IDC_EDIT_SONG_NUMBER,NULL,FALSE);
	if(uiNum<1||uiNum>uiTotalSongs)
	{
		CString str;
		str.Format("Please enter an integer between 1 and %u.",uiTotalSongs);
		MessageBox(str,AfxGetApp()->m_pszAppName,MB_ICONWARNING);
		return;
	}
	CDialog::OnOK();
}

BOOL CGoToDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_SONG_NUMBER))->SetRange(1,uiTotalSongs);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
