// VisWindow.cpp : implementation file
//

#include "stdafx.h"
#include "super jukebox.h"
#include "..\SNESAmp\SNESAmp.h"
#include "Globals.h"
#include "VisWindow.h"
#include "math.h"
#include "FFTLib.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

COLORREF colors[]=
{
	GetSysColor(COLOR_3DHIGHLIGHT),
	GetSysColor(COLOR_3DLIGHT),
	GetSysColor(COLOR_3DSHADOW),
	GetSysColor(COLOR_3DDKSHADOW),
	RGB(0,128,0),
	RGB(0,255,0),
	RGB(255,0,0),
	RGB(0,0,255),
	RGB(128,0,0),
	RGB(0,0,128),
};
struct
{
	LPCTSTR lpszName;
	int x,y;
}Columns[]=
{
	"Channel",0,0,
	"Active",0,0,
	"Key On",0,0,
	"Echo",0,0,
	"Pitch Mod.",0,0,
	"Noise",0,0,
	"Env. Type",0,0,
	"Envelope",0,0,
	"Pitch",0,0,
	"Volume",0,0,
	"Output",0,0,
};
enum	EnvM {Dec,Exp,Inc,Bent=6,Release=8,Sustain,Attack,Decay=13,Direct=15};
struct
{
	LPCTSTR lpszName;
	EnvM mode;
	COLORREF cr;
}EnvelopeTypes[]=
{
	"LinDec",Dec,RGB(0,128,0),
	"ExpDec",Exp,RGB(255,128,0),
	"LinInc",Inc,RGB(0,0,255),
	"BentInc",Bent,RGB(255,255,0),
	"Release",Release,RGB(255,0,255),
	"Sustain",Sustain,RGB(0,255,255),
	"Attack",Attack,RGB(255,0,0),
	"Decay",Decay,RGB(64,128,128),
	"Direct",Direct,RGB(255,187,119),
};
double log2(double i)
{
    double  d;

    _asm
    {
        fld  [i]
        fld1
        fyl2x
        fstp  [d]
        fdecstp
    }
    return(d);
}
int VUMeter(int VMax)
{
    int ip32=32;

    VMax>>=7;   //Divide VMax by 128
    if (VMax)         //Is VMax >= than 128 (-48db)?
    {
        _asm
        {
            fild    [VMax]      //Load integer into FPU
            fild    [ip32]       //Load 32 into FPU
            fyl2x           //Calculate Y*Log2(X) or 32*Log2(VMax)
            fistp   [VMax]  //Store integer result in VMax
            fdecstp   //Decrease FPU stack pointer
        }
    }
    else
        VMax=0; 

    return(VMax);
}
BOOL Line(HDC hdc,COLORREF cr,int nXStart,int nYStart,int nXEnd,int nYEnd)
{
	HPEN hPen=CreatePen(PS_SOLID,0,cr);
	HPEN hOldPen=(HPEN)SelectObject(hdc,hPen);
	if(!MoveToEx(hdc,nXStart,nYStart,NULL))return FALSE;
	if(!LineTo(hdc,nXEnd,nYEnd))return FALSE;
	SelectObject(hdc,hOldPen);
	DeleteObject(hPen);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CVisWindow

VIS_PARAMS CVisWindow::VP;
int CVisWindow::KillThread;
HDC CVisWindow::hdcWnd;
BOOL CVisWindow::bDrawAll,CVisWindow::bActive;
HDC CVisWindow::hdcGroup[10];
HPEN CVisWindow::Pens[10];
HBRUSH CVisWindow::Brushes[10];
int CVisWindow::iWidth,CVisWindow::iHeight,CVisWindow::iWaveWidth,CVisWindow::iWaveHeight;
CStatusBarCtrl *CVisWindow::m_StatusBar;

CVisWindow::CVisWindow()
{
	bActive=FALSE;
}

CVisWindow::~CVisWindow()
{
}

BOOL CVisWindow::Create(DWORD dwStyle,const RECT& rect,CWnd* pParentWnd,UINT nID)
{
	CWnd* pWnd = this;
	RECT rt;
	SetRect(&rt,rect.left,rect.top,rect.right,rect.top+VIS_HEIGHT);
	return pWnd->Create("VisWindow", NULL, dwStyle, rt, pParentWnd, nID);
}



BEGIN_MESSAGE_MAP(CVisWindow, CWnd)
	//{{AFX_MSG_MAP(CVisWindow)
	ON_WM_CREATE()
	ON_WM_SIZE()
	ON_WM_MOVE()
	ON_WM_PAINT()
	ON_WM_DESTROY()
	ON_WM_ERASEBKGND()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// CVisWindow message handlers

int CVisWindow::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	ASSERT(::IsWindow(m_hWnd));
	if(bActive)return -1;
	
	hdcWnd=GetDC()->GetSafeHdc();
	ASSERT(hdcWnd);

	THand=NULL;
	for(int i=0;i<sizeof(hdcGroup)/sizeof(hdcGroup[0]);i++)
		hdcGroup[i]=NULL;
	for(i=0;i<sizeof(hbmpGroup)/sizeof(hbmpGroup[0]);i++)
		hbmpGroup[i]=NULL;
	for(i=0;i<sizeof(colors)/sizeof(colors[0]);i++)
	{
		Pens[i]=CreatePen(PS_SOLID,0,colors[i]);
		Brushes[i]=CreateSolidBrush(colors[i]);
	}

	RECT rect;
	GetClientRect(&rect);
	for(i=0;i<8;i++)
	{
		if(!CheckBoxes[i].Create(NULL,WS_CHILD|WS_VISIBLE|BS_AUTOCHECKBOX,rect,this,i))
			MessageBox("Failed to create one of the check boxes.");
		if(reg.dwActiveChannels&(1<<i))
			CheckBoxes[i].SetCheck(TRUE);
	}
	SelectObject(hdcWnd,GetStockObject(ANSI_VAR_FONT));
	SetBkMode(hdcWnd,TRANSPARENT);
	for(i=0;i<sizeof(Columns)/sizeof(Columns[0]);i++)
	{
		SIZE size;
		if(!i)
			size.cx=0;
		else
			GetTextExtentPoint32(hdcWnd,Columns[i-1].lpszName,strlen(Columns[i-1].lpszName),&size);

		if(!i)
			Columns[i].x=2;
		else
			Columns[i].x=Columns[i-1].x+size.cx+5;
		Columns[i].y=2;
	}
	Columns[8].x=Columns[7].x+55;
	Columns[9].x=Columns[8].x+55;
	Columns[10].x=Columns[9].x+55;

	hdcGroup[0]=CreateCompatibleDC(hdcWnd);
	hbmpGroup[0]=CreateCompatibleBitmap(hdcWnd,50,13);
	SelectObject(hdcGroup[0],hbmpGroup[0]);
	DrawChannelGauge(0,8191,hdcGroup[0],0,0,50,13);
	hdcGroup[1]=CreateCompatibleDC(hdcWnd);
	hbmpGroup[1]=CreateCompatibleBitmap(hdcWnd,50,13);
	SelectObject(hdcGroup[1],hbmpGroup[1]);
	DrawChannelGauge(8191,8191,hdcGroup[1],0,0,50,13);
	hdcGroup[2]=CreateCompatibleDC(hdcWnd);
	hbmpGroup[2]=CreateCompatibleBitmap(hdcWnd,50,13);
	SelectObject(hdcGroup[2],hbmpGroup[2]);

	hdcGroup[3]=CreateCompatibleDC(hdcWnd);
	hbmpGroup[3]=CreateCompatibleBitmap(hdcWnd,100,13);
	SelectObject(hdcGroup[3],hbmpGroup[3]);
	DrawChannelGauge(0,32000,hdcGroup[3],0,0,100,13);
	hdcGroup[4]=CreateCompatibleDC(hdcWnd);
	hbmpGroup[4]=CreateCompatibleBitmap(hdcWnd,100,13);
	SelectObject(hdcGroup[4],hbmpGroup[4]);
	DrawChannelGauge(32000,32000,hdcGroup[4],0,0,100,13);
	hdcGroup[5]=CreateCompatibleDC(hdcWnd);
	hbmpGroup[5]=CreateCompatibleBitmap(hdcWnd,100,13);
	SelectObject(hdcGroup[5],hbmpGroup[5]);

	hwndParent=lpCreateStruct->hwndParent;
	bActive=TRUE;
	return 0;
}

void CVisWindow::OnDestroy() 
{
	CWnd::OnDestroy();
	
	// TODO: Add your message handler code here
	ASSERT(::IsWindow(m_hWnd));
	if(!bActive)return;
	
	Stop();
	for(int i=0;i<sizeof(colors)/sizeof(colors[0]);i++)
	{
		DeleteObject(Pens[i]);
		DeleteObject(Brushes[i]);
	}
	for(i=0;i<8;i++)
	{
		if(hdcGroup[i])
			DeleteDC(hdcGroup[i]);
		if(hbmpGroup[i])
			DeleteObject(hbmpGroup[i]);
	}
	bActive=FALSE;
}

void CVisWindow::OnSize(UINT nType, int cx, int cy) 
{
	CWnd::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	ASSERT(::IsWindow(m_hWnd));
	if(!bActive)return;

	iWidth=cx;
	iHeight=cy;
	iWaveWidth=iWidth-Columns[9].x-2;
	iWaveHeight=iHeight-19;
	if(iWaveWidth>0)
	{
		if(hdcGroup[6])DeleteDC(hdcGroup[6]);
		if(hbmpGroup[6])DeleteObject(hbmpGroup[6]);
		hdcGroup[6]=CreateCompatibleDC(hdcWnd);
		hbmpGroup[6]=CreateCompatibleBitmap(hdcWnd,iWaveWidth,iWaveHeight);
		SelectObject(hdcGroup[6],hbmpGroup[6]);
		if(hdcGroup[7])DeleteDC(hdcGroup[7]);
		if(hbmpGroup[7])DeleteObject(hbmpGroup[7]);
		hdcGroup[7]=CreateCompatibleDC(hdcWnd);
		hbmpGroup[7]=CreateCompatibleBitmap(hdcWnd,iWaveWidth,iWaveHeight);
		SelectObject(hdcGroup[7],hbmpGroup[7]);

		RECT rect;
		SetRect(&rect,0,0,iWaveWidth,iWaveHeight);
		FillRect(hdcGroup[6],&rect,(HBRUSH)GetStockObject(BLACK_BRUSH));
		for(int y=0;y<iWaveHeight/2;y+=2)
			for(int x=0;x<iWaveWidth;x+=2)
				SetPixel(hdcGroup[6],x,y,RGB(0,0,192));
		for(y=iWaveHeight/2;y<iWaveHeight;y+=2)
			for(int x=0;x<iWaveWidth;x+=2)
				SetPixel(hdcGroup[6],x,y,RGB(192,0,0));
	}
}

void CVisWindow::OnMove(int x, int y) 
{
	CWnd::OnMove(x, y);
	
	// TODO: Add your message handler code here
	ASSERT(::IsWindow(m_hWnd));
	if(!bActive)return;

	iXPos=x;
	iYPos=y;
	for(int i=0;i<8;i++)
		CheckBoxes[i].MoveWindow(Columns[1].x,i*14+16,13,13,FALSE);
}

void CVisWindow::OnPaint() 
{
	CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	ASSERT(::IsWindow(m_hWnd));
	if(!bActive)return;

	HDC hdc=dc.GetSafeHdc();

	HPEN hOldPen=(HPEN)SelectObject(hdc,Pens[2]);
	MoveToEx(hdc,0,0,NULL);
	LineTo(hdc,iWidth,0);
	SelectObject(hdc,Pens[0]);
	MoveToEx(hdc,0,iHeight-1,NULL);
	LineTo(hdc,iWidth,iHeight-1);
	SelectObject(hdc,hOldPen);

	HFONT hOldFont=(HFONT)SelectObject(hdc,GetStockObject(ANSI_VAR_FONT));
	SetTextColor(hdc,RGB(255,255,255));
	SetBkMode(hdc,TRANSPARENT);
	for(int i=0;i<sizeof(Columns)/sizeof(Columns[0]);i++)
		TextOut(hdc,Columns[i].x,Columns[i].y,Columns[i].lpszName,strlen(Columns[i].lpszName));
	SelectObject(hdc,hOldFont);

	if(bPlaying)Stop();
	bDrawAll=TRUE;
	Render();
	if(bPlaying)Start();
	// Do not call CWnd::OnPaint() for painting messages
}

WORD CVisWindow::GetSample(PVOID lpBuf,INT nSmp,INT nChn)
{
	int st=(reg.dwChannels==2&&nChn==1);
	signed short *p16=(signed short*)lpBuf;
	unsigned char *p8=(unsigned char*)lpBuf;

	return (reg.dwSampleSize==8)?(p8[nSmp*reg.dwChannels+st]<<8):(p16[nSmp*reg.dwChannels+st]^0x8000);
}

int CVisWindow::Render()
{
	if(!bActive)return -1;

	static VIS_PARAMS OldVP;
	static int OldActiveChannels;

	SNESAmp_GetVisParams(&VP);
	if(!bDrawAll&&VP.dwCount==OldVP.dwCount)
		return 1;

	int FrameSize=(reg.dwChannels-1)+(reg.dwSampleSize>>4);
	int NumSmp=VP.PCMBufferLength>>FrameSize;

	RECT rect;
	for(int i=0;i<8;i++)
	{
		if(bDrawAll||(reg.dwActiveChannels&(1<<i))!=(OldActiveChannels&(1<<i)))
		{
			char szBuf[2];
			sprintf(szBuf,"%d",i);
			SetTextColor(hdcWnd,colors[reg.dwActiveChannels&(1<<i)?5:4]);
			SetRect(&rect,Columns[0].x,i*14+16,Columns[1].x-1,i*14+29);
			FillRect(hdcWnd,&rect,(HBRUSH)GetStockObject(BLACK_BRUSH));
			TextOut(hdcWnd,Columns[0].x,i*14+16,szBuf,strlen(szBuf));
		}

		if(bDrawAll||(VP.DSP.KOn&(1<<i))!=(OldVP.DSP.KOn&(1<<i)))
		{
			SetRect(&rect,Columns[2].x,i*14+16,Columns[2].x+13,i*14+29);
			int br=reg.dwActiveChannels&(1<<i)&&VP.DSP.KOn&(1<<i)?5:4;
			FillRect(hdcWnd,&rect,Brushes[br]);
		}

		if(bDrawAll||(VP.DSP.EOn&(1<<i))!=(OldVP.DSP.EOn&(1<<i)))
		{
			SetRect(&rect,Columns[3].x,i*14+16,Columns[3].x+13,i*14+29);
			int br=reg.dwActiveChannels&(1<<i)&&VP.DSP.EOn&(1<<i)?5:4;
			FillRect(hdcWnd,&rect,Brushes[br]);
		}

		if(bDrawAll||(VP.DSP.PMod&(1<<i))!=(OldVP.DSP.PMod&(1<<i)))
		{
			SetRect(&rect,Columns[4].x,i*14+16,Columns[4].x+13,i*14+29);
			int br=reg.dwActiveChannels&(1<<i)&&VP.DSP.PMod&(1<<i)?5:4;
			FillRect(hdcWnd,&rect,Brushes[br]);
		}

		if(bDrawAll||(VP.DSP.NOn&(1<<i))!=(OldVP.DSP.NOn&(1<<i)))
		{
			SetRect(&rect,Columns[5].x,i*14+16,Columns[5].x+13,i*14+29);
			int br=reg.dwActiveChannels&(1<<i)&&VP.DSP.NOn&(1<<i)?5:4;
			FillRect(hdcWnd,&rect,Brushes[br]);
		}

		if(bDrawAll||VP.Mix[i].EMode!=OldVP.Mix[i].EMode)
		{
			char szBuf[20];
			for(int e=0;e<sizeof(EnvelopeTypes)/sizeof(EnvelopeTypes[0]);e++)
			{
				if(reg.dwActiveChannels&(1<<i)&&VP.Mix[i].EMode==EnvelopeTypes[e].mode)
				{
					sprintf(szBuf,"%s",EnvelopeTypes[e].lpszName);
					SetTextColor(hdcWnd,EnvelopeTypes[e].cr);
					break;
				}
				else if(!(reg.dwActiveChannels&(1<<i)))
				{
					sprintf(szBuf,"%s",EnvelopeTypes[0].lpszName);
					SetTextColor(hdcWnd,EnvelopeTypes[0].cr);
					break;
				}
			}
			SetRect(&rect,Columns[6].x,i*14+16,Columns[7].x-1,i*14+29);
			FillRect(hdcWnd,&rect,(HBRUSH)GetStockObject(BLACK_BRUSH));
			TextOut(hdcWnd,Columns[6].x,i*14+16,szBuf,strlen(szBuf));
		}

		if(bDrawAll||VP.Mix[i].EVal!=OldVP.Mix[i].EVal)
		{
			int w=(double)VP.Mix[i].EVal/8191.0*50.0;
			BitBlt(hdcGroup[2],0,0,50,13,hdcGroup[0],0,0,SRCCOPY);
			if(reg.dwActiveChannels&(1<<i))
				BitBlt(hdcGroup[2],0,0,w,13,hdcGroup[1],0,0,SRCCOPY);
			BitBlt(hdcWnd,Columns[7].x,i*14+16,50,13,hdcGroup[2],0,0,SRCCOPY);
		}

		if(bDrawAll||VP.Mix[i].PRate!=OldVP.Mix[i].PRate)
		{
			int w=(double)VP.Mix[i].PRate/130078.0*50.0;
			BitBlt(hdcGroup[2],0,0,50,13,hdcGroup[0],0,0,SRCCOPY);
			if(reg.dwActiveChannels&(1<<i))
				BitBlt(hdcGroup[2],0,0,w,13,hdcGroup[1],0,0,SRCCOPY);
			BitBlt(hdcWnd,Columns[8].x,i*14+16,50,13,hdcGroup[2],0,0,SRCCOPY);
		}

		if(bDrawAll||VP.Mix[i].VMaxL!=OldVP.Mix[i].VMaxL||VP.Mix[i].VMaxR!=OldVP.Mix[i].VMaxR)
		{
			int dB=VUMeter((VP.Mix[i].VMaxL+VP.Mix[i].VMaxR)/2);
			int w=(double)dB/60180.0*50.0;
			BitBlt(hdcGroup[2],0,0,50,13,hdcGroup[0],0,0,SRCCOPY);
			if(reg.dwActiveChannels&(1<<i))
				BitBlt(hdcGroup[2],0,0,w,13,hdcGroup[1],0,0,SRCCOPY);
			BitBlt(hdcWnd,Columns[9].x,i*14+16,50,13,hdcGroup[2],0,0,SRCCOPY);
		}
	}

	if(iWaveWidth>0)
	{
		BitBlt(hdcGroup[7],0,0,iWaveWidth,iWaveHeight,hdcGroup[6],0,0,SRCCOPY);
		if(VP.PCMBuffer!=NULL&&NumSmp>0)
		{
			int x,half=iWaveHeight/2;
			HPEN hOldPen;
			switch(reg.dwVisMode)
			{
			case 0:
				hOldPen=(HPEN)SelectObject(hdcGroup[7],Pens[7]);
				WORD wSmp;
				wSmp=GetSample(VP.PCMBuffer,0,0);
				MoveToEx(hdcGroup[7],0,wSmp/65535.0*half,NULL);
				for(x=0;x<iWaveWidth;x++)
				{
					wSmp=GetSample(VP.PCMBuffer,(double)x/iWaveWidth*NumSmp,0);
					LineTo(hdcGroup[7],x,wSmp/65535.0*half);
				}
				SelectObject(hdcGroup[7],Pens[6]);
				wSmp=GetSample(VP.PCMBuffer,0,1);
				MoveToEx(hdcGroup[7],0,wSmp/65535.0*half+half,NULL);
				for(x=0;x<iWaveWidth;x++)
				{
					wSmp=GetSample(VP.PCMBuffer,(double)x/iWaveWidth*NumSmp,1);
					LineTo(hdcGroup[7],x,wSmp/65535.0*half+half);
				}
				SelectObject(hdcGroup[7],hOldPen);
				break;

			case 1:
				UINT limit=1048576;
				float RealIn[1024],RealOut[1024],ImagOut[1024];

				for(x=0;x<1024;x++)
					RealIn[x]=(signed short)(GetSample(VP.PCMBuffer,(double)x/1024*NumSmp,0)^0x8000);
				fftFloat(1024,0,RealIn,NULL,RealOut,ImagOut);
				HPEN hOldPen=(HPEN)SelectObject(hdcGroup[7],Pens[7]);
				for(x=0;x<iWaveWidth;x++)
				{
					int idx=(double)x/iWaveWidth*(reg.dwSpectrumSize/100.0*512.0)+1;
					float f=sqrt(RealOut[idx]*RealOut[idx]+ImagOut[idx]*ImagOut[idx]);
					if(f>limit)f=limit;
					MoveToEx(hdcGroup[7],x,half-1,NULL);
					LineTo(hdcGroup[7],x,half-(f/limit*half)-1);
				}

				for(x=0;x<1024;x++)
					RealIn[x]=(signed short)(GetSample(VP.PCMBuffer,(double)x/1024*NumSmp,1)^0x8000);
				fftFloat(1024,0,RealIn,NULL,RealOut,ImagOut);
				SelectObject(hdcGroup[7],Pens[6]);
				for(x=0;x<iWaveWidth;x++)
				{
					int idx=(double)x/iWaveWidth*(reg.dwSpectrumSize/100.0*512.0)+1;
					float f=sqrt(RealOut[idx]*RealOut[idx]+ImagOut[idx]*ImagOut[idx]);
					if(f>limit)f=limit;
					MoveToEx(hdcGroup[7],x,iWaveHeight-1,NULL);
					LineTo(hdcGroup[7],x,iWaveHeight-(f/limit*half)-1);
				}
				SelectObject(hdcGroup[7],hOldPen);
				break;
			}
		}
		BitBlt(hdcWnd,Columns[10].x,16,iWaveWidth,iWaveHeight,hdcGroup[7],0,0,SRCCOPY);
	}

	OldActiveChannels=reg.dwActiveChannels;
	OldVP=VP;
	bDrawAll=FALSE;

	return 0;
}

UINT CVisWindow::Thread(LPVOID lpParameter)
{
	while(!KillThread)
	{
		Render();
		Sleep(10);
	}
	return 0;
}

void CVisWindow::Start()
{
	if(!bActive)return;

	if(!THand)
	{
		KillThread=0;
		THand=AfxBeginThread(Thread,0,reg.dwVisThreadPriority);
	}
}

void CVisWindow::Stop()
{
	if(!bActive)return;

	if(THand)
	{
		KillThread=1;
		if(WaitForSingleObject(THand->m_hThread,3000)==WAIT_TIMEOUT)
		{
			MessageBox("The visualization thread won't cooperate. Press OK to terminate.",NULL,MB_ICONERROR);
			TerminateThread(THand->m_hThread,0);
		}
		CloseHandle(THand->m_hThread);
		THand=NULL;
	}
}

void CVisWindow::Suspend()
{
	if(!bActive)return;

	if(THand)
		THand->SuspendThread();
}

void CVisWindow::Resume()
{
	if(!bActive)return;

	if(THand)
		THand->ResumeThread();
}

void CVisWindow::SetThreadPriority(DWORD dwPriority)
{
	if(THand)
		THand->SetThreadPriority(dwPriority);
}

void CVisWindow::DrawChannelGauge(int nSndVal,int nMax,HDC pDC, int nXPos, int nYPos, int nWidth, int nHeight)
{
	RECT rt;
	rt.left=nXPos;
	rt.top=nYPos;
	rt.right=nXPos+nWidth;
	rt.bottom=nYPos+nHeight;

	for(int x=rt.right;x>=rt.left;x--)
	{
		int r=0,g=0;
		r=(double)(x-nXPos)/nWidth*255-63;
		g=192-(double)(x-nXPos)/nWidth*255;
		if(r<0)r=0;
		if(g<0)g=0;
		Line(pDC,RGB(r,g,0),x,rt.top,x,rt.bottom);
	}
	
	if(nSndVal<0)nSndVal=0;
	else if(nSndVal>nMax)nSndVal=nMax;
	if(nSndVal>0)
	{
		rt.right=rt.left+(double)nSndVal/nMax*nWidth;
		for(x=rt.right;x>=rt.left;x--)
		{
			int r=0,g=0;
			r=(double)(x-nXPos)/nWidth*255;
			g=255-(double)(x-nXPos)/nWidth*255;
			if(r<0)r=0;
			if(g<0)g=0;
			Line(pDC,RGB(r,g,0),x,rt.top,x,rt.bottom);
		}
	}
}

BOOL CVisWindow::OnCommand(WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	ASSERT(::IsWindow(m_hWnd));

	if(HIWORD(wParam)==BN_CLICKED)
	{
		if(CheckBoxes[LOWORD(wParam)].GetCheck())reg.dwActiveChannels|=(1<<LOWORD(wParam));
		else reg.dwActiveChannels&=~(1<<LOWORD(wParam));
		SNESAmp_MuteChannels(~reg.dwActiveChannels);
		bDrawAll=TRUE;
		Render();
		return TRUE;
	}
	
	return CWnd::OnCommand(wParam, lParam);
}

BOOL CVisWindow::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	ASSERT(::IsWindow(m_hWnd));

	RECT rect;
	for(int i=0;i<8;i++)
	{
		SetRect(&rect,Columns[0].x,i*14+16,Columns[1].x-1,i*14+29);
		pDC->ExcludeClipRect(&rect);
		SetRect(&rect,Columns[2].x,i*14+16,Columns[2].x+13,i*14+29);
		pDC->ExcludeClipRect(&rect);
		SetRect(&rect,Columns[3].x,i*14+16,Columns[3].x+13,i*14+29);
		pDC->ExcludeClipRect(&rect);
		SetRect(&rect,Columns[4].x,i*14+16,Columns[4].x+13,i*14+29);
		pDC->ExcludeClipRect(&rect);
		SetRect(&rect,Columns[5].x,i*14+16,Columns[5].x+13,i*14+29);
		pDC->ExcludeClipRect(&rect);
		SetRect(&rect,Columns[6].x,i*14+16,Columns[7].x-1,i*14+29);
		pDC->ExcludeClipRect(&rect);
		SetRect(&rect,Columns[7].x,i*14+16,Columns[7].x+50,i*14+29);
		pDC->ExcludeClipRect(&rect);
		SetRect(&rect,Columns[8].x,i*14+16,Columns[8].x+50,i*14+29);
		pDC->ExcludeClipRect(&rect);
		SetRect(&rect,Columns[9].x,i*14+16,Columns[9].x+50,i*14+29);
		pDC->ExcludeClipRect(&rect);
	}

	if(iWaveWidth>0)
	{
		SetRect(&rect,Columns[10].x,16,Columns[10].x+iWaveWidth,16+iWaveHeight);
		pDC->ExcludeClipRect(&rect);
	}
	BOOL bRes=CWnd::OnEraseBkgnd(pDC);
	pDC->SelectClipRgn(NULL);
	return bRes;
}
