#include "stdafx.h"
#include "Globals.h"
#include "resource.h"
#include <vector>

int iCurrentSong=-1;
int iPlayingSong=-1;
int iSongLength=0;
int iFadeLength=0;
int iSongRepetitions=1;
int iSortMethod=-1;
bool bSortAscending=true;
bool bPaused;
bool bPlaying;
bool bNeedsSaving;
bool bArchived;
bool bLoadPlayList;
bool bDeleteSong;
char szPlayList[MAX_PATH];
char szCurrentSong[MAX_PATH];
char szPlaylistLocation[MAX_PATH];
char szProgramLocation[MAX_PATH];
BOOL fShowExtensions;
std::vector<SongEntry>seList1;
std::vector<SongEntry>seList2;
std::vector<SongEntry>seClipboard;
CString cstrOpenedPlaylist="Untitled";
CString cstrTitle="Super Jukebox - Untitled";
CRegistry reg;
ColumnInfo stColumnsInfo[NUMBER_OF_COLUMNS]=
{
	"Name",
	-1,
	TRUE,
	"File",
	-1,
	TRUE,
	"Title",
	-1,
	TRUE,
	"Game",
	-1,
	TRUE,
	"Artist",
	-1,
	TRUE,
	"Dumper",
	-1,
	TRUE,
	"Date",
	-1,
	TRUE,
	"Comment",
	-1,
	TRUE,
	"Length",
	-1,
	TRUE,
	"Fade",
	-1,
	TRUE,
	"Repetitions",
	-1,
	TRUE,
};
RULE LayoutRules[5][50]=
{
	{
		{lMOVE,    lLEFT(IDC_VIS_WINDOW),                  lLEFT(lPARENT),                 +0},
		{lMOVE,    lBOTTOM(IDC_VIS_WINDOW),                lTOP(IDC_STATUS_BAR),           +0},
		{lSTRETCH, lRIGHT(IDC_VIS_WINDOW),                 lRIGHT(lPARENT),                +0},
		{lMOVE,    lLEFT(IDC_STATUS_BAR),                  lLEFT(lPARENT),                 +0},
		{lMOVE,    lBOTTOM(IDC_STATUS_BAR),                lBOTTOM(lPARENT),               +0},
		{lSTRETCH, lRIGHT(IDC_STATUS_BAR),                 lRIGHT(lPARENT),                +0},
		{lEND},
	},
	{
		{lMOVE,    lLEFT(IDC_VIS_WINDOW),                  lLEFT(lPARENT),                 +0},
		{lMOVE,    lBOTTOM(IDC_VIS_WINDOW),                lTOP(IDC_STATUS_BAR),           +0},
		{lSTRETCH, lRIGHT(IDC_VIS_WINDOW),                 lRIGHT(lPARENT),                +0},
		{lMOVE,    lLEFT(IDC_STATUS_BAR),                  lLEFT(lPARENT),                 +0},
		{lMOVE,    lBOTTOM(IDC_STATUS_BAR),                lBOTTOM(lPARENT),               +0},
		{lSTRETCH, lRIGHT(IDC_STATUS_BAR),                 lRIGHT(lPARENT),                +0},
		{lMOVE,    lLEFT(IDC_BUTTON_REMOVE),               lLEFT(IDC_BUTTON_ADD),          +0},
		{lMOVE,    lLEFT(IDC_BUTTON_ADD_ALL),              lLEFT(IDC_BUTTON_ADD),          +0},
		{lMOVE,    lLEFT(IDC_BUTTON_REMOVE_ALL),           lLEFT(IDC_BUTTON_ADD),          +0},
		{lMOVE,    lLEFT(IDC_BUTTON_PLAY),                 lLEFT(IDC_BUTTON_ADD),          +0},
		{lMOVE,    lLEFT(IDC_BUTTON_PAUSE),                lLEFT(IDC_BUTTON_ADD),          +0},
		{lMOVE,    lLEFT(IDC_BUTTON_STOP),                 lLEFT(IDC_BUTTON_ADD),          +0},
		{lMOVE,    lLEFT(IDC_BUTTON_PREVIOUS),             lLEFT(IDC_BUTTON_ADD),          +0},
		{lMOVE,    lLEFT(IDC_BUTTON_NEXT),                 lLEFT(IDC_BUTTON_ADD),          +0},
		{lMOVE,    lTOP(IDC_BUTTON_REMOVE),                lBOTTOM(IDC_BUTTON_ADD),        +0},
		{lMOVE,    lTOP(IDC_BUTTON_ADD_ALL),               lBOTTOM(IDC_BUTTON_REMOVE),     +0},
		{lMOVE,    lTOP(IDC_BUTTON_REMOVE_ALL),            lBOTTOM(IDC_BUTTON_ADD_ALL),    +0},
		{lMOVE,    lTOP(IDC_BUTTON_PLAY),                  lBOTTOM(IDC_BUTTON_REMOVE_ALL), +0},
		{lMOVE,    lTOP(IDC_BUTTON_PAUSE),                 lBOTTOM(IDC_BUTTON_PLAY),       +0},
		{lMOVE,    lTOP(IDC_BUTTON_STOP),                  lBOTTOM(IDC_BUTTON_PAUSE),      +0},
		{lMOVE,    lTOP(IDC_BUTTON_PREVIOUS),              lBOTTOM(IDC_BUTTON_STOP),       +0},
		{lMOVE,    lTOP(IDC_BUTTON_NEXT),                  lBOTTOM(IDC_BUTTON_PREVIOUS),   +0},
		{lHCENTER, lGROUP(IDC_BUTTON_ADD,IDC_BUTTON_NEXT), lCHILD(lPARENT),                +0},
		{lVCENTER, lGROUP(IDC_BUTTON_ADD,IDC_BUTTON_NEXT), lCHILD(IDC_LIST_FILELIST),      +0},
		{lMOVE,    lLEFT(IDC_LIST_FILELIST),               lLEFT(lPARENT),                 +10},
		{lMOVE,    lTOP(IDC_LIST_FILELIST),                lTOP(lPARENT),                  +10},
		{lSTRETCH, lRIGHT(IDC_LIST_FILELIST),              lLEFT(IDC_BUTTON_ADD),          -10},
		{lSTRETCH, lBOTTOM(IDC_LIST_FILELIST),             lTOP(IDC_VIS_WINDOW),           -10},
		{lMOVE,    lLEFT(IDC_LIST_PLAYLIST),               lRIGHT(IDC_BUTTON_ADD),         +10},
		{lMOVE,    lTOP(IDC_LIST_PLAYLIST),                lTOP(lPARENT),                  +10},
		{lSTRETCH, lRIGHT(IDC_LIST_PLAYLIST),              lRIGHT(lPARENT),                -10},
		{lSTRETCH, lBOTTOM(IDC_LIST_PLAYLIST),             lBOTTOM(IDC_LIST_FILELIST),     -0},
		{lEND},
	},
	{
		{lMOVE,    lLEFT(IDC_VIS_WINDOW),                  lLEFT(lPARENT),                 +0},
		{lMOVE,    lBOTTOM(IDC_VIS_WINDOW),                lTOP(IDC_STATUS_BAR),           +0},
		{lSTRETCH, lRIGHT(IDC_VIS_WINDOW),                 lRIGHT(lPARENT),                +0},
		{lMOVE,    lLEFT(IDC_STATUS_BAR),                  lLEFT(lPARENT),                 +0},
		{lMOVE,    lBOTTOM(IDC_STATUS_BAR),                lBOTTOM(lPARENT),               +0},
		{lSTRETCH, lRIGHT(IDC_STATUS_BAR),                 lRIGHT(lPARENT),                +0},
		{lMOVE,    lLEFT(IDC_BUTTON_ADD),                  lLEFT(lPARENT),                 +10},
		{lMOVE,    lLEFT(IDC_BUTTON_REMOVE),               lLEFT(lPARENT),                 +10},
		{lMOVE,    lLEFT(IDC_BUTTON_ADD_ALL),              lLEFT(lPARENT),                 +10},
		{lMOVE,    lLEFT(IDC_BUTTON_REMOVE_ALL),           lLEFT(lPARENT),                 +10},
		{lMOVE,    lLEFT(IDC_BUTTON_PLAY),                 lLEFT(lPARENT),                 +10},
		{lMOVE,    lLEFT(IDC_BUTTON_PAUSE),                lLEFT(lPARENT),                 +10},
		{lMOVE,    lLEFT(IDC_BUTTON_STOP),                 lLEFT(lPARENT),                 +10},
		{lMOVE,    lLEFT(IDC_BUTTON_PREVIOUS),             lLEFT(lPARENT),                 +10},
		{lMOVE,    lLEFT(IDC_BUTTON_NEXT),                 lLEFT(lPARENT),                 +10},
		{lMOVE,    lTOP(IDC_BUTTON_ADD),                   lTOP(lPARENT),                  +10},
		{lMOVE,    lTOP(IDC_BUTTON_REMOVE),                lBOTTOM(IDC_BUTTON_ADD),        +0},
		{lMOVE,    lTOP(IDC_BUTTON_ADD_ALL),               lBOTTOM(IDC_BUTTON_REMOVE),     +0},
		{lMOVE,    lTOP(IDC_BUTTON_REMOVE_ALL),            lBOTTOM(IDC_BUTTON_ADD_ALL),    +0},
		{lMOVE,    lTOP(IDC_BUTTON_PLAY),                  lBOTTOM(IDC_BUTTON_REMOVE_ALL), +0},
		{lMOVE,    lTOP(IDC_BUTTON_PAUSE),                 lBOTTOM(IDC_BUTTON_PLAY),       +0},
		{lMOVE,    lTOP(IDC_BUTTON_STOP),                  lBOTTOM(IDC_BUTTON_PAUSE),      +0},
		{lMOVE,    lTOP(IDC_BUTTON_PREVIOUS),              lBOTTOM(IDC_BUTTON_STOP),       +0},
		{lMOVE,    lTOP(IDC_BUTTON_NEXT),                  lBOTTOM(IDC_BUTTON_PREVIOUS),   +0},
		{lMOVE,    lLEFT(IDC_LIST_FILELIST),               lRIGHT(IDC_BUTTON_ADD),         +10},
		{lMOVE,    lTOP(IDC_LIST_FILELIST),                lTOP(lPARENT),                  +10},
		{lSTRETCH, lRIGHT(IDC_LIST_FILELIST),              lRIGHT(lPARENT),                -10},
		{lSTRETCH, lBOTTOM(IDC_LIST_FILELIST),             lBOTTOM(IDC_BUTTON_NEXT),       +0},
		{lMOVE,    lLEFT(IDC_LIST_PLAYLIST),               lLEFT(lPARENT),                 +10},
		{lMOVE,    lTOP(IDC_LIST_PLAYLIST),                lBOTTOM(IDC_BUTTON_NEXT),       +10},
		{lSTRETCH, lRIGHT(IDC_LIST_PLAYLIST),              lRIGHT(lPARENT),                -10},
		{lSTRETCH, lBOTTOM(IDC_LIST_PLAYLIST),             lTOP(IDC_VIS_WINDOW),           -10},
		{lEND},
	},
	{
		{lMOVE,    lLEFT(IDC_VIS_WINDOW),                  lLEFT(lPARENT),                 +0},
		{lMOVE,    lBOTTOM(IDC_VIS_WINDOW),                lTOP(IDC_STATUS_BAR),           +0},
		{lSTRETCH, lRIGHT(IDC_VIS_WINDOW),                 lRIGHT(lPARENT),                +0},
		{lMOVE,    lLEFT(IDC_STATUS_BAR),                  lLEFT(lPARENT),                 +0},
		{lMOVE,    lBOTTOM(IDC_STATUS_BAR),                lBOTTOM(lPARENT),               +0},
		{lSTRETCH, lRIGHT(IDC_STATUS_BAR),                 lRIGHT(lPARENT),                +0},
		{lMOVE,    lLEFT(IDC_BUTTON_ADD),                  lLEFT(lPARENT),                 +10},
		{lMOVE,    lLEFT(IDC_BUTTON_REMOVE),               lLEFT(lPARENT),                 +10},
		{lMOVE,    lLEFT(IDC_BUTTON_ADD_ALL),              lLEFT(lPARENT),                 +10},
		{lMOVE,    lLEFT(IDC_BUTTON_REMOVE_ALL),           lLEFT(lPARENT),                 +10},
		{lMOVE,    lLEFT(IDC_BUTTON_PLAY),                 lLEFT(lPARENT),                 +10},
		{lMOVE,    lLEFT(IDC_BUTTON_PAUSE),                lLEFT(lPARENT),                 +10},
		{lMOVE,    lLEFT(IDC_BUTTON_STOP),                 lLEFT(lPARENT),                 +10},
		{lMOVE,    lLEFT(IDC_BUTTON_PREVIOUS),             lLEFT(lPARENT),                 +10},
		{lMOVE,    lLEFT(IDC_BUTTON_NEXT),                 lLEFT(lPARENT),                 +10},
		{lMOVE,    lTOP(IDC_BUTTON_REMOVE),                lBOTTOM(IDC_BUTTON_ADD),        +0},
		{lMOVE,    lTOP(IDC_BUTTON_ADD_ALL),               lBOTTOM(IDC_BUTTON_REMOVE),     +0},
		{lMOVE,    lTOP(IDC_BUTTON_REMOVE_ALL),            lBOTTOM(IDC_BUTTON_ADD_ALL),    +0},
		{lMOVE,    lTOP(IDC_BUTTON_PLAY),                  lBOTTOM(IDC_BUTTON_REMOVE_ALL), +0},
		{lMOVE,    lTOP(IDC_BUTTON_PAUSE),                 lBOTTOM(IDC_BUTTON_PLAY),       +0},
		{lMOVE,    lTOP(IDC_BUTTON_STOP),                  lBOTTOM(IDC_BUTTON_PAUSE),      +0},
		{lMOVE,    lTOP(IDC_BUTTON_PREVIOUS),              lBOTTOM(IDC_BUTTON_STOP),       +0},
		{lMOVE,    lTOP(IDC_BUTTON_NEXT),                  lBOTTOM(IDC_BUTTON_PREVIOUS),   +0},
		{lVCENTER, lGROUP(IDC_BUTTON_ADD,IDC_BUTTON_NEXT), lCHILD(IDC_LIST_FILELIST),      +0},
		{lMOVE,    lLEFT(IDC_LIST_FILELIST),               lRIGHT(IDC_BUTTON_ADD),         +10},
		{lMOVE,    lTOP(IDC_LIST_FILELIST),                lTOP(lPARENT),                  +10},
		{lSTRETCH, lRIGHT(IDC_LIST_FILELIST),              lWIDTHOF(lPARENT,25),           +0},
		{lSTRETCH, lBOTTOM(IDC_LIST_FILELIST),             lTOP(IDC_VIS_WINDOW),           -10},
		{lMOVE,    lLEFT(IDC_LIST_PLAYLIST),               lRIGHT(IDC_LIST_FILELIST),      +10},
		{lMOVE,    lTOP(IDC_LIST_PLAYLIST),                lTOP(lPARENT),                  +10},
		{lSTRETCH, lRIGHT(IDC_LIST_PLAYLIST),              lRIGHT(lPARENT),                -10},
		{lSTRETCH, lBOTTOM(IDC_LIST_PLAYLIST),             lTOP(IDC_VIS_WINDOW),           -10},
		{lEND},
	},
	{
		{lMOVE,    lLEFT(IDC_VIS_WINDOW),                  lLEFT(lPARENT),                 +0},
		{lMOVE,    lBOTTOM(IDC_VIS_WINDOW),                lTOP(IDC_STATUS_BAR),           +0},
		{lSTRETCH, lRIGHT(IDC_VIS_WINDOW),                 lRIGHT(lPARENT),                +0},
		{lMOVE,    lLEFT(IDC_STATUS_BAR),                  lLEFT(lPARENT),                 +0},
		{lMOVE,    lBOTTOM(IDC_STATUS_BAR),                lBOTTOM(lPARENT),               +0},
		{lSTRETCH, lRIGHT(IDC_STATUS_BAR),                 lRIGHT(lPARENT),                +0},
		{lMOVE,    lLEFT(IDC_BUTTON_REMOVE),               lRIGHT(IDC_BUTTON_ADD),         +0},
		{lMOVE,    lLEFT(IDC_BUTTON_ADD_ALL),              lRIGHT(IDC_BUTTON_REMOVE),      +0},
		{lMOVE,    lLEFT(IDC_BUTTON_REMOVE_ALL),           lRIGHT(IDC_BUTTON_ADD_ALL),     +0},
		{lMOVE,    lLEFT(IDC_BUTTON_PLAY),                 lRIGHT(IDC_BUTTON_REMOVE_ALL),  +0},
		{lMOVE,    lLEFT(IDC_BUTTON_PAUSE),                lRIGHT(IDC_BUTTON_PLAY),        +0},
		{lMOVE,    lLEFT(IDC_BUTTON_STOP),                 lRIGHT(IDC_BUTTON_PAUSE),       +0},
		{lMOVE,    lLEFT(IDC_BUTTON_PREVIOUS),             lRIGHT(IDC_BUTTON_STOP),        +0},
		{lMOVE,    lLEFT(IDC_BUTTON_NEXT),                 lRIGHT(IDC_BUTTON_PREVIOUS),    +0},
		{lMOVE,    lTOP(IDC_BUTTON_ADD),                   lTOP(lPARENT),                  +10},
		{lMOVE,    lTOP(IDC_BUTTON_REMOVE),                lTOP(lPARENT),                  +10},
		{lMOVE,    lTOP(IDC_BUTTON_ADD_ALL),               lTOP(lPARENT),                  +10},
		{lMOVE,    lTOP(IDC_BUTTON_REMOVE_ALL),            lTOP(lPARENT),                  +10},
		{lMOVE,    lTOP(IDC_BUTTON_PLAY),                  lTOP(lPARENT),                  +10},
		{lMOVE,    lTOP(IDC_BUTTON_PAUSE),                 lTOP(lPARENT),                  +10},
		{lMOVE,    lTOP(IDC_BUTTON_STOP),                  lTOP(lPARENT),                  +10},
		{lMOVE,    lTOP(IDC_BUTTON_PREVIOUS),              lTOP(lPARENT),                  +10},
		{lMOVE,    lTOP(IDC_BUTTON_NEXT),                  lTOP(lPARENT),                  +10},
		{lHCENTER, lGROUP(IDC_BUTTON_ADD,IDC_BUTTON_NEXT), lCHILD(lPARENT),                +0},
		{lMOVE,    lLEFT(IDC_LIST_FILELIST),               lLEFT(lPARENT),                 +10},
		{lMOVE,    lTOP(IDC_LIST_FILELIST),                lBOTTOM(IDC_BUTTON_ADD),        +10},
		{lSTRETCH, lRIGHT(IDC_LIST_FILELIST),              lRIGHT(lPARENT),                -10},
		{lSTRETCH, lBOTTOM(IDC_LIST_FILELIST),             lHEIGHTOF(lPARENT,35)           +0},
		{lMOVE,    lLEFT(IDC_LIST_PLAYLIST),               lLEFT(lPARENT),                 +10},
		{lMOVE,    lTOP(IDC_LIST_PLAYLIST),                lBOTTOM(IDC_LIST_FILELIST),     +10},
		{lSTRETCH, lRIGHT(IDC_LIST_PLAYLIST),              lRIGHT(lPARENT),                -10},
		{lSTRETCH, lBOTTOM(IDC_LIST_PLAYLIST),             lTOP(IDC_VIS_WINDOW),           -10},
		{lEND},
	},
};

#ifdef UNIMPORTED_UNRAR_DLL
pfnRAROpenArchive _RAROpenArchive;
pfnRARCloseArchive _RARCloseArchive;
pfnRARReadHeader _RARReadHeader;
pfnRARProcessFile _RARProcessFile;
pfnRARSetChangeVolProc _RARSetChangeVolProc;
pfnRARSetProcessDataProc _RARSetProcessDataProc;
pfnRARSetPassword _RARSetPassword;
#endif
#ifdef UNIMPORTED_UNACE_DLL
pfnACEOpenArchive _ACEOpenArchive;
pfnACECloseArchive _ACECloseArchive;
pfnACEReadHeader _ACEReadHeader;
pfnACEProcessFile _ACEProcessFile;
pfnACESetPassword _ACESetPassword;
#endif

DWORD _GetLongPathName(LPCTSTR lpszShortPath,LPTSTR lpszLongPath,DWORD cchBuffer)
{
	TCHAR szBuf[MAX_PATH];
	HINSTANCE hInstDll;
	DWORD dwRes=0;

	strncpy(lpszLongPath,lpszShortPath,cchBuffer);

	hInstDll=LoadLibrary("KERNEL32.DLL");
	if(hInstDll)
	{
		GETLONGPATHNAMEPROC pGetLongPathName;
		pGetLongPathName=(GETLONGPATHNAMEPROC)GetProcAddress(hInstDll,"GetLongPathNameA");
		if(pGetLongPathName)
		{
			dwRes=(*pGetLongPathName)(lpszShortPath,szBuf,MAX_PATH);
			if(dwRes)
				strncpy(lpszLongPath,szBuf,cchBuffer);
		}
		FreeLibrary(hInstDll);
	}
	return dwRes;
}

bool operator<(const SongEntry & se1, const SongEntry & se2)
{
	return stricmp(se1.szName,se2.szName)<0?true:false;
}

void ConvertTimeUp(int iSeconds, LPSTR lpszBuffer)
{
	int iDay,iHour,iMinute,iSecond;
	iMinute=iSeconds/60;
	iSecond=iSeconds%60;
	iHour=iMinute/60;
	iMinute=iMinute%60;
	iDay=iHour/24;
	iHour=iHour%24;
	
	if(iDay>0)
		sprintf(lpszBuffer,"%d:%02d:%02d:%02d",iDay,iHour,iMinute,iSecond);
	else if(iHour>0)
		sprintf(lpszBuffer,"%d:%02d:%02d",iHour,iMinute,iSecond);
	else if(iMinute>0)
		sprintf(lpszBuffer,"%d:%02d",iMinute,iSecond);
	else if(iSecond>0)
		sprintf(lpszBuffer,"%d",iSecond);
	else
		sprintf(lpszBuffer,"0");
}

int ConvertTimeDown(LPCTSTR lpszBuffer)
{
	int iDay=0,iHour=0,iMinute=0,iSecond=0,iIndex=0,iEntries=0;
	char szBuf[500];

	for(int i=0;i<strlen(lpszBuffer)+1;i++)
		if(lpszBuffer[i]==':'||lpszBuffer[i]=='\0')iEntries++;
	for(i=0;i<strlen(lpszBuffer)+1;i++)
	{
		szBuf[iIndex]=lpszBuffer[i];
		if(lpszBuffer[i]==':'||lpszBuffer[i]=='\0')
		{
			szBuf[iIndex]='\0';
			switch(iEntries)
			{
			case 1:iSecond=atoi(szBuf);break;
			case 2:iMinute=atoi(szBuf);break;
			case 3:iHour=atoi(szBuf);break;
			case 4:iDay=atoi(szBuf);break;
			}
			if(iEntries==1)
				break;
			iIndex=0;iEntries--;
		}
		else iIndex++;
	}

	return iDay*86400+iHour*3600+iMinute*60+iSecond;
}

BOOL IsInRange(int i0,int i1,int iRange)
{
	return (i0>=i1-iRange&&i0<=i1+iRange);
}

BOOL IsFileTypeRegistered(LPCTSTR lpszExtension)
{
	char szBuffer[5000];
	sprintf(szBuffer,"%s%s","SOFTWARE\\CLASSES\\",lpszExtension);
	HKEY hKey;
	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE,szBuffer,0,KEY_ALL_ACCESS,&hKey)==ERROR_SUCCESS)
	{
		RegCloseKey(hKey);
		return TRUE;
	}
	return FALSE;
}

BOOL IsOverlapped(RECT rtSrc,int iCount,int iSkip,RECT rtDest[20])
{
	for(int i=0;i<iCount;i++)
		if(i!=iSkip)
		{
			RECT rtSpare;
			if(IntersectRect(&rtSpare,&rtSrc,&rtDest[i]))
				return TRUE;
		}
	return FALSE;
}

void AdjustRect(RECT *rtSrc,RECT rtDest,BOOL bMove,BOOL bSize)
{
	if(bMove)
	{
		if(rtSrc->left<0){rtSrc->right=rtSrc->right-rtSrc->left;rtSrc->left=0;}
		if(rtSrc->top<0){rtSrc->bottom=rtSrc->bottom-rtSrc->top;rtSrc->top=0;}
		if(rtSrc->right>rtDest.right){rtSrc->left=rtDest.right-(rtSrc->right-rtSrc->left);rtSrc->right=rtDest.right;}
		if(rtSrc->bottom>rtDest.bottom){rtSrc->top=rtDest.bottom-(rtSrc->bottom-rtSrc->top);rtSrc->bottom=rtDest.bottom;}
	}
	if(bSize)
	{
		if(rtSrc->right-rtSrc->left<29)rtSrc->right=rtSrc->left+29;
		if(rtSrc->bottom-rtSrc->top<29)rtSrc->bottom=rtSrc->top+29;
		if(rtSrc->right>rtDest.right)rtSrc->right=rtDest.right;
		if(rtSrc->bottom>rtDest.bottom)rtSrc->bottom=rtDest.bottom;
	}
}

void TrimString(LPTSTR lpszString)
{
	for(int i=0;i<strlen(lpszString);i++)
		if(lpszString[i]=='\n'||lpszString[i]=='\r')
		{lpszString[i]='\0';break;}
}
