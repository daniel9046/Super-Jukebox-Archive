// Super JukeboxDlg.cpp : implementation file
//

#include "stdafx.h"
#include "Super Jukebox.h"
#include "Super JukeboxDlg.h"
#include "AddFilesDlg.h"
#include "FindDlg.h"
#include "ConfigSheet.h"
#include "Extractors.h"
#include "Unace.h"
#include "Unrar.h"
#include "Unzip.h"
#include "VisWindow.h"
#include "..\SNESAmp\SNESAmp.h"
#include "Msg.h"
#include "Layout.h"
#include <mmsystem.h>
#include <stack>
#include <algorithm>
#include <direct.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

extern CSuperJukeboxApp theApp;
extern Message msgs;

/////////////////////////////////////////////////////////////////////////////
// CAboutDlg dialog used for App About

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialog Data
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	//{{AFX_MSG(CAboutDlg)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSuperJukeboxDlg dialog

CSuperJukeboxDlg::CSuperJukeboxDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSuperJukeboxDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSuperJukeboxDlg)
	hDCSkin=hDCAdjustedSkin=NULL;
	hBmpSkin=hBmpAdjustedSkin=NULL;
	iPageJump=0;
	cstrOldSkinFile="";
	dwMouseButtons=0;
	bInternalCall=FALSE;
	//}}AFX_DATA_INIT
	// Note that LoadIcon does not require a subsequent DestroyIcon in Win32
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CSuperJukeboxDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSuperJukeboxDlg)
	DDX_Control(pDX, IDC_BUTTON_ADD, m_ctlButton1);
	DDX_Control(pDX, IDC_BUTTON_REMOVE, m_ctlButton2);
	DDX_Control(pDX, IDC_BUTTON_ADD_ALL, m_ctlButton3);
	DDX_Control(pDX, IDC_BUTTON_REMOVE_ALL, m_ctlButton4);
	DDX_Control(pDX, IDC_BUTTON_PLAY, m_ctlButton5);
	DDX_Control(pDX, IDC_BUTTON_PAUSE, m_ctlButton6);
	DDX_Control(pDX, IDC_BUTTON_STOP, m_ctlButton7);
	DDX_Control(pDX, IDC_BUTTON_PREVIOUS, m_ctlButton8);
	DDX_Control(pDX, IDC_BUTTON_NEXT, m_ctlButton9);
	DDX_Control(pDX, IDC_LIST_FILELIST, m_ctlList1);
	DDX_Control(pDX, IDC_LIST_PLAYLIST, m_ctlList2);
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CSuperJukeboxDlg, CDialog)
	//{{AFX_MSG_MAP(CSuperJukeboxDlg)
	ON_WM_SYSCOMMAND()
	ON_WM_DESTROY()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDC_BUTTON_ADD, OnButtonAdd)
	ON_BN_CLICKED(IDC_BUTTON_REMOVE, OnButtonRemove)
	ON_BN_CLICKED(IDC_BUTTON_ADD_ALL, OnButtonAddAll)
	ON_BN_CLICKED(IDC_BUTTON_REMOVE_ALL, OnButtonRemoveAll)
	ON_BN_CLICKED(IDC_BUTTON_PLAY, OnButtonPlay)
	ON_BN_CLICKED(IDC_BUTTON_PAUSE, OnButtonPause)
	ON_BN_CLICKED(IDC_BUTTON_STOP, OnButtonStop)
	ON_BN_CLICKED(IDC_BUTTON_PREVIOUS, OnButtonPrevious)
	ON_BN_CLICKED(IDC_BUTTON_NEXT, OnButtonNext)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_LIST_FILELIST, OnItemchangedList1)
	ON_NOTIFY(LVN_ITEMCHANGED, IDC_LIST_PLAYLIST, OnItemchangedList2)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_PLAYLIST, OnDblclkList2)
	ON_NOTIFY(NM_DBLCLK, IDC_LIST_FILELIST, OnDblclkList1)
	ON_NOTIFY(NM_SETFOCUS, IDC_LIST_FILELIST, OnSetfocusList1)
	ON_NOTIFY(NM_SETFOCUS, IDC_LIST_PLAYLIST, OnSetfocusList2)
	ON_NOTIFY(LVN_KEYDOWN, IDC_LIST_PLAYLIST, OnKeydownList2)
	ON_WM_TIMER()
	ON_NOTIFY(NM_RCLICK, IDC_LIST_PLAYLIST, OnRclickList2)
	ON_WM_ERASEBKGND()
	ON_WM_SIZE()
	ON_NOTIFY(LVN_COLUMNCLICK, IDC_LIST_PLAYLIST, OnColumnclickList2)
	ON_WM_QUERYENDSESSION()
	ON_WM_ENDSESSION()
	ON_WM_MOUSEMOVE()
	ON_WM_LBUTTONDOWN()
	ON_WM_LBUTTONUP()
	ON_COMMAND(ID_FILE_NEW, OnFileNew)
	ON_COMMAND(ID_FILE_OPEN, OnFileOpen)
	ON_COMMAND(ID_FILE_SAVE, OnFileSave)
	ON_COMMAND(ID_FILE_SAVEAS, OnFileSaveAs)
	ON_COMMAND(ID_FILE_PROPERTIES, OnFileProperties)
	ON_COMMAND(ID_FILE_EXIT, OnFileExit)
	ON_COMMAND(ID_EDIT_CUT, OnEditCut)
	ON_COMMAND(ID_EDIT_COPY, OnEditCopy)
	ON_COMMAND(ID_EDIT_PASTE, OnEditPaste)
	ON_COMMAND(ID_EDIT_DELETE, OnEditDelete)
	ON_COMMAND(ID_EDIT_SELECTALL, OnEditSelectAll)
	ON_COMMAND(ID_EDIT_FIND, OnEditFind)
	ON_COMMAND(ID_EDIT_GOTO, OnEditGoTo)
	ON_COMMAND(ID_VIEW_REFRESH, OnViewRefresh)
	ON_COMMAND(ID_VIEW_PROPERTIES, OnViewProperties)
	ON_COMMAND(ID_SETTINGS_CONFIGURE, OnSettingsConfigure)
	ON_COMMAND(ID_HELP_CONTENTS, OnHelpContents)
	ON_COMMAND(ID_HELP_ABOUTSUPERJUKEBOX, OnHelpAboutSuperJukebox)
	ON_COMMAND(ID_VIEW_HIDEWINDOWS, OnViewHideWindows)
	ON_WM_GETMINMAXINFO()
	ON_WM_DRAWITEM()
	ON_WM_MENUSELECT()
	ON_WM_INITMENU()
	ON_NOTIFY(NM_CLICK, IDC_STATUS_BAR, OnClickStatusBar)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSuperJukeboxDlg message handlers

BOOL CSuperJukeboxDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon
	
	// TODO: Add extra initialization here
	bDebug=FALSE;

	if(bDebug)MessageBox("Following will be a series of message boxes announcing what Super Jukebox is about to do...");
	if(bDebug)MessageBox("About to load registry settings.");
	reg.Load();

	if(bDebug)MessageBox("About to set priority levels.");
	SetPriorityClass(GetCurrentProcess(),reg.dwPriorityClass);
	SNESAmp_SetMixingThreadPriority(reg.dwMixingThreadPriority);
	if(bDebug)MessageBox("About to mute appropriate channels.");
	SNESAmp_MuteChannels(~reg.dwActiveChannels);

	if(bDebug)MessageBox("About to load cursors.");
	hCursor0=LoadCursor(NULL,IDC_SIZEWE);
	hCursor1=LoadCursor(NULL,IDC_SIZENS);
	ASSERT(hCursor0&&hCursor1);

	if(bDebug)MessageBox("About to load playlist popup menu.");
	if(!cMenu1.LoadMenu(MAKEINTRESOURCE(IDR_MENU1)))
	{
		MessageBox("Cannot load resource: IDR_MENU1",NULL,MB_ICONERROR);
		DestroyWindow();
	}

	if(bDebug)MessageBox("About to clear file list and playlist.");
	seList1.clear();
	seList2.clear();
	if(bDebug)MessageBox("About to change current directory.");
	chdir(reg.szLastDirectory);
	if(bDebug)MessageBox("About to load file list.");
	if(LoadFileList())
	{
		MessageBox("Out of memory!",NULL,MB_ICONERROR);
		DestroyWindow();
	}

	if(bLoadPlayList)
	{
		if(bDebug)MessageBox("About to load playlist (0).");
		if(LoadPlayList(szPlayList))
			bLoadPlayList=FALSE;
	}
	else if(reg.bAutoLoadPlaylist)
	{
		if(bDebug)MessageBox("About to load playlist (1).");
		WIN32_FIND_DATA w32FindData;
		HANDLE hFindFile;
		if((hFindFile=FindFirstFile(reg.szLastPlaylist,&w32FindData))!=INVALID_HANDLE_VALUE)
		{
			FindClose(hFindFile);
			if(!LoadPlayList(reg.szLastPlaylist))
				bLoadPlayList=TRUE;
		}
	}

	if(bDebug)MessageBox("About to load skin.");
	LoadSkin(PlaylistPropsDlg.m_cstrSkinFile);

	RECT rect;
	GetClientRect(&rect);

	if(bDebug)MessageBox("About to create status bar.");
	m_StatusBar.Create(WS_CHILD|WS_VISIBLE,rect,this,IDC_STATUS_BAR);

	if(bDebug)MessageBox("About to create visualization window (if enabled).");
	if(reg.bShowVisWindow&&!m_VisWindow.Create(WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN,rect,this,IDC_VIS_WINDOW))
		MessageBox("Failed to create the vis window.",AfxGetApp()->m_pszAppName,MB_ICONERROR);
	m_VisWindow.m_StatusBar=&m_StatusBar;
	if(reg.bActiveWallpaper&&!m_ActiveWallpaper.LoadPlugin("aw_disco.dll"))
		MessageBox("Failed to load the Active Wallpaper plugin (aw_disco.dll).",AfxGetApp()->m_pszAppName,MB_ICONERROR);
	m_ActiveWallpaper.m_StatusBar=&m_StatusBar;
	
	btns[0]=&m_ctlButton1;
	btns[1]=&m_ctlButton2;
	btns[2]=&m_ctlButton3;
	btns[3]=&m_ctlButton4;
	btns[4]=&m_ctlButton5;
	btns[5]=&m_ctlButton6;
	btns[6]=&m_ctlButton7;
	btns[7]=&m_ctlButton8;
	btns[8]=&m_ctlButton9;

	UINT BtnIDs[]={IDI_ADD,IDI_REMOVE,IDI_ADDALL,IDI_REMOVEALL,IDI_PLAY,IDI_PAUSE,IDI_STOP,IDI_PREVIOUS,IDI_NEXT};
	
	if(bDebug)MessageBox("About to set bitmaps to buttons.");
	for(int i=0;i<NUMBER_OF_BUTTONS;i++)
	{
		btns[i]->ModifyStyle(0,BS_ICON);
		btns[i]->SetIcon(::LoadIcon(AfxGetApp()->m_hInstance,MAKEINTRESOURCE(BtnIDs[i])));
		if(!reg.dwButtonStyle)
			btns[i]->ModifyStyle(BS_ICON,0);
		else
			btns[i]->SetWindowText("");
		RECT rt;
		btns[i]->GetWindowRect(&rt);
		SetWindowLong(btns[i]->m_hWnd,GWL_USERDATA,MAKELONG(rt.right-rt.left,rt.bottom-rt.top));
	}
		
	if(bDebug)MessageBox("About to position controls.");
	PositionControls(0xFF);

	if(bDebug)MessageBox("About to set extended styles for list views.");
	DWORD dwFlags=0;
	dwFlags|=reg.bFullRowSelect?LVS_EX_FULLROWSELECT:0;
	dwFlags|=reg.bShowGridlines?LVS_EX_GRIDLINES:0;
	m_ctlList1.SetExtendedStyle(dwFlags);
	m_ctlList2.SetExtendedStyle(dwFlags);

	if(bDebug)MessageBox("About to attach system image list to the file list window.");
	SHFILEINFO sfi;
	HIMAGELIST himlSystem=(HIMAGELIST)SHGetFileInfo("*.*",FILE_ATTRIBUTE_NORMAL,&sfi,sizeof(sfi),SHGFI_SMALLICON|SHGFI_SYSICONINDEX|SHGFI_USEFILEATTRIBUTES);
	if(!ImageList_GetImageCount(himlSystem))
		MessageBox("Failed to retrieve the system icon image list.");
	pSmallSysImage=new CImageList();
	if(pSmallSysImage==NULL)
		MessageBox("Failed to create a new CImageList object.");
	if(!pSmallSysImage->Attach(himlSystem))
		MessageBox("Failed to attach the system icon image list.");
	m_ctlList1.SetImageList(pSmallSysImage,LVSIL_SMALL);
	
	if(bDebug)MessageBox("About to create playlist column header image list.");
	pImageHdrSmall=new CImageList();
	if(pImageHdrSmall==NULL)
		MessageBox("Failed to create a new CImageList object");
	if(!pImageHdrSmall->Create(IDB_BITMAP1,13,0,RGB(255,0,0)))
		MessageBox("Failed to create a new image list.");

	if(bDebug)MessageBox("About to attach image list to the playlist column header.");
	CHeaderCtrl* pHdrCtrl=m_ctlList2.GetHeaderCtrl();
	if(pHdrCtrl==NULL)
		MessageBox("Failed to retrieve the header control for the playlist view.");
	pHdrCtrl->SetImageList(pImageHdrSmall);

	if(bDebug)MessageBox("About to update playlist column widths.");
	for(i=0;i<NUMBER_OF_COLUMNS;i++)
	{
		if(i==0&&reg.stColumnsInfo[i].iWidth==-1)
		{
			m_ctlList1.GetWindowRect(&rect);
			reg.stColumnsInfo[i].iWidth=rect.right-rect.left-4;
		}
		else if(reg.stColumnsInfo[i].iWidth==-1)
			reg.stColumnsInfo[i].iWidth=m_ctlList2.GetStringWidth(reg.stColumnsInfo[i].szName)+12;
	}
	UpdateListColumns();

	if(bDebug)MessageBox("About to refresh file list.");
	if(seList1.size())
	{
		UpdateList1();
		HighlightListEntry(m_ctlList1,iCurrentFileSelection=0);
	}
	if(bDebug)MessageBox("About to refresh playlist.");
	if(seList2.size())
	{
		UpdateList2();
		HighlightListEntry(m_ctlList2,iCurrentSong=0);
	}

	if(bDebug)MessageBox("About to modify caption style for main window (if needed).");
	if(!reg.bShowTitleBar)
		ModifyStyle(WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX|WS_MAXIMIZEBOX,0);

	if(bDebug)MessageBox("About to update caption.");
	UpdateTitleBar();
	if(bDebug)MessageBox("About to update button states.");
	UpdateButtonStates();

	if(bDebug)MessageBox("About to update controls layout.");
	UpdateLayout(reg.bShowVisWindow);
	if(bDebug)MessageBox("About to modify visibility styles for the controls.");
	m_ctlList1.ModifyStyle(reg.bShowControls?0:WS_VISIBLE,reg.bShowControls?WS_VISIBLE:0);
	m_ctlList2.ModifyStyle(reg.bShowControls?0:WS_VISIBLE,reg.bShowControls?WS_VISIBLE:0);
	for(i=0;i<NUMBER_OF_BUTTONS;i++)
		btns[i]->ModifyStyle(reg.bShowControls?0:WS_VISIBLE,reg.bShowControls?WS_VISIBLE:0);
	if(bDebug)MessageBox("About to set window placement.");
	SetWindowPlacement(&reg.wp);

	if(bDebug)MessageBox("About to activate the timer.");
	if(!SetTimer(1,1000,NULL))
	{
		MessageBox("Failed to allocate a timer.",NULL,MB_ICONERROR);
		DestroyWindow();
	}

	if(bDebug)MessageBox("About to start playing a song (if needed).");
	if(bLoadPlayList)
	{
		bInternalCall=TRUE;
		OnButtonPlay();
		bInternalCall=FALSE;
	}

	if(bDebug)MessageBox("OnInitDialog has reached the end and is about to return.");
	return TRUE;  // return TRUE  unless you set the focus to a control
}

void CSuperJukeboxDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

void CSuperJukeboxDlg::OnDestroy()
{
	if(bPlaying==TRUE||bPaused==TRUE)OnButtonStop();
	KillTimer(1);
	if(reg.bActiveWallpaper)
		m_ActiveWallpaper.UnloadPlugin();

	reg.wp.length=sizeof(reg.wp);
	GetWindowPlacement(&reg.wp);

	for(int i=0,nCol=0;i<NUMBER_OF_COLUMNS;i++)
	{
		if(reg.stColumnsInfo[i].bActive)
		{
			if(i==0)
				reg.stColumnsInfo[i].iWidth=m_ctlList1.GetColumnWidth(i);
			else
				reg.stColumnsInfo[i].iWidth=m_ctlList2.GetColumnWidth(nCol++);
		}
	}
	
	getcwd(reg.szLastDirectory,sizeof(reg.szLastDirectory));
	strcpy(reg.szLastPlaylist,cstrOpenedPlaylist);
	reg.Save();

	pSmallSysImage->Detach();
	delete pSmallSysImage;
	delete pImageHdrSmall;

	SetPriorityClass(GetCurrentProcess(),NORMAL_PRIORITY_CLASS);

	WinHelp(0L, HELP_QUIT);
	CDialog::OnDestroy();
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void CSuperJukeboxDlg::OnPaint() 
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, (WPARAM) dc.GetSafeHdc(), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

// The system calls this to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR CSuperJukeboxDlg::OnQueryDragIcon()
{
	return (HCURSOR) m_hIcon;
}

void CSuperJukeboxDlg::OnButtonAdd() 
{
	// TODO: Add your control notification handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	POSITION pos=m_ctlList1.GetFirstSelectedItemPosition();
	int nItem=m_ctlList1.GetNextSelectedItem(pos);
	int iType=seList1[nItem].iType;
	BOOL bPass=TRUE;
	if(m_ctlList1.GetSelectedCount()==1)
	{
		if(seList1[nItem].iType==LIST_ID_DRV)
		{
			if(_chdrive(tolower(seList1[nItem].szName[strlen(seList1[nItem].szName)-3])-'a'+1)!=0)
			{
				CString cstrBuffer;
				cstrBuffer.Format("Cannot switch into drive: %s",seList1[nItem].szName);
				MessageBox(cstrBuffer,NULL,MB_ICONERROR);
			}
			else
			{
				if(LoadFileList())
				{
					MessageBox("Out of memory!",NULL,MB_ICONERROR);
					DestroyWindow();
				}
				UpdateList1();
				HighlightListEntry(m_ctlList1,iCurrentFileSelection);
			}
			bPass=FALSE;
		}
		else if(seList1[nItem].iType==LIST_ID_DIR)
		{
			char szBuffer[MAX_PATH],szHiliteName[MAX_PATH];
			if(stricmp(seList1[nItem].szName,".."))
			{
				strcpy(szHiliteName,"..");
			}
			else
			{
				if(!bArchived)
				{
					getcwd(szBuffer,MAX_PATH);
					for(int i=strlen(szBuffer)-1;i>=0;i--)
						if(szBuffer[i]=='\\')
						{
							strcpy(szHiliteName,&szBuffer[i+1]);
							break;
						}
				}
				else
				{
					_splitpath(seList1[nItem].szDirectory,NULL,NULL,szHiliteName,szBuffer);
					strcat(szHiliteName,szBuffer);
				}
			}
			if(!bArchived)
				chdir(seList1[nItem].szName);
			if(LoadFileList())
			{
				MessageBox("Out of memory!",NULL,MB_ICONERROR);
				DestroyWindow();
			}
			UpdateList1();
			for(UINT i=0;i<m_ctlList1.GetItemCount();i++)
			{
				if(!stricmp(seList1[i].szRealName,szHiliteName))
				{
					HighlightListEntry(m_ctlList1,iCurrentFileSelection=i);
					break;
				}
			}
			bPass=FALSE;
		}
		else if(iType==LIST_ID_ACE||iType==LIST_ID_RAR||iType==LIST_ID_ZIP)
		{
			char szName[MAX_PATH];
			strcpy(szName,seList1[nItem].szRealName);
			int iRes;
			if(iType==LIST_ID_ACE)
				iRes=LoadFileListFromACE(szName);
			else if(iType==LIST_ID_RAR)
				iRes=LoadFileListFromRAR(szName);
			else if(iType==LIST_ID_ZIP)
				iRes=LoadFileListFromZIP(szName);
			if(iRes)
			{
				CString cstrBuffer;
				cstrBuffer.Format("Failed to list contents of archive \"%s\"",szName);
				MessageBox(cstrBuffer,NULL,MB_ICONERROR);
				if(LoadFileList())
				{
					MessageBox("Out of memory!",NULL,MB_ICONERROR);
					DestroyWindow();
				}
			}
			UpdateList1();
			HighlightListEntry(m_ctlList1,iCurrentFileSelection=0);
			for(int i=0;i<seList1.size();i++)
				if(!stricmp(seList1[i].szName,".."))
				{
					HighlightListEntry(m_ctlList1,i);
					break;
				}
			bPass=FALSE;
		}
	}
	if(bPass)
	{
		for(int i=0;i<seList1.size();i++)
			seList1[i].bSelected=FALSE;
		UINT iSelCount=0;
		pos=m_ctlList1.GetFirstSelectedItemPosition();
		while(pos)
		{
			nItem=m_ctlList1.GetNextSelectedItem(pos);
			if(seList1[nItem].iType==LIST_ID_SPC)
			{
				seList1[nItem].bSelected=TRUE;
				iSelCount++;
			}
		}
		if(iSelCount)
		{
			int iOldSize=seList2.size();
			CAddFilesDlg dlg;
			dlg.m_bUseID666=reg.bUseID666;
			dlg.DoModal();
			if(seList2.size()!=iOldSize&&seList2.size()>0)
			{
				bNeedsSaving=TRUE;
				InsertList2Items(m_ctlList2.GetItemCount(),iOldSize,seList2.size()-1);
				if(!m_ctlList2.GetSelectedCount())HighlightListEntry(m_ctlList2,iCurrentSong=0);
			}
			LVCOLUMN Column;
			Column.mask=LVCF_FMT;
			Column.fmt=LVCFMT_LEFT;
			m_ctlList2.SetColumn(iSortMethod,&Column);
			iSortMethod=-1;
		}
		else
			MessageBox("There are no SPC files selected.",NULL,MB_ICONINFORMATION);
	}
	UpdateTitleBar();
	UpdateButtonStates();
}

void CSuperJukeboxDlg::OnButtonRemove()
{
	// TODO: Add your control notification handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	POSITION pos=m_ctlList2.GetFirstSelectedItemPosition();
	int iTmp=iCurrentSong;
	std::stack<int>itemstack;
	while(pos)
	{
		int nItem=m_ctlList2.GetNextSelectedItem(pos);
		itemstack.push(nItem);
	}
	CWnd* cWndSpare=GetFocus();
	while(!itemstack.empty())
	{
		seList2.erase(seList2.begin()+itemstack.top(),seList2.begin()+itemstack.top()+1);
		m_ctlList2.DeleteItem(itemstack.top());
		if(itemstack.top()<iPlayingSong)iPlayingSong--;
		else if(itemstack.top()==iPlayingSong)OnButtonStop();
		itemstack.pop();
	}
	if(seList2.size()>0)
	{
		if(iTmp<0)iTmp=0;
		else if(iTmp>=seList2.size())iTmp=seList2.size()-1;
		HighlightListEntry(m_ctlList2,iTmp);
	}
	if(cWndSpare)cWndSpare->SetFocus();
	bNeedsSaving=TRUE;

	UpdateTitleBar();
	UpdateButtonStates();
}

void CSuperJukeboxDlg::OnButtonAddAll()
{
	// TODO: Add your control notification handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	for(int i=0;i<seList1.size();i++)
		seList1[i].bSelected=FALSE;
	UINT iSelCount=0;
	for(i=0;i<seList1.size();i++)
		if(seList1[i].iType==LIST_ID_SPC)
		{
			seList1[i].bSelected=TRUE;
			iSelCount++;
		}
	if(iSelCount)
	{
		int iOldSize=seList2.size();
		CAddFilesDlg dlg;
		dlg.m_bUseID666=reg.bUseID666;
		dlg.DoModal();
		if(seList2.size()!=iOldSize&&seList2.size()>0)
		{
			bNeedsSaving=TRUE;
			InsertList2Items(m_ctlList2.GetItemCount(),iOldSize,seList2.size()-1);
			if(!m_ctlList2.GetSelectedCount())HighlightListEntry(m_ctlList2,0);
		}
		LVCOLUMN Column;
		Column.mask=LVCF_FMT;
		Column.fmt=LVCFMT_LEFT;
		m_ctlList2.SetColumn(iSortMethod,&Column);
		iSortMethod=-1;
	}
	else
		MessageBox("There are no SPC files to be added.",NULL,MB_ICONINFORMATION);

	UpdateTitleBar();
	UpdateButtonStates();
}

void CSuperJukeboxDlg::OnButtonRemoveAll()
{
	// TODO: Add your control notification handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	iCurrentSong=-1;
	seList2.clear();
	m_ctlList2.DeleteAllItems();
	bNeedsSaving=FALSE;
	OnButtonStop();

	UpdateTitleBar();
	UpdateButtonStates();
}

void CSuperJukeboxDlg::OnButtonPlay()
{
	// TODO: Add your control notification handler code here
	if(bDebug)MessageBox("OnButtonPlay has been called.");
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	if(bPlaying==TRUE)
		OnButtonStop();
	if(bPaused==FALSE)
	{
		HighlightListEntry(m_ctlList2,iCurrentSong);
		HANDLE handle;
		char szBuffer[MAX_PATH],szBuffer1[MAX_PATH],szBuffer2[MAX_PATH],szName[_MAX_FNAME],szExt[_MAX_EXT];
		strcpy(szBuffer2,seList2[iCurrentSong].szRealName);
		strcpy(szBuffer1,seList2[iCurrentSong].szDirectory);
		_splitpath(szBuffer1,NULL,NULL,NULL,szExt);
		if(!strlen(szExt))
		{
			if(szBuffer1[strlen(szBuffer1)-1]!='\\')
				strcat(szBuffer1,"\\");
			strcat(szBuffer1,szBuffer2);
		}
		for(int i=0;i<3;i++)
		{
			switch(i)
			{
			case 0:strcpy(szBuffer,szBuffer1);
				break;
			case 1:
				_splitpath(szBuffer1,NULL,NULL,szName,szExt);
				sprintf(szBuffer,"%s%s%s",szPlaylistLocation,szName,szExt);
				break;
			case 2:
				_splitpath(szBuffer1,NULL,NULL,szName,szExt);
				sprintf(szBuffer,"%s%s%s",szProgramLocation,szName,szExt);
				break;
			}
			WIN32_FIND_DATA w32fdFindData;
			if((handle=FindFirstFile(szBuffer,&w32fdFindData))!=INVALID_HANDLE_VALUE)
				break;
		}
		if(handle==INVALID_HANDLE_VALUE)
		{
			char szName[_MAX_FNAME],szExt[_MAX_EXT];
			_splitpath(szBuffer,NULL,NULL,szName,szExt);
			CString cstrBuffer;
			cstrBuffer.Format("After searching the directory specified in the playlist, the directory of the playlist and the directory of the program, still failed to locate the file \"%s%s\"",szName,szExt);
			MessageBox(cstrBuffer,NULL,MB_ICONERROR);
			return;
		}
		FindClose(handle);

		_splitpath(szBuffer,NULL,NULL,NULL,szExt);
		strcpy(szCurrentSong,szBuffer);
		if(!stricmp(szExt,".ace")||!stricmp(szExt,".rar")||!stricmp(szExt,".zip"))
		{
			char *szTempName=_tempnam(NULL,NULL);
			strcpy(szCurrentSong,szTempName);
			free(szTempName);
			WIN32_FIND_DATA w32fdFindData;
			if((handle=FindFirstFile(szCurrentSong,&w32fdFindData))!=INVALID_HANDLE_VALUE)
			{
				FindClose(handle);
				CString cstrBuffer;
				cstrBuffer.Format("\"%s\" already exists. Overwrite?\nWARNING: If you select Yes, it will be deleted.",szCurrentSong);
				if(MessageBox(cstrBuffer,NULL,MB_YESNO|MB_ICONQUESTION|MB_DEFBUTTON2)==IDNO)
					return;
			}
			BOOL bRes;
			if(!stricmp(szExt,".ace"))
				bRes=ExtractFileFromACE(szBuffer,szBuffer2,szCurrentSong);
			else if(!stricmp(szExt,".rar"))
				bRes=ExtractFileFromRAR(szBuffer,szBuffer2,szCurrentSong);
			else if(!stricmp(szExt,".zip"))
				bRes=ExtractFileFromZIP(szBuffer,szBuffer2,szCurrentSong);
			if(!bRes)
			{
				CString cstrBuffer;
				cstrBuffer.Format("Failed to extract \"%s\" from \"%s\"",szBuffer2,szBuffer);
				MessageBox(cstrBuffer,NULL,MB_ICONERROR);
				return;
			}
			SetFileAttributes(szCurrentSong,FILE_ATTRIBUTE_NORMAL);
			bDeleteSong=TRUE;
		}
		SNESAMP_CONFIG cfg;
		SNESAmp_GetConfig(&cfg);
		cfg.LowPass=reg.bUseLPF;
		cfg.OldBRE=reg.bUseOldBRE;
		cfg.APR=reg.bAPR;
		cfg.Amp=reg.dwPreamp;
		cfg.SmpRate=reg.dwSampleRate;
		cfg.BPS=reg.dwSampleSize;
		cfg.NChn=reg.dwChannels;
		cfg.Interpolation=reg.dwInterpolation;
		cfg.BufferLength=reg.dwBufferLength;
		cfg.VisRate=reg.dwVisRate;
		switch(PlaylistPropsDlg.m_nMode)
		{
		case 0:
			cfg.NoTime=1;
			break;
		case 1:
			int iPlayLen,iFadeLen;
			if(iSongLength>0)
			{
				cfg.NoTime=0;
				iFadeLen=0;
				iPlayLen=(iSongLength*iSongRepetitions)*1000;
				if(PlaylistPropsDlg.m_bFadeOut)
					iFadeLen=iFadeLength*1000;
				SNESAmp_SetSongLength(iPlayLen,iFadeLen);
			}
			else
				cfg.NoTime=1;
			break;
		case 2:
			if(seList2[iCurrentSong].iLength>0)
			{
				cfg.NoTime=0;
				iFadeLen=0;
				iPlayLen=(seList2[iCurrentSong].iLength*seList2[iCurrentSong].iRepetitions)*1000;
				if(PlaylistPropsDlg.m_bFadeOut)
					iFadeLen=seList2[iCurrentSong].iFadeLength*1000;
				SNESAmp_SetSongLength(iPlayLen,iFadeLen);
			}
			else
				cfg.NoTime=1;
		}
		SNESAmp_SetConfig(&cfg);
		if(!SNESAmp_Play(szCurrentSong))
		{
			CString cstrBuffer;
			cstrBuffer.Format("Failed to load and/or play \"%s\"",szCurrentSong);
			MessageBox(cstrBuffer,NULL,MB_ICONERROR);
			if(bDeleteSong)
			{
				remove(szCurrentSong);
				bDeleteSong=FALSE;
			}
			return;
		}
		if(bDeleteSong)
		{
			remove(szCurrentSong);
			bDeleteSong=FALSE;
		}
	}
	else
	{
		SNESAmp_UnPause();
	}
	iPlayingSong=iCurrentSong;
	bJustStarted=TRUE;
	bPlaying=TRUE;bPaused=FALSE;
	m_VisWindow.Start();
	if(reg.bActiveWallpaper)
		m_ActiveWallpaper.Start();

	UpdateTitleBar();
	UpdateButtonStates();
}

void CSuperJukeboxDlg::OnButtonPause()
{
	// TODO: Add your control notification handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	if(bPlaying==FALSE)return;
	m_VisWindow.Stop();
	if(reg.bActiveWallpaper)
		m_ActiveWallpaper.Stop(1);
	SNESAmp_Pause();
	m_VisWindow.Render();
	bPlaying=FALSE;bPaused=TRUE;

	UpdateTitleBar();
	UpdateButtonStates();
}

void CSuperJukeboxDlg::OnButtonStop()
{
	// TODO: Add your control notification handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	if(!bPlaying&&!bPaused)
		return;

	m_VisWindow.Stop();
	if(reg.bActiveWallpaper)
		m_ActiveWallpaper.Stop(0);
	SNESAmp_Stop();
	m_VisWindow.Render();
	bPlaying=bPaused=FALSE;
	m_StatusBar.SetText("",0,0);
	m_StatusBar.SetText("",1,0);
	m_StatusBar.SetText("",2,SBT_OWNERDRAW);

	UpdateTitleBar();
	UpdateButtonStates();
}

void CSuperJukeboxDlg::OnButtonPrevious()
{
	// TODO: Add your control notification handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	if(bPlaying)
		iCurrentSong=iPlayingSong;
	if(iCurrentSong>0)
	{
		iCurrentSong--;
		if(bPlaying==FALSE)
		{
			HighlightListEntry(m_ctlList2,iCurrentSong);
		}
		else
			OnButtonPlay();
	}
}

void CSuperJukeboxDlg::OnButtonNext()
{
	// TODO: Add your control notification handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	if(bPlaying)
		iCurrentSong=iPlayingSong;
	int iTmp=iCurrentSong;
	if(PlaylistPropsDlg.m_bRandomize&&seList2.size()>1)
	{
		int iSpare=iCurrentSong;
		while(iCurrentSong==iSpare)
			iCurrentSong=rand()%seList2.size();
	}
	else if(iCurrentSong<seList2.size()-1)
	{
		iCurrentSong++;
	}
	else if(PlaylistPropsDlg.m_bAutoRewind)
	{
		iCurrentSong=0;
	}
	else if(bInternalCall)
	{
		OnButtonStop();
		if(bLoadPlayList)
			OnFileExit();
	}
	if(bPlaying&&iTmp!=iCurrentSong)
		OnButtonPlay();
	else 
		HighlightListEntry(m_ctlList2,iCurrentSong);
}

void CSuperJukeboxDlg::OnItemchangedList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	POSITION pos=m_ctlList1.GetFirstSelectedItemPosition();
	if(pos)
		iCurrentFileSelection=m_ctlList1.GetNextSelectedItem(pos);
	else
		iCurrentFileSelection=-1;

	UpdateTitleBar();
	UpdateButtonStates();
	*pResult = 0;
}

void CSuperJukeboxDlg::OnItemchangedList2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	int iTmp=iCurrentSong;
	POSITION pos=m_ctlList2.GetFirstSelectedItemPosition();
	if(pos)
		iCurrentSong=m_ctlList2.GetNextSelectedItem(pos);
	else
		iCurrentSong=-1;
	if(iCurrentSong!=iTmp&&bPaused==TRUE)
		OnButtonStop();

	UpdateTitleBar();
	UpdateButtonStates();
	*pResult = 0;
}

void CSuperJukeboxDlg::OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	if(m_ctlButton1.IsWindowEnabled())
		OnButtonAdd();
	*pResult = 0;
}

void CSuperJukeboxDlg::OnDblclkList2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	if(m_ctlButton5.IsWindowEnabled())
		OnButtonPlay();
	*pResult = 0;
}

void CSuperJukeboxDlg::OnSetfocusList1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	SetDefID(IDC_BUTTON_ADD);
	*pResult = 0;
}

void CSuperJukeboxDlg::OnSetfocusList2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	SetDefID(IDC_BUTTON_PLAY);
	*pResult = 0;
}

void CSuperJukeboxDlg::OnKeydownList2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_KEYDOWN* pLVKeyDow = (LV_KEYDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	switch(pLVKeyDow->wVKey)
	{
	case VK_APPS:
		RECT rect0,rect1;
		m_ctlList2.GetWindowRect(&rect0);
		m_ctlList2.GetItemRect(iCurrentSong,&rect1,LVIR_BOUNDS);
		m_ctlList2.ClientToScreen(&rect1);
		CMenu*cTempMenu=cMenu1.GetSubMenu(0);
		UINT uState=m_ctlList2.GetItemState(iCurrentSong,LVIS_SELECTED)?MF_ENABLED:MF_GRAYED;
		cTempMenu->EnableMenuItem(ID_MENU_PLAYLIST_REMOVE,uState);
		cTempMenu->EnableMenuItem(ID_MENU_PLAYLIST_PLAY,uState);
		cTempMenu->EnableMenuItem(ID_MENU_PLAYLIST_PROPERTIES,uState);
		switch(cTempMenu->TrackPopupMenu(TPM_RIGHTBUTTON|TPM_NONOTIFY|TPM_RETURNCMD,rect0.left+10,rect1.top+(rect1.bottom-rect1.top)/2,this))
		{
		case ID_MENU_PLAYLIST_REMOVE:OnButtonRemove();break;
		case ID_MENU_PLAYLIST_PLAY:OnButtonPlay();break;
		case ID_MENU_PLAYLIST_PROPERTIES:OnViewProperties();break;
		case ID_MENU_PLAYLIST_STATISTICS:OnHelpAboutSuperJukebox();break;
		}
	}
	*pResult = 0;
}

void CSuperJukeboxDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	if(bPlaying==FALSE)
	{
		CDialog::OnTimer(nIDEvent);
		return;
	}
	if(bDebug)MessageBox("OnTimer has been called.");

	int iElapsedSeconds=(SNESAmp_GetPlayTime()/1000);
	if(!bJustStarted&&iElapsedSeconds==iOldElapsedSeconds)
	{
		CDialog::OnTimer(nIDEvent);
		return;
	}
	bJustStarted=FALSE;
	iOldElapsedSeconds=iElapsedSeconds;

	int iLength=0;
	if(PlaylistPropsDlg.m_nMode==1)
	{
		iLength=iSongLength*iSongRepetitions;
		if(PlaylistPropsDlg.m_bFadeOut&&iLength>0)
			iLength+=iFadeLength;
	}
	else if(PlaylistPropsDlg.m_nMode==2)
	{
		iLength=seList2[iPlayingSong].iLength*seList2[iPlayingSong].iRepetitions;
		if(PlaylistPropsDlg.m_bFadeOut&&iLength>0)
			iLength+=seList2[iPlayingSong].iFadeLength;
	}

	char szBuf0[20],szBuf1[20],szBuf2[100];
	sprintf(szBuf2,"Song: %d of %d",iPlayingSong+1,seList2.size());
	m_StatusBar.SetText(szBuf2,0,0);
	
	ConvertTimeUp(iElapsedSeconds,szBuf0);
	ConvertTimeUp(iLength,szBuf1);
	sprintf(szBuf2,"Elapsed time: %s",szBuf0);
	if(iLength>0)
	{
		strcat(szBuf2," of ");
		strcat(szBuf2,szBuf1);
	}
	m_StatusBar.SetText(szBuf2,1,0);
	m_StatusBar.SetText("",2,SBT_OWNERDRAW);
	if(reg.bActiveWallpaper)
		m_StatusBar.SetText(m_ActiveWallpaper.strSpare,3,0);

	if(PlaylistPropsDlg.m_bDetectSilence&&!SNESAmp_IsPlaying())
	{
		bInternalCall=TRUE;
		OnButtonNext();
		bInternalCall=FALSE;
	}
	else if(iLength>0)
	{
		if(iElapsedSeconds>=iLength)
		{
			bInternalCall=TRUE;
			OnButtonNext();
			bInternalCall=FALSE;
		}
	}

	CDialog::OnTimer(nIDEvent);
}

void CSuperJukeboxDlg::OnCancel()
{
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	if(bNeedsSaving==TRUE&&seList2.size()>0)
	{
		CString cstrBuffer;
		cstrBuffer.Format("Save changes to %s?",cstrOpenedPlaylist);
		int iRes=MessageBox(cstrBuffer,NULL,MB_YESNOCANCEL|MB_ICONQUESTION);
		if(iRes==IDYES)OnFileSave();
		else if(iRes==IDCANCEL)return;
	}
	DestroyWindow();
}

void CSuperJukeboxDlg::OnOK()
{
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	if(bNeedsSaving==TRUE&&seList2.size()>0)
	{
		CString cstrBuffer;
		cstrBuffer.Format("Save changes to %s?",cstrOpenedPlaylist);
		int iRes=MessageBox(cstrBuffer,NULL,MB_YESNOCANCEL|MB_ICONQUESTION);
		if(iRes==IDYES)OnFileSave();
		else if(iRes==IDCANCEL)return;
	}
	DestroyWindow();
}

int CSuperJukeboxDlg::LoadFileList()
{
	HANDLE hFindFile;
	WIN32_FIND_DATA w32fdFindData;
	char *szExtensions[]={"*.ace","*.rar","*.zip","*.spc","*.sp0","*.sp1","*.sp2","*.sp3","*.sp4","*.sp5","*.sp6","*.sp7","*.sp8","*.sp9"};
	char szCurDir[MAX_PATH];
	SongEntry seSpare;

	seList1.clear();
	LoadDriveList();
	getcwd(szCurDir,MAX_PATH);
	int iTmp=seList1.size();
	int iPass=0;
	while(!iPass?(hFindFile=FindFirstFile("*.*",&w32fdFindData))!=INVALID_HANDLE_VALUE:FindNextFile(hFindFile,&w32fdFindData))
	{
		if(w32fdFindData.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY&&strcmp(w32fdFindData.cFileName,"."))
		{
			SHFILEINFO sfi;
			if(!strcmp(w32fdFindData.cFileName,".."))
			{
				SHGetFileInfo("*.*",FILE_ATTRIBUTE_DIRECTORY,&sfi,sizeof(sfi),SHGFI_ICON|SHGFI_SMALLICON|SHGFI_USEFILEATTRIBUTES);
				strcpy(sfi.szDisplayName,"..");
			}
			else
				SHGetFileInfo(w32fdFindData.cFileName,0,&sfi,sizeof(sfi),SHGFI_ICON|SHGFI_SMALLICON|SHGFI_DISPLAYNAME);
			memset(&seSpare,0,sizeof(seSpare));
			if(strlen(sfi.szDisplayName))
				strcpy(seSpare.szName,sfi.szDisplayName);
			else
				strcpy(seSpare.szName,w32fdFindData.cFileName);
			strcpy(seSpare.szRealName,w32fdFindData.cFileName);
			strcpy(seSpare.szDirectory,szCurDir);
			if(strlen(seSpare.szDirectory)>3)strcat(seSpare.szDirectory,"\\");
			seSpare.iIcon=sfi.iIcon;
			seSpare.iLength=0;
			seSpare.iFadeLength=0;
			seSpare.iRepetitions=1;
			seSpare.iType=LIST_ID_DIR;
			seList1.push_back(seSpare);
		}
		iPass++;
	}
	FindClose(hFindFile);
	std::sort(seList1.begin()+iTmp,seList1.end());
	iTmp=seList1.size();
	for(int iIndex1=0;iIndex1<14;iIndex1++)
	{
		iPass=0;
		while(!iPass?(hFindFile=FindFirstFile(szExtensions[iIndex1],&w32fdFindData))!=INVALID_HANDLE_VALUE:FindNextFile(hFindFile,&w32fdFindData))
		{
			if(!(w32fdFindData.dwFileAttributes&FILE_ATTRIBUTE_DIRECTORY))
			{
				SHFILEINFO sfi;
				SHGetFileInfo(w32fdFindData.cFileName,0,&sfi,sizeof(sfi),SHGFI_ICON|SHGFI_SMALLICON|SHGFI_DISPLAYNAME);
				memset(&seSpare,0,sizeof(seSpare));
				if(strlen(sfi.szDisplayName))
					strcpy(seSpare.szName,sfi.szDisplayName);
				else
					strcpy(seSpare.szName,w32fdFindData.cFileName);
				strcpy(seSpare.szRealName,w32fdFindData.cFileName);
				strcpy(seSpare.szDirectory,szCurDir);
				if(strlen(seSpare.szDirectory)>3)strcat(seSpare.szDirectory,"\\");
				seSpare.iIcon=sfi.iIcon;
				seSpare.iLength=0;
				seSpare.iFadeLength=0;
				seSpare.iRepetitions=1;
				switch(iIndex1)
				{
				case 0:seSpare.iType=LIST_ID_ACE;break;
				case 1:seSpare.iType=LIST_ID_RAR;break;
				case 2:seSpare.iType=LIST_ID_ZIP;break;
				default:seSpare.iType=LIST_ID_SPC;break;
				}
				seSpare.bArchived=FALSE;
				seList1.push_back(seSpare);
			}
			iPass++;
		}
		FindClose(hFindFile);
	}
	std::sort(seList1.begin()+iTmp,seList1.end());
	iListingType=LIST_ID_DIR;
	strcpy(szListingSource,szCurDir);
	bArchived=FALSE;
	return 0;
}

int CSuperJukeboxDlg::LoadFileListFromACE(CString cstrArchiveName)
{
	HANDLE hArcData;
	int RHCode,PFCode;
	ACEHeaderData HeaderData;
	ACEOpenArchiveData OpenArchiveData;
	char szCurDir[MAX_PATH];
	SongEntry seSpare;
	char *szExtensions[]={".spc",".sp0",".sp1",".sp2",".sp3",".sp4",".sp5",".sp6",".sp7",".sp8",".sp9"};

	seList1.clear();
	LoadDriveList();
	getcwd(szCurDir,MAX_PATH);
	if(strlen(szCurDir)>3)
		strcat(szCurDir,"\\");
	strcat(szCurDir,cstrArchiveName);
	SHFILEINFO sfi;
	SHGetFileInfo("*.*",FILE_ATTRIBUTE_DIRECTORY,&sfi,sizeof(sfi),SHGFI_ICON|SHGFI_SMALLICON|SHGFI_USEFILEATTRIBUTES);
	strcpy(seSpare.szName,"..");
	strcpy(seSpare.szDirectory,szCurDir);
	seSpare.iIcon=sfi.iIcon;
	seSpare.iLength=0;
	seSpare.iFadeLength=0;
	seSpare.iRepetitions=1;
	seSpare.iType=LIST_ID_DIR;
	seList1.push_back(seSpare);

	int iTmp=seList1.size();
	OpenArchiveData.ArcName=cstrArchiveName.GetBuffer(MAX_PATH);
	OpenArchiveData.CmtBuf=NULL;
	OpenArchiveData.OpenMode=ACEOPEN_LIST;
	OpenArchiveData.ChangeVolProc=NULL;
	OpenArchiveData.ProcessDataProc=NULL;
	HeaderData.CmtBuf=NULL;
	if((hArcData=_ACEOpenArchive(&OpenArchiveData))==NULL)return 1;
	if(OpenArchiveData.OpenResult)return 1;
	while((RHCode=_ACEReadHeader(hArcData,&HeaderData))==0)
	{
		if(!(HeaderData.FileAttr&FILE_ATTRIBUTE_DIRECTORY))
		{
			char szExt[_MAX_EXT];
			_splitpath(HeaderData.FileName,NULL,NULL,NULL,szExt);
			for(int i=0;i<11;i++)
				if(!stricmp(szExt,szExtensions[i]))
				{
					SHFILEINFO sfi;
					SHGetFileInfo(HeaderData.FileName,FILE_ATTRIBUTE_NORMAL,&sfi,sizeof(sfi),SHGFI_ICON|SHGFI_SMALLICON|SHGFI_USEFILEATTRIBUTES);
					memset(&seSpare,0,sizeof(seSpare));
					_splitpath(HeaderData.FileName,NULL,NULL,seSpare.szName,szExt);
					if(fShowExtensions||IsFileTypeRegistered(szExt)==FALSE)
						strcat(seSpare.szName,szExt);
					strcpy(seSpare.szRealName,HeaderData.FileName);
					strcpy(seSpare.szDirectory,szCurDir);
					seSpare.iIcon=sfi.iIcon;
					seSpare.iLength=0;
					seSpare.iFadeLength=0;
					seSpare.iRepetitions=1;
					seSpare.iType=LIST_ID_SPC;
					seSpare.bArchived=TRUE;
					seSpare.iSubType=LIST_ID_ACE;
					seList1.push_back(seSpare);
				}
		}
		if((PFCode=_ACEProcessFile(hArcData,ACECMD_SKIP,NULL))!=0)break;
	}
	_ACECloseArchive(hArcData);
	if(RHCode==ACEERR_READ||PFCode)return 1;
	std::sort(seList1.begin()+iTmp,seList1.end());
	iListingType=LIST_ID_ACE;
	strcpy(szListingSource,szCurDir);
	bArchived=TRUE;
	return 0;
}

int CSuperJukeboxDlg::LoadFileListFromRAR(CString cstrArchiveName)
{
	HANDLE hArcData;
	int RHCode,PFCode;
	RARHeaderData HeaderData;
	RAROpenArchiveData OpenArchiveData;
	char szCurDir[MAX_PATH];
	SongEntry seSpare;
	char *szExtensions[]={".spc",".sp0",".sp1",".sp2",".sp3",".sp4",".sp5",".sp6",".sp7",".sp8",".sp9"};

	seList1.clear();
	LoadDriveList();
	getcwd(szCurDir,MAX_PATH);
	if(strlen(szCurDir)>3)
		strcat(szCurDir,"\\");
	strcat(szCurDir,cstrArchiveName);
	SHFILEINFO sfi;
	SHGetFileInfo("*.*",FILE_ATTRIBUTE_DIRECTORY,&sfi,sizeof(sfi),SHGFI_ICON|SHGFI_SMALLICON|SHGFI_USEFILEATTRIBUTES);
	strcpy(seSpare.szName,"..");
	strcpy(seSpare.szRealName,"..");
	strcpy(seSpare.szDirectory,szCurDir);
	seSpare.iIcon=sfi.iIcon;
	seSpare.iLength=0;
	seSpare.iFadeLength=0;
	seSpare.iRepetitions=1;
	seSpare.iType=LIST_ID_DIR;
	seList1.push_back(seSpare);

	int iTmp=seList1.size();
	OpenArchiveData.ArcName=cstrArchiveName.GetBuffer(MAX_PATH);
	OpenArchiveData.CmtBuf=NULL;
	OpenArchiveData.OpenMode=RAR_OM_LIST;
	HeaderData.CmtBuf=NULL;
	if((hArcData=_RAROpenArchive(&OpenArchiveData))==NULL)return 1;
	while((RHCode=_RARReadHeader(hArcData,&HeaderData))==0)
	{
		if(!(HeaderData.FileAttr&FILE_ATTRIBUTE_DIRECTORY))
		{
			char szExt[_MAX_EXT];
			_splitpath(HeaderData.FileName,NULL,NULL,NULL,szExt);
			for(int i=0;i<11;i++)
				if(!stricmp(szExt,szExtensions[i]))
				{
					SHFILEINFO sfi;
					SHGetFileInfo(HeaderData.FileName,FILE_ATTRIBUTE_NORMAL,&sfi,sizeof(sfi),SHGFI_ICON|SHGFI_SMALLICON|SHGFI_USEFILEATTRIBUTES);
					memset(&seSpare,0,sizeof(seSpare));
					_splitpath(HeaderData.FileName,NULL,NULL,seSpare.szName,szExt);
					if(fShowExtensions||IsFileTypeRegistered(szExt)==FALSE)
						strcat(seSpare.szName,szExt);
					strcpy(seSpare.szRealName,HeaderData.FileName);
					strcpy(seSpare.szDirectory,szCurDir);
					seSpare.iIcon=sfi.iIcon;
					seSpare.iLength=0;
					seSpare.iFadeLength=0;
					seSpare.iRepetitions=1;
					seSpare.iType=LIST_ID_SPC;
					seSpare.iSubType=LIST_ID_RAR;
					seSpare.bArchived=TRUE;
					seList1.push_back(seSpare);
				}
		}
		if((PFCode=_RARProcessFile(hArcData,RAR_SKIP,NULL,NULL))!=0)break;
	}
	_RARCloseArchive(hArcData);
	if(RHCode==ERAR_BAD_DATA||PFCode)return 1;
	std::sort(seList1.begin()+iTmp,seList1.end());
	iListingType=LIST_ID_RAR;
	strcpy(szListingSource,szCurDir);
	bArchived=TRUE;
	return 0;
}

int CSuperJukeboxDlg::LoadFileListFromZIP(CString cstrArchiveName)
{
	char szBuffer[MAX_PATH];
	unz_file_info ufiInfo;
	unzFile ufFile;
	char szCurDir[MAX_PATH];
	SongEntry seSpare;
	char *szExtensions[]={".spc",".sp0",".sp1",".sp2",".sp3",".sp4",".sp5",".sp6",".sp7",".sp8",".sp9"};

	seList1.clear();
	LoadDriveList();
	getcwd(szCurDir,MAX_PATH);
	if(strlen(szCurDir)>3)
		strcat(szCurDir,"\\");
	strcat(szCurDir,cstrArchiveName);
	SHFILEINFO sfi;
	SHGetFileInfo("*.*",FILE_ATTRIBUTE_DIRECTORY,&sfi,sizeof(sfi),SHGFI_ICON|SHGFI_SMALLICON|SHGFI_USEFILEATTRIBUTES);
	strcpy(seSpare.szName,"..");
	strcpy(seSpare.szRealName,"..");
	strcpy(seSpare.szDirectory,szCurDir);
	seSpare.iIcon=sfi.iIcon;
	seSpare.iLength=0;
	seSpare.iFadeLength=0;
	seSpare.iRepetitions=1;
	seSpare.iType=LIST_ID_DIR;
	seList1.push_back(seSpare);

	int iTmp=seList1.size();
	int iPass=0;
	if((ufFile=unzOpen(cstrArchiveName))==NULL)return 1;
	while((!iPass?unzGoToFirstFile(ufFile):unzGoToNextFile(ufFile))==UNZ_OK)
	{
		unzGetCurrentFileInfo(ufFile,&ufiInfo,szBuffer,MAX_PATH,NULL,0,NULL,0);
		if(!(ufiInfo.external_fa&FILE_ATTRIBUTE_DIRECTORY))
		{
			char szExt[_MAX_EXT];
			_splitpath(szBuffer,NULL,NULL,NULL,szExt);
			for(int i=0;i<11;i++)
				if(!stricmp(szExt,szExtensions[i]))
				{
					SHFILEINFO sfi;
					SHGetFileInfo(szBuffer,FILE_ATTRIBUTE_NORMAL,&sfi,sizeof(sfi),SHGFI_ICON|SHGFI_SMALLICON|SHGFI_USEFILEATTRIBUTES);
					memset(&seSpare,0,sizeof(seSpare));
					_splitpath(szBuffer,NULL,NULL,seSpare.szName,szExt);
					if(fShowExtensions||IsFileTypeRegistered(szExt)==FALSE)
						strcat(seSpare.szName,szExt);
					strcpy(seSpare.szRealName,szBuffer);
					strcpy(seSpare.szDirectory,szCurDir);
					seSpare.iIcon=sfi.iIcon;
					seSpare.iLength=0;
					seSpare.iFadeLength=0;
					seSpare.iRepetitions=1;
					seSpare.iType=LIST_ID_SPC;
					seSpare.bArchived=TRUE;
					seSpare.iSubType=LIST_ID_ZIP;
					seList1.push_back(seSpare);
				}
		}
		iPass++;
	}
	unzClose(ufFile);
	std::sort(seList1.begin()+iTmp,seList1.end());
	iListingType=LIST_ID_ZIP;
	strcpy(szListingSource,szCurDir);
	bArchived=TRUE;
	return 0;
}

int CSuperJukeboxDlg::LoadPlayList(const char *szPlayList)
{
	CStdioFile fileIn;
	if(!fileIn.Open(szPlayList,CFile::modeRead|CFile::typeBinary))
	{
		CString cstrBuffer;
		cstrBuffer.Format("Failed to open: \"%s\"",szPlayList);
		MessageBox(cstrBuffer,NULL,MB_ICONERROR);
		return 1;
	}
	char szBuffer[MAX_PATH+1];
	fileIn.ReadString(szBuffer,MAX_PATH);
	TrimString(szBuffer);
	if(stricmp(szBuffer,"SJPL"))
	{
		MessageBox("File is not a valid playlist.",NULL,MB_ICONERROR);
		fileIn.Close();
		return 1;
	}
	fileIn.ReadString(szBuffer,MAX_PATH);
	TrimString(szBuffer);
	int iVersion=GetSettingValue(szBuffer);
	if(iVersion>PLAYLIST_VERSION)
	{
		MessageBox("Playlist is of an unsupported version.",NULL,MB_ICONERROR);
		fileIn.Close();
		return 1;
	}
	if(iVersion>=2&&iVersion<=6)
		fileIn.ReadString(szBuffer,MAX_PATH);
	fileIn.ReadString(szBuffer,MAX_PATH);
	TrimString(szBuffer);
	PlaylistPropsDlg.m_nMode=GetSettingValue(szBuffer);
	if(PlaylistPropsDlg.m_nMode!=0&&PlaylistPropsDlg.m_nMode!=1&&PlaylistPropsDlg.m_nMode!=2)
	{
		MessageBox("File is not a valid playlist.",NULL,MB_ICONERROR);
		fileIn.Close();
		return 1;
	}
	fileIn.ReadString(szBuffer,MAX_PATH);
	TrimString(szBuffer);
	if(iVersion>=10)
	{
		for(int i=0;i<strlen(szBuffer);i++)
			if(szBuffer[i]=='=')break;
		strcpy(szBuffer,&szBuffer[i+1]);
		iSongLength=ConvertTimeDown(szBuffer);
	}
	else 
		iSongLength=GetSettingValue(szBuffer);
	if(iSongLength<0)iSongLength=0;
	if(iVersion>=8)
	{
		fileIn.ReadString(szBuffer,MAX_PATH);
		TrimString(szBuffer);
		if(iVersion>=10)
		{
			for(int i=0;i<strlen(szBuffer);i++)
				if(szBuffer[i]=='=')break;
			strcpy(szBuffer,&szBuffer[i+1]);
			iFadeLength=ConvertTimeDown(szBuffer);
		}
		else 
			iFadeLength=GetSettingValue(szBuffer);
		if(iFadeLength<0)iFadeLength=0;
	}
	fileIn.ReadString(szBuffer,MAX_PATH);
	TrimString(szBuffer);
	iSongRepetitions=GetSettingValue(szBuffer);
	if(iSongRepetitions<1)iSongRepetitions=1;
	fileIn.ReadString(szBuffer,MAX_PATH);
	TrimString(szBuffer);
	PlaylistPropsDlg.m_bAutoRewind=GetSettingValue(szBuffer)?1:0;
	if(iVersion>=3)
	{
		fileIn.ReadString(szBuffer,MAX_PATH);
		TrimString(szBuffer);
		PlaylistPropsDlg.m_bFadeOut=GetSettingValue(szBuffer)?1:0;
	}
	else PlaylistPropsDlg.m_bFadeOut=0;
	if(iVersion>=4)
	{
		fileIn.ReadString(szBuffer,MAX_PATH);
		TrimString(szBuffer);
		PlaylistPropsDlg.m_bRandomize=GetSettingValue(szBuffer)?1:0;
	}
	else PlaylistPropsDlg.m_bRandomize=0;
	if(iVersion>=5)
	{
		fileIn.ReadString(szBuffer,MAX_PATH);
		TrimString(szBuffer);
		PlaylistPropsDlg.m_bDetectSilence=GetSettingValue(szBuffer)?1:0;
	}
	else PlaylistPropsDlg.m_bDetectSilence=0;
	if(iVersion>=6)
	{
		fileIn.ReadString(szBuffer,MAX_PATH);
		TrimString(szBuffer);
		PlaylistPropsDlg.m_bUseSkin=GetSettingValue(szBuffer)?1:0;
		fileIn.ReadString(szBuffer,MAX_PATH);
		TrimString(szBuffer);
		PlaylistPropsDlg.m_nSkinLayout=GetSettingValue(szBuffer)?1:0;
		fileIn.ReadString(szBuffer,MAX_PATH);
		TrimString(szBuffer);
		PlaylistPropsDlg.m_cstrSkinFile=szBuffer;
	}
	else PlaylistPropsDlg.m_cstrSkinFile=PlaylistPropsDlg.m_bUseSkin=PlaylistPropsDlg.m_nSkinLayout=0;

	seList2.clear();
	while(fileIn.GetPosition()<fileIn.GetLength())
	{
		SongEntry seSpare;
		memset(&seSpare,0,sizeof(seSpare));

		if(fileIn.ReadString(szBuffer,MAX_PATH)==NULL)break;
		TrimString(szBuffer);
		strcpy(seSpare.szName,szBuffer);
		if(iVersion>=9)
		{
			if(fileIn.ReadString(szBuffer,MAX_PATH)==NULL)break;
			TrimString(szBuffer);
			strcpy(seSpare.szRealName,szBuffer);
		}
		else
			strcpy(seSpare.szRealName,seSpare.szName);
		if(fileIn.ReadString(szBuffer,MAX_PATH)==NULL)break;
		TrimString(szBuffer);
		strcpy(seSpare.szDirectory,szBuffer);
		if(iVersion>=8)
		{
			if(fileIn.ReadString(szBuffer,MAX_PATH)==NULL)break;
			TrimString(szBuffer);
			strcpy((char*)seSpare.ID666.Song,szBuffer);
			if(fileIn.ReadString(szBuffer,MAX_PATH)==NULL)break;
			TrimString(szBuffer);
			strcpy((char*)seSpare.ID666.Game,szBuffer);
			if(fileIn.ReadString(szBuffer,MAX_PATH)==NULL)break;
			TrimString(szBuffer);
			strcpy((char*)seSpare.ID666.Artist,szBuffer);
			if(fileIn.ReadString(szBuffer,MAX_PATH)==NULL)break;
			TrimString(szBuffer);
			strcpy((char*)seSpare.ID666.Dumper,szBuffer);
			if(fileIn.ReadString(szBuffer,MAX_PATH)==NULL)break;
			TrimString(szBuffer);
			strcpy((char*)seSpare.ID666.Date,szBuffer);
			if(fileIn.ReadString(szBuffer,MAX_PATH)==NULL)break;
			TrimString(szBuffer);
			strcpy((char*)seSpare.ID666.Comment,szBuffer);
		}
		if(fileIn.ReadString(szBuffer,MAX_PATH)==NULL)break;
		TrimString(szBuffer);
		if(iVersion>=10)
			seSpare.iLength=ConvertTimeDown(szBuffer);
		else 
			seSpare.iLength=atoi(szBuffer);
		if(seSpare.iLength<0)seSpare.iLength=0;
		if(iVersion>=8)
		{
			if(fileIn.ReadString(szBuffer,MAX_PATH)==NULL)break;
			TrimString(szBuffer);
			if(iVersion>=10)
				seSpare.iFadeLength=ConvertTimeDown(szBuffer);
			else 
				seSpare.iFadeLength=atoi(szBuffer);
			if(seSpare.iFadeLength<0)seSpare.iFadeLength=0;
		}
		if(fileIn.ReadString(szBuffer,MAX_PATH)==NULL)break;
		TrimString(szBuffer);
		seSpare.iRepetitions=atoi(szBuffer);
		if(seSpare.iRepetitions<1)seSpare.iRepetitions=1;
		seList2.push_back(seSpare);
	}
	fileIn.Close();
	UpdateList2();
	HighlightListEntry(m_ctlList2,iCurrentSong=0);
	char szDrive[_MAX_DRIVE],szDir[_MAX_DIR];
	cstrOpenedPlaylist=szPlayList;
	_splitpath(cstrOpenedPlaylist,szDrive,szDir,szBuffer,NULL);
	strcpy(szPlaylistLocation,szDrive);strcat(szPlaylistLocation,szDir);
	return 0;
}

int CSuperJukeboxDlg::SavePlayList(const char *szPlayList)
{
	CStdioFile fileOut;
	if(!fileOut.Open(szPlayList,CFile::modeCreate|CFile::modeWrite|CFile::typeBinary))
	{
		CString cstrBuffer;
		cstrBuffer.Format("Failed to create: \"%s\"",szPlayList);
		MessageBox(cstrBuffer,NULL,MB_ICONERROR);
		return 1;
	}
	CString cstrBuffer;
	fileOut.WriteString("SJPL\r\n");
	cstrBuffer.Format("Version=%d\r\n",PLAYLIST_VERSION);
	fileOut.WriteString(cstrBuffer);
	cstrBuffer.Format("Mode=%d\r\n",PlaylistPropsDlg.m_nMode);
	fileOut.WriteString(cstrBuffer);
	char szBuf[20];
	ConvertTimeUp(iSongLength,szBuf);
	cstrBuffer.Format("Length=%s\r\n",szBuf);
	fileOut.WriteString(cstrBuffer);
	ConvertTimeUp(iFadeLength,szBuf);
	cstrBuffer.Format("Fade=%s\r\n",szBuf);
	fileOut.WriteString(cstrBuffer);
	cstrBuffer.Format("Repetitions=%d\r\n",iSongRepetitions);
	fileOut.WriteString(cstrBuffer);
	cstrBuffer.Format("AutoRewind=%d\r\n",PlaylistPropsDlg.m_bAutoRewind);
	fileOut.WriteString(cstrBuffer);
	cstrBuffer.Format("FadeOut=%d\r\n",PlaylistPropsDlg.m_bFadeOut);
	fileOut.WriteString(cstrBuffer);
	cstrBuffer.Format("Randomize=%d\r\n",PlaylistPropsDlg.m_bRandomize);
	fileOut.WriteString(cstrBuffer);
	cstrBuffer.Format("DetectSilence=%d\r\n",PlaylistPropsDlg.m_bDetectSilence);
	fileOut.WriteString(cstrBuffer);
	cstrBuffer.Format("UseSkin=%d\r\n",PlaylistPropsDlg.m_bUseSkin);
	fileOut.WriteString(cstrBuffer);
	cstrBuffer.Format("SkinLayout=%d\r\n",PlaylistPropsDlg.m_nSkinLayout);
	fileOut.WriteString(cstrBuffer);
	cstrBuffer.Format("%s\r\n",PlaylistPropsDlg.m_cstrSkinFile);
	fileOut.WriteString(cstrBuffer);
	for(int iIndex=0;iIndex<seList2.size();iIndex++)
	{
		cstrBuffer.Format("%s\r\n",seList2[iIndex].szName);
		fileOut.WriteString(cstrBuffer);
		cstrBuffer.Format("%s\r\n",seList2[iIndex].szRealName);
		fileOut.WriteString(cstrBuffer);
		cstrBuffer.Format("%s\r\n",seList2[iIndex].szDirectory);
		fileOut.WriteString(cstrBuffer);
		cstrBuffer.Format("%s\r\n",seList2[iIndex].ID666.Song);
		fileOut.WriteString(cstrBuffer);
		cstrBuffer.Format("%s\r\n",seList2[iIndex].ID666.Game);
		fileOut.WriteString(cstrBuffer);
		cstrBuffer.Format("%s\r\n",seList2[iIndex].ID666.Artist);
		fileOut.WriteString(cstrBuffer);
		cstrBuffer.Format("%s\r\n",seList2[iIndex].ID666.Dumper);
		fileOut.WriteString(cstrBuffer);
		cstrBuffer.Format("%s\r\n",seList2[iIndex].ID666.Date);
		fileOut.WriteString(cstrBuffer);
		cstrBuffer.Format("%s\r\n",seList2[iIndex].ID666.Comment);
		fileOut.WriteString(cstrBuffer);
		ConvertTimeUp(seList2[iIndex].iLength,szBuf);
		cstrBuffer.Format("%s\r\n",szBuf);
		fileOut.WriteString(cstrBuffer);
		ConvertTimeUp(seList2[iIndex].iFadeLength,szBuf);
		cstrBuffer.Format("%s\r\n",szBuf);
		fileOut.WriteString(cstrBuffer);
		cstrBuffer.Format("%d\r\n",seList2[iIndex].iRepetitions);
		fileOut.WriteString(cstrBuffer);
	}
	fileOut.Close();
	char szDrive[_MAX_DRIVE],szName[_MAX_FNAME],szDir[_MAX_DIR];
	cstrOpenedPlaylist=szPlayList;
	_splitpath(cstrOpenedPlaylist,szDrive,szDir,szName,NULL);
	strcpy(szPlaylistLocation,szDrive);strcat(szPlaylistLocation,szDir);
	return 0;
}

BOOL CAboutDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	int iTotalLength=0,iTotalRepetitions=0;
	for(int i=0;i<seList2.size();i++)
	{
		if(seList2[i].iLength>=0)
			iTotalLength+=seList2[i].iLength;
		if(seList2[i].iFadeLength>=0)
			iTotalLength+=seList2[i].iFadeLength;
		if(seList2[i].iRepetitions>=0)
			iTotalRepetitions+=seList2[i].iRepetitions;
	}
	int iAverageLength=0,iAverageRepetitions=0;
	if(seList2.size()>0)
	{
		iAverageLength=iTotalLength/seList2.size();
		iAverageRepetitions=iTotalRepetitions/seList2.size();
	}
	char szBuf0[500],szBuf1[500];
	ConvertTimeUp(iTotalLength,szBuf0);
	ConvertTimeUp(iAverageLength,szBuf1);
	CString cstrBuffer;
	cstrBuffer.Format("Total songs:\t\t%u\nTotal length:\t\t%s\nAverage length:\t\t%s\nTotal repetitions:\t\t%u\nAverage repetitions:\t%u",seList2.size(),szBuf0,szBuf1,iTotalRepetitions,iAverageRepetitions);
	GetDlgItem(IDC_STATIC_STATISTICS)->SetWindowText(cstrBuffer);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSuperJukeboxDlg::LoadDriveList()
{
	char szCurDir[MAX_PATH];

	getcwd(szCurDir,MAX_PATH);
	DWORD dwDrives=GetLogicalDrives();
	DWORD dwDrivesMask=1,dwDrivesIndex=0;
	while(dwDrives&&dwDrivesIndex<26)
	{
		if(dwDrives&dwDrivesMask)
		{
			SongEntry seSpare;
			memset(&seSpare,0,sizeof(seSpare));
			char szRoot[4];
			sprintf(szRoot,"%c:\\",dwDrivesIndex+'A');
			SHFILEINFO sfi;
			SHGetFileInfo(szRoot,0,&sfi,sizeof(sfi),SHGFI_ICON|SHGFI_SMALLICON|SHGFI_DISPLAYNAME);
			strcpy(seSpare.szName,sfi.szDisplayName);
			strcpy(seSpare.szRealName,sfi.szDisplayName);
			strcpy(seSpare.szDirectory,szCurDir);
			if(strlen(seSpare.szDirectory)>3)strcat(seSpare.szDirectory,"\\");
			seSpare.iIcon=sfi.iIcon;
			seSpare.iLength=0;
			seSpare.iFadeLength=0;
			seSpare.iRepetitions=1;
			seSpare.iType=LIST_ID_DRV;
			seList1.push_back(seSpare);
		}
		dwDrivesMask<<=1;dwDrivesIndex++;
	}
}

int CSuperJukeboxDlg::GetSettingValue(const char *szSetting)
{
	for(int iIndex=strlen(szSetting)-1;iIndex>=0;iIndex--)
		if(szSetting[iIndex]=='=')
			break;
	char szBuffer[200];
	int iIndex1=0;
	while(iIndex<strlen(szSetting))
		szBuffer[iIndex1++]=szSetting[++iIndex];
	szBuffer[iIndex1]=NULL;
	return atoi(szBuffer);
}

void CSuperJukeboxDlg::InsertList1Items(int iInsertPos,int iStart,int iEnd)
{
	m_ctlList1.SetRedraw(FALSE);
	m_ctlList1.SetItemCount(m_ctlList1.GetItemCount()+(iEnd-iStart+1));
	for(UINT i0=iStart,i1=iInsertPos;i0<=iEnd;i0++,i1++)
		m_ctlList1.InsertItem(i1,seList1[i0].szName,seList1[i0].iIcon);
	m_ctlList1.SetRedraw();
}

void CSuperJukeboxDlg::InsertList2Items(int iInsertPos,int iStart,int iEnd)
{
	m_ctlList2.SetRedraw(FALSE);
	m_ctlList2.SetItemCount(m_ctlList2.GetItemCount()+(iEnd-iStart+1));
	for(UINT i0=iStart,i1=iInsertPos;i0<=iEnd;i0++,i1++)
	{
		SetColumnText(i1,"File",seList2[i0].szName,seList2[i0].iIcon);
		SetColumnText(i1,"Title",seList2[i0].ID666.Song,seList2[i0].iIcon);
		SetColumnText(i1,"Game",seList2[i0].ID666.Game,seList2[i0].iIcon);
		SetColumnText(i1,"Artist",seList2[i0].ID666.Artist,seList2[i0].iIcon);
		SetColumnText(i1,"Dumper",seList2[i0].ID666.Dumper,seList2[i0].iIcon);
		SetColumnText(i1,"Date",seList2[i0].ID666.Date,seList2[i0].iIcon);
		SetColumnText(i1,"Comment",seList2[i0].ID666.Comment,seList2[i0].iIcon);
		TCHAR szBuffer[20];
		ConvertTimeUp(seList2[i0].iLength,szBuffer);
		SetColumnText(i1,"Length",szBuffer,seList2[i0].iIcon);
		ConvertTimeUp(seList2[i0].iFadeLength,szBuffer);
		SetColumnText(i1,"Fade",szBuffer,seList2[i0].iIcon);
		itoa(seList2[i0].iRepetitions,szBuffer,10);
		SetColumnText(i1,"Repetitions",szBuffer,seList2[i0].iIcon);
	}
	if(reg.bAutoSizeColumns&&m_ctlList2.GetItemCount()>0)
	{
		CHeaderCtrl* pHdrCtrl=m_ctlList2.GetHeaderCtrl();
		UINT uiColumns=pHdrCtrl->GetItemCount();
		UINT uiItems=m_ctlList2.GetItemCount();
		for(UINT i0=0;i0<uiColumns;i0++)
		{
			UINT uiColumnWidth=0;
			for(UINT i1=0;i1<uiItems;i1++)
			{
				TCHAR szBuffer[MAX_PATH]={0};
				m_ctlList2.GetItemText(i1,i0,szBuffer,sizeof(szBuffer));
				uiColumnWidth=max(m_ctlList2.GetStringWidth(szBuffer)+12,uiColumnWidth);
			}
			if(m_ctlList2.GetColumnWidth(i0)!=uiColumnWidth)
				m_ctlList2.SetColumnWidth(i0,uiColumnWidth);
		}
	}
	m_ctlList2.SetRedraw();
}

void CSuperJukeboxDlg::UpdateList1()
{
	if(seList1.size())
	{
		m_ctlList1.DeleteAllItems();
		InsertList1Items(0,0,seList1.size()-1);
	}
}

void CSuperJukeboxDlg::UpdateList2()
{
	if(seList2.size())
	{
		m_ctlList2.DeleteAllItems();
		InsertList2Items(0,0,seList2.size()-1);
	}
}

void CSuperJukeboxDlg::HighlightListEntry(CListCtrl &ctlList,int iEntry)
{
	if(iEntry>=0&&iEntry<ctlList.GetItemCount())
	{
		CWnd* cWndSpare=GetFocus();
		POSITION pos=ctlList.GetFirstSelectedItemPosition();
		bInternalCall=TRUE;
		while(pos)ctlList.SetItemState(ctlList.GetNextSelectedItem(pos),0,LVIS_SELECTED);
		ctlList.SetItemState(iEntry,LVIS_SELECTED|LVIS_FOCUSED,LVIS_SELECTED|LVIS_FOCUSED);
		bInternalCall=FALSE;
		ctlList.EnsureVisible(iEntry,FALSE);
		if(cWndSpare)cWndSpare->SetFocus();
	}
}

void CSuperJukeboxDlg::OnRclickList2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	POINT point=((LPNMITEMACTIVATE)pNMHDR)->ptAction;
	m_ctlList2.ClientToScreen(&point);
	CMenu*cTempMenu=cMenu1.GetSubMenu(0);
	UINT uState=m_ctlList2.GetItemState(LPNMITEMACTIVATE(pNMHDR)->iItem,LVIS_SELECTED)?MF_ENABLED:MF_GRAYED;
	cTempMenu->EnableMenuItem(ID_MENU_PLAYLIST_REMOVE,uState);
	cTempMenu->EnableMenuItem(ID_MENU_PLAYLIST_PLAY,uState);
	cTempMenu->EnableMenuItem(ID_MENU_PLAYLIST_PROPERTIES,uState);
	switch(cTempMenu->TrackPopupMenu(TPM_RIGHTBUTTON|TPM_NONOTIFY|TPM_RETURNCMD,point.x,point.y,this))
	{
	case ID_MENU_PLAYLIST_REMOVE:OnButtonRemove();break;
	case ID_MENU_PLAYLIST_PLAY:OnButtonPlay();break;
	case ID_MENU_PLAYLIST_PROPERTIES:OnViewProperties();break;
	case ID_MENU_PLAYLIST_STATISTICS:OnHelpAboutSuperJukebox();break;
	}
	*pResult = 0;
}

BOOL CSuperJukeboxDlg::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	if(reg.bActiveWallpaper)
	{
		return TRUE;
	}
	else if(PlaylistPropsDlg.m_bUseSkin==TRUE&&hDCAdjustedSkin!=NULL)
	{
		BitBlt(pDC->GetSafeHdc(),0,0,iSJWidth,iSJHeight,hDCAdjustedSkin,0,0,SRCCOPY);
		return TRUE;
	}
	else
	{
		return CDialog::OnEraseBkgnd(pDC);
	}
}

void CSuperJukeboxDlg::OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI) 
{
	// TODO: Add your message handler code here and/or call default
	SIZE sz[4]=
	{
		133,415,
		119,431,
		420,415,
		705,277,
	};

	int nExtraY=0;
	if(iSJWidth<=187)
		nExtraY=GetSystemMetrics(SM_CYMENU);

	if(reg.dwLayoutScheme)
	{
		lpMMI->ptMinTrackSize.x=sz[reg.dwLayoutScheme-1].cx+GetSystemMetrics(SM_CXSIZEFRAME)*2;
		lpMMI->ptMinTrackSize.y=sz[reg.dwLayoutScheme-1].cy+GetSystemMetrics(SM_CYSIZEFRAME)*2+GetSystemMetrics(SM_CYCAPTION)+GetSystemMetrics(SM_CYMENU)+nExtraY;
	}
	
	CDialog::OnGetMinMaxInfo(lpMMI);
}

void CSuperJukeboxDlg::OnSize(UINT nType, int cx, int cy) 
{
	CDialog::OnSize(nType, cx, cy);
		
	// TODO: Add your message handler code here
	Layout_ComputeLayout(GetSafeHwnd(),LayoutRules[reg.dwLayoutScheme]);

	if(IsWindow(m_StatusBar.GetSafeHwnd()))
	{
		SIZE sz;
		CString str;
		int iParts[4];

		str.Format("Song: 000 of 000");
		GetTextExtentPoint32(m_StatusBar.GetDC()->GetSafeHdc(),str,strlen(str),&sz);
		iParts[0]=sz.cx;
		str.Format("Elapsed time: 00:00 of 00:00");
		GetTextExtentPoint32(m_StatusBar.GetDC()->GetSafeHdc(),str,strlen(str),&sz);	
		iParts[1]=iParts[0]+sz.cx;
		iParts[2]=iParts[1]+100;
		iParts[3]=cx;
		m_StatusBar.SetParts(4,iParts);
	}

	RECT rt;
	GetClientRect(&rt);
	iSJWidth=rt.right;
	if(reg.bShowVisWindow&&IsWindow(m_VisWindow.GetSafeHwnd()))
		m_VisWindow.GetWindowRect(&rt);
	else if(!reg.bShowVisWindow&&IsWindow(m_StatusBar.GetSafeHwnd()))
		m_StatusBar.GetWindowRect(&rt);
	ScreenToClient(&rt);
	iSJHeight=rt.top;

	if(reg.bActiveWallpaper)
		m_ActiveWallpaper.SetParameters(this->GetSafeHwnd(),30,iSJWidth,iSJHeight);

	RefreshSkin();
	RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_UPDATENOW|RDW_ERASE|RDW_ALLCHILDREN);
}

int CSuperJukeboxDlg::MapColumnText(LPCTSTR lpszColumn)
{
	for(int i=1,nCol=0;i<NUMBER_OF_COLUMNS;i++)
	{
		if(reg.stColumnsInfo[i].bActive)
		{
			if(!stricmp(reg.stColumnsInfo[i].szName,lpszColumn))
				return nCol;
			nCol++;
		}
	}
	return -1;
}

void CSuperJukeboxDlg::SetColumnText(int nItem,LPCTSTR lpszColumn,LPCTSTR lpszText,int nImage)
{
	int nCol=MapColumnText(lpszColumn);

	if(!nCol)
	{
		LVITEM item;
		item.iItem=nItem;
		item.iSubItem=nCol;
		item.mask=LVIF_TEXT|LVIF_PARAM|LVIF_IMAGE;
		item.pszText=(char*)lpszText;
		item.iImage=nImage;
		item.lParam=nItem;
		m_ctlList2.InsertItem(&item);
	}
	else if(nCol>0)
		m_ctlList2.SetItemText(nItem,nCol,lpszText);
}

int CALLBACK CSuperJukeboxDlg::CompFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort)
{
	CListCtrl *pListCtrl=(CListCtrl*)lParamSort;
	LVFINDINFO info;
	info.flags=LVFI_PARAM;
	info.lParam=lParam1;
	int nItem1=pListCtrl->FindItem(&info);
	info.flags=LVFI_PARAM;
	info.lParam=lParam2;
	int nItem2=pListCtrl->FindItem(&info);
	CString strItem1=pListCtrl->GetItemText(nItem1,iSortMethod);
	CString strItem2=pListCtrl->GetItemText(nItem2,iSortMethod);

	char szColumnText[20];
	GetColumnText(iSortMethod,szColumnText,20);

	if(!strcmp(szColumnText,"Length")||!strcmp(szColumnText,"Fade"))
	{
		int iVar1=ConvertTimeDown(strItem1);
		int iVar2=ConvertTimeDown(strItem2);
		return iVar1>iVar2*(bSortAscending?1:-1);
	}
	else if(!strcmp(szColumnText,"Repetitions"))
	{
		int iVar1=atoi(strItem1);
		int iVar2=atoi(strItem2);
		return iVar1>iVar2*(bSortAscending?1:-1);
	}
	else
	{
		return stricmp(strItem1,strItem2)*(bSortAscending?1:-1);
	}
}

void CSuperJukeboxDlg::OnColumnclickList2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_LISTVIEW* pNMListView = (NM_LISTVIEW*)pNMHDR;
	// TODO: Add your control notification handler code here
	if(pNMListView->iSubItem==iSortMethod)
		bSortAscending^=1;
	else
		bSortAscending=TRUE;

	LVCOLUMN Column;
	if(iSortMethod>=0)
	{
		Column.mask=LVCF_FMT;
		Column.fmt=LVCFMT_LEFT;
		m_ctlList2.SetColumn(iSortMethod,&Column);		
	}

	iSortMethod=pNMListView->iSubItem;
	m_ctlList2.SortItems(CompFunc,(LPARAM)&m_ctlList2);

	Column.mask=LVCF_FMT|LVCF_IMAGE;
	Column.fmt=LVCFMT_LEFT|LVCFMT_IMAGE|LVCFMT_BITMAP_ON_RIGHT;
	Column.iImage=bSortAscending;
	m_ctlList2.SetColumn(iSortMethod,&Column);

	std::vector<SongEntry>seSpareList;
	seSpareList.clear();
	for(int i=0;i<seList2.size();i++)
	{
		LVITEM item;
		item.mask=LVIF_PARAM;
		item.iItem=i;
		item.iSubItem=0;
		m_ctlList2.GetItem(&item);
		seSpareList.push_back(seList2[item.lParam]);
	}
	seList2.clear();
	for(i=0;i<seSpareList.size();i++)
	{
		seList2.push_back(seSpareList[i]);
		LVITEM item;
		item.mask=LVIF_PARAM;
		item.iItem=i;
		item.iSubItem=0;
		item.lParam=i;
		m_ctlList2.SetItem(&item);
	}
	bNeedsSaving=TRUE;
	
	*pResult = 0;
}

BOOL CSuperJukeboxDlg::OnQueryEndSession()
{
	if (!CDialog::OnQueryEndSession())
		return FALSE;
	
	// TODO: Add your specialized query end session code here
	if(bNeedsSaving==TRUE&&seList2.size()>0)
	{
		CString cstrBuffer;
		cstrBuffer.Format("Save changes to %s?",cstrOpenedPlaylist);
		int iRes=MessageBox(cstrBuffer,NULL,MB_YESNOCANCEL|MB_ICONQUESTION);
		if(iRes==IDYES)OnFileSave();
		else if(iRes==IDCANCEL)return FALSE;
	}
	
	return TRUE;
}

void CSuperJukeboxDlg::OnEndSession(BOOL bEnding) 
{
	CDialog::OnEndSession(bEnding);
	
	// TODO: Add your message handler code here
	if(bEnding)
		DestroyWindow();
}

int CSuperJukeboxDlg::GetColumnText(int iColumn, LPTSTR lpszText, int nMaxChar)
{
 	for(int i=1,nCol=0;i<NUMBER_OF_COLUMNS;i++)
 		if(reg.stColumnsInfo[i].bActive)
 		{
 			if(nCol==iColumn)
 			{
 				strncpy(lpszText,reg.stColumnsInfo[i].szName,nMaxChar);
 				return i;
 			}
 			nCol++;
 		}

 	return -1;
}

BOOL CSuperJukeboxDlg::LoadSkin(LPCTSTR lpszSkinFile)
{
	if(PlaylistPropsDlg.m_bUseSkin==FALSE)
		return FALSE;

	if(hDCSkin)DeleteDC(hDCSkin);
	if(hBmpSkin)DeleteObject(hBmpSkin);

	for(int i=0;i<3;i++)
	{
		char szBuffer[MAX_PATH],szName[_MAX_FNAME],szExt[_MAX_EXT];
		switch(i)
		{
		case 0:strcpy(szBuffer,lpszSkinFile);break;
		case 1:
			_splitpath(lpszSkinFile,NULL,NULL,szName,szExt);
			sprintf(szBuffer,"%s%s%s",szPlaylistLocation,szName,szExt);
			break;
		case 2:
			_splitpath(lpszSkinFile,NULL,NULL,szName,szExt);
			sprintf(szBuffer,"%s%s%s",szProgramLocation,szName,szExt);
			break;
		}
		if((hBmpSkin=(HBITMAP)LoadImage(NULL,szBuffer,IMAGE_BITMAP,0,0,LR_LOADFROMFILE))!=NULL)
			break;
	}
	if(hBmpSkin==NULL)
	{
		char szName[_MAX_FNAME],szExt[_MAX_EXT];
		_splitpath(lpszSkinFile,NULL,NULL,szName,szExt);
		CString cstrBuffer;
		cstrBuffer.Format("After searching the directory specified in the playlist, the directory of the playlist and the directory of the program, still failed to locate the file \"%s%s\"",szName,szExt);
		MessageBox(cstrBuffer,NULL,MB_ICONERROR);
		return FALSE;
	}
	else
	{
		hDCSkin=CreateCompatibleDC(GetDC()->GetSafeHdc());
		SelectObject(hDCSkin,hBmpSkin);
		BITMAP bitmap;
		GetObject(hBmpSkin,sizeof(BITMAP),&bitmap);
		iSkinWidth=bitmap.bmWidth;
		iSkinHeight=bitmap.bmHeight;
	}
	return TRUE;
}

void CSuperJukeboxDlg::RefreshSkin()
{
	if(PlaylistPropsDlg.m_bUseSkin==FALSE||iSJWidth<0||iSJHeight<0)
		return;

	if(hDCAdjustedSkin)DeleteDC(hDCAdjustedSkin);
	if(hBmpAdjustedSkin)DeleteObject(hBmpAdjustedSkin);

	hDCAdjustedSkin=CreateCompatibleDC(GetDC()->GetSafeHdc());
	hBmpAdjustedSkin=CreateCompatibleBitmap(GetDC()->GetSafeHdc(),iSJWidth,iSJHeight);
	SelectObject(hDCAdjustedSkin,hBmpAdjustedSkin);

	if(PlaylistPropsDlg.m_nSkinLayout)
	{
		if(!StretchBlt(hDCAdjustedSkin,0,0,iSJWidth,iSJHeight,hDCSkin,0,0,iSkinWidth,iSkinHeight,SRCCOPY))
		{
			if(MessageBox("Windows cannot stretch the skin bitmap any further, do you want to switch to tiled mode instead?\nClick Yes to use tiled mode, or click No to disable the skin.",NULL,MB_ICONQUESTION|MB_YESNO)==IDYES)
			{
				PlaylistPropsDlg.m_nSkinLayout=0;
				int cbx=iSJWidth/iSkinWidth;
				int cby=iSJHeight/iSkinHeight;
				for(int y=0;y<=cby;y++)
					for(int x=0;x<=cbx;x++)
						BitBlt(hDCAdjustedSkin,x*iSkinWidth,y*iSkinHeight,iSkinWidth,iSkinHeight,hDCSkin,0,0,SRCCOPY);
			}
			else
			{
				PlaylistPropsDlg.m_bUseSkin=FALSE;
			}
		}
	}
	else
	{
		int cbx=iSJWidth/iSkinWidth;
		int cby=iSJHeight/iSkinHeight;
		for(int y=0;y<=cby;y++)
			for(int x=0;x<=cbx;x++)
				BitBlt(hDCAdjustedSkin,x*iSkinWidth,y*iSkinHeight,iSkinWidth,iSkinHeight,hDCSkin,0,0,SRCCOPY);
	}
}

void CSuperJukeboxDlg::LoadControlRects()
{
	m_ctlList1.GetWindowRect(&reg.List0Rect);
	ScreenToClient(&reg.List0Rect);
	m_ctlList2.GetWindowRect(&reg.List1Rect);
	ScreenToClient(&reg.List1Rect);
	m_ctlButton1.GetWindowRect(&reg.ButtonsRect);
	RECT rt;
	m_ctlButton9.GetWindowRect(&rt);
	reg.ButtonsRect.right=rt.right;
	reg.ButtonsRect.bottom=rt.bottom;
	ScreenToClient(&reg.ButtonsRect);
}

void CSuperJukeboxDlg::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(reg.dwLayoutScheme)
		return;

	RECT rect[3],rtSpare,rtMainWnd;

	SetRect(&rtMainWnd,0,0,iSJWidth,iSJHeight);
	rect[0]=reg.List0Rect;
	rect[1]=reg.ButtonsRect;
	rect[2]=reg.List1Rect;

	if(dwMouseButtons&1)
	{
		int i=iMousePos/4,x,y,w,h;

		switch(iMousePos%4)
		{
		case 0:
			x=point.x+1;y=rect[i].top;
			w=rect[i].right-rect[i].left;h=rect[i].bottom-rect[i].top;
			break;
		case 1:
			x=rect[i].left;y=rect[i].top;
			w=point.x-rect[i].left;h=rect[i].bottom-rect[i].top;			
			break;
		case 2:
			x=rect[i].left;y=point.y+1;
			w=rect[i].right-rect[i].left;h=rect[i].bottom-rect[i].top;
			break;
		case 3:
			x=rect[i].left;y=rect[i].top;
			w=rect[i].right-rect[i].left;h=point.y-rect[i].top;			
			break;
		}
		SetRect(&rtSpare,x,y,x+w,y+h);
		if(iMousePos%4==0||iMousePos%4==2)
			AdjustRect(&rtSpare,rtMainWnd,1,0);
		else
			AdjustRect(&rtSpare,rtMainWnd,0,1);
		if(!IsOverlapped(rtSpare,3,i,rect))
		{
			switch(iMousePos/4)
			{
			case 0:
				reg.List0Rect=rtSpare;
				PositionControls(4);
				RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_UPDATENOW|RDW_ERASE|RDW_ALLCHILDREN);
				break;
			case 1:
				reg.ButtonsRect=rtSpare;
				PositionControls(2);
				RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_UPDATENOW|RDW_ERASE|RDW_ALLCHILDREN);
				break;
			case 2:
				reg.List1Rect=rtSpare;
				PositionControls(8);
				RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_UPDATENOW|RDW_ERASE|RDW_ALLCHILDREN);
				break;
			}
		}
	}
	else
	{
		iMousePos=-1;
		for(int i=0;i<3;i++)
		{
			if(IsInRange(point.x,rect[i].left-1,0)&&point.y>=rect[i].top-1&&point.y<=rect[i].bottom)
			{iMousePos=i*4;break;}
			else if(IsInRange(point.x,rect[i].right,0)&&point.y>=rect[i].top-1&&point.y<=rect[i].bottom)
			{iMousePos=i*4+1;break;}
			else if(IsInRange(point.y,rect[i].top-1,0)&&point.x>=rect[i].left-1&&point.x<=rect[i].right)
			{iMousePos=i*4+2;break;}
			else if(IsInRange(point.y,rect[i].bottom,0)&&point.x>=rect[i].left-1&&point.x<=rect[i].right)
			{iMousePos=i*4+3;break;}
		}
	}

	if(iMousePos%4==0||iMousePos%4==1)
		SetCursor(hCursor0);
	else if(iMousePos%4==2||iMousePos%4==3)
		SetCursor(hCursor1);
	else
		SetCursor((HCURSOR)GetClassLong(GetSafeHwnd(),GCL_HCURSOR));

	CDialog::OnMouseMove(nFlags, point);
}

void CSuperJukeboxDlg::OnLButtonDown(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(reg.dwLayoutScheme)
		return;

	dwMouseButtons|=1;

	if(iMousePos%4==0||iMousePos%4==1)
		SetCursor(hCursor0);
	else if(iMousePos%4==2||iMousePos%4==3)
		SetCursor(hCursor1);
	else
		SetCursor((HCURSOR)GetClassLong(m_hWnd,GCL_HCURSOR));

	if(iMousePos>=0&&iMousePos<=11)
	{
		SetCapture();
	}
	
	CDialog::OnLButtonDown(nFlags, point);
}

void CSuperJukeboxDlg::OnLButtonUp(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	if(reg.dwLayoutScheme)
		return;

	dwMouseButtons&=~1;

	if(iMousePos%4==0||iMousePos%4==1)
		SetCursor(hCursor0);
	else if(iMousePos%4==2||iMousePos%4==3)
		SetCursor(hCursor1);
	else
		SetCursor((HCURSOR)GetClassLong(m_hWnd,GCL_HCURSOR));
	
	if(iMousePos>=0&&iMousePos<=11)
	{
		ReleaseCapture();
	}

	CDialog::OnLButtonUp(nFlags, point);
}

void CSuperJukeboxDlg::PositionControls(DWORD dwFlags)
{
	if(reg.dwLayoutScheme)
		return;

	RECT rect;
	if(dwFlags&2)
	{
		for(int i=0;i<NUMBER_OF_BUTTONS;i++)
		{
			double dHeight=double(reg.ButtonsRect.bottom-reg.ButtonsRect.top)/NUMBER_OF_BUTTONS;
			rect.left=reg.ButtonsRect.left;
			rect.top=reg.ButtonsRect.top+i*dHeight;
			rect.right=reg.ButtonsRect.right;
			rect.bottom=rect.top+dHeight;
			if(i==NUMBER_OF_BUTTONS-1)
				rect.bottom=reg.ButtonsRect.bottom;
			btns[i]->MoveWindow(&rect,FALSE);
		}
	}
	if(dwFlags&4)
		m_ctlList1.MoveWindow(&reg.List0Rect,FALSE);
	if(dwFlags&8)
		m_ctlList2.MoveWindow(&reg.List1Rect,FALSE);
	if(dwFlags&16&&reg.bShowVisWindow)
		m_VisWindow.MoveWindow(0,iSJHeight,iSJWidth,130,FALSE);
}

void CSuperJukeboxDlg::UpdateListColumns()
{
	while(m_ctlList1.GetHeaderCtrl()->GetItemCount())
		m_ctlList1.DeleteColumn(0);
	while(m_ctlList2.GetHeaderCtrl()->GetItemCount())
		m_ctlList2.DeleteColumn(0);

	for(int i=0,nCol=0;i<NUMBER_OF_COLUMNS;i++)
	{
		if(reg.stColumnsInfo[i].bActive)
		{
			if(i==0)
				m_ctlList1.InsertColumn(i,reg.stColumnsInfo[i].szName,LVCFMT_LEFT,reg.stColumnsInfo[i].iWidth);
			else
				m_ctlList2.InsertColumn(nCol++,reg.stColumnsInfo[i].szName,LVCFMT_LEFT,reg.stColumnsInfo[i].iWidth);
		}
	}
	iSortMethod=-1;
}

void CSuperJukeboxDlg::UpdateLayout(BOOL bShowVis)
{
	if(!bShowVis)
	{
		for(int x=0;x<5;x++)
			for(int y=0;y<3;y++)
				LayoutRules[x][y].Action=lNULL;
		LayoutRules[1][27].RelTo.idc=IDC_STATUS_BAR;
		LayoutRules[2][31].RelTo.idc=IDC_STATUS_BAR;
		LayoutRules[3][27].RelTo.idc=IDC_STATUS_BAR;
		LayoutRules[3][31].RelTo.idc=IDC_STATUS_BAR;
		LayoutRules[4][31].RelTo.idc=IDC_STATUS_BAR;
	}
	else
	{
		for(int x=0;x<5;x++)
			for(int y=0;y<3;y++)
				LayoutRules[x][y].Action=y%2==0?lSTRETCH:lMOVE;
		LayoutRules[1][27].RelTo.idc=IDC_VIS_WINDOW;
		LayoutRules[2][31].RelTo.idc=IDC_VIS_WINDOW;
		LayoutRules[3][27].RelTo.idc=IDC_VIS_WINDOW;
		LayoutRules[3][31].RelTo.idc=IDC_VIS_WINDOW;
		LayoutRules[4][31].RelTo.idc=IDC_VIS_WINDOW;
	}
}

void CSuperJukeboxDlg::OnFileNew() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	if(bNeedsSaving==TRUE&&seList2.size()>0)
	{
		CString cstrBuffer;
		cstrBuffer.Format("Save changes to %s?",cstrOpenedPlaylist);
		int iRes=MessageBox(cstrBuffer,NULL,MB_YESNOCANCEL|MB_ICONQUESTION);
		if(iRes==IDYES)
			OnFileSave();
		else if(iRes==IDCANCEL)
			return;
	}
	OnButtonStop();
	iPlayingSong=iCurrentSong=-1;
	iSongLength=iFadeLength=0;
	iSongRepetitions=1;
	CPlaylistPropsDlg _PlaylistPropsDlg;
	PlaylistPropsDlg=_PlaylistPropsDlg;
	seList2.clear();
	m_ctlList2.DeleteAllItems();
	cstrOpenedPlaylist="Untitled";
	bNeedsSaving=FALSE;
	LoadSkin(PlaylistPropsDlg.m_cstrSkinFile);
	RefreshSkin();
	RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_UPDATENOW|RDW_ERASE|RDW_ALLCHILDREN);

	UpdateTitleBar();
	UpdateButtonStates();
}

void CSuperJukeboxDlg::OnFileOpen() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	if(bNeedsSaving==TRUE&&seList2.size()>0)
	{
		CString cstrBuffer;
		cstrBuffer.Format("Save changes to %s?",cstrOpenedPlaylist);
		int iRes=MessageBox(cstrBuffer,NULL,MB_YESNOCANCEL|MB_ICONQUESTION);
		if(iRes==IDYES)
			OnFileSave();
		else if(iRes==IDCANCEL)
			return;
	}
	CFileDialog dlg(TRUE,"PL",cstrOpenedPlaylist,OFN_NOCHANGEDIR|OFN_HIDEREADONLY,"Playlist Files (.PL)|*.PL|All Files (*.*)|*.*||");
	if(dlg.DoModal()!=IDOK)return;
	if(!LoadPlayList(dlg.GetPathName()))
	{
		if(bPlaying||bPaused)
			OnButtonStop();
		bNeedsSaving=FALSE;
	}

	LoadSkin(PlaylistPropsDlg.m_cstrSkinFile);
	RefreshSkin();
	RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_UPDATENOW|RDW_ERASE|RDW_ALLCHILDREN);

	UpdateTitleBar();
	UpdateButtonStates();
}

void CSuperJukeboxDlg::OnFileSave() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	WIN32_FIND_DATA w32FindData;
	HANDLE hFindFile;
	if((hFindFile=FindFirstFile(cstrOpenedPlaylist,&w32FindData))!=INVALID_HANDLE_VALUE)
	{
		FindClose(hFindFile);
		if(!SavePlayList(cstrOpenedPlaylist))
			bNeedsSaving=FALSE;
		UpdateTitleBar();
		UpdateButtonStates();
	}
	else
	{
		OnFileSaveAs();
	}
}

void CSuperJukeboxDlg::OnFileSaveAs() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	CFileDialog dlg(FALSE,"PL",cstrOpenedPlaylist,OFN_NOCHANGEDIR|OFN_OVERWRITEPROMPT|OFN_HIDEREADONLY,"Playlist Files (.PL)|*.PL|All Files (*.*)|*.*||");
	if(dlg.DoModal()!=IDOK)return;
	if(!SavePlayList(dlg.GetPathName()))
		bNeedsSaving=FALSE;

	UpdateTitleBar();
	UpdateButtonStates();
}

void CSuperJukeboxDlg::OnFileProperties() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	char szBuf[20];
	ConvertTimeUp(iSongLength,szBuf);
	PlaylistPropsDlg.m_strLength=szBuf;
	ConvertTimeUp(iFadeLength,szBuf);
	PlaylistPropsDlg.m_strFade=szBuf;
	PlaylistPropsDlg.m_strRepetitions.Format("%d",iSongRepetitions);
	PlaylistPropsDlg.iSJWidth=iSJWidth;
	PlaylistPropsDlg.iSJHeight=iSJHeight;

	CPlaylistPropsDlg _PlaylistPropsDlg;
	_PlaylistPropsDlg=PlaylistPropsDlg;

	if(PlaylistPropsDlg.DoModal()==IDCANCEL)
		return;

	BOOL bReplay=FALSE;

	if(PlaylistPropsDlg.m_nMode!=_PlaylistPropsDlg.m_nMode)
		bReplay=bNeedsSaving=TRUE;
	if(PlaylistPropsDlg.m_strLength!=_PlaylistPropsDlg.m_strLength)
	{
		if(PlaylistPropsDlg.m_nMode==1)
			iSongLength=ConvertTimeDown(PlaylistPropsDlg.m_strLength);
		bReplay=bNeedsSaving=TRUE;
	}
	if(PlaylistPropsDlg.m_strFade!=_PlaylistPropsDlg.m_strFade)
	{
		if(PlaylistPropsDlg.m_nMode==1)
			iFadeLength=ConvertTimeDown(PlaylistPropsDlg.m_strFade);
		bReplay=bNeedsSaving=TRUE;
	}
	if(PlaylistPropsDlg.m_strRepetitions!=_PlaylistPropsDlg.m_strRepetitions)
	{
		if(PlaylistPropsDlg.m_nMode==1)
			iSongRepetitions=ConvertTimeDown(PlaylistPropsDlg.m_strRepetitions);
		bReplay=bNeedsSaving=TRUE;
	}
	if(PlaylistPropsDlg.m_bAutoRewind!=_PlaylistPropsDlg.m_bAutoRewind)
		bNeedsSaving=TRUE;
	if(PlaylistPropsDlg.m_bFadeOut!=_PlaylistPropsDlg.m_bFadeOut)
		bReplay=bNeedsSaving=TRUE;
	if(PlaylistPropsDlg.m_bRandomize!=_PlaylistPropsDlg.m_bRandomize)
		bNeedsSaving=TRUE;
	if(PlaylistPropsDlg.m_bDetectSilence!=_PlaylistPropsDlg.m_bDetectSilence)
		bNeedsSaving=TRUE;
	if(PlaylistPropsDlg.m_bUseSkin!=_PlaylistPropsDlg.m_bUseSkin||PlaylistPropsDlg.m_nSkinLayout!=_PlaylistPropsDlg.m_nSkinLayout||PlaylistPropsDlg.m_cstrSkinFile!=_PlaylistPropsDlg.m_cstrSkinFile)
	{
		LoadSkin(PlaylistPropsDlg.m_cstrSkinFile);
		RefreshSkin();
		bNeedsSaving=TRUE;
		RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_UPDATENOW|RDW_ERASE|RDW_ALLCHILDREN);
	}

	if(bReplay&&bPlaying)
		OnButtonPlay();

	UpdateTitleBar();
	UpdateButtonStates();
}

void CSuperJukeboxDlg::OnFileExit() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	OnCancel();
}

void CSuperJukeboxDlg::OnEditCut() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	bInternalCall=TRUE;
	OnEditCopy();
	OnEditDelete();
	bInternalCall=FALSE;
}

void CSuperJukeboxDlg::OnEditCopy() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	POSITION pos=m_ctlList2.GetFirstSelectedItemPosition();
	seClipboard.clear();
	while(pos)
	{
		int nItem=m_ctlList2.GetNextSelectedItem(pos);
		seClipboard.push_back(seList2[nItem]);
	}
}

void CSuperJukeboxDlg::OnEditPaste() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	if(seClipboard.size())
	{
		POSITION pos=m_ctlList2.GetFirstSelectedItemPosition();
		int nItem=m_ctlList2.GetNextSelectedItem(pos);
		if(nItem<0)nItem=0;
		int iClipboardEntries=seClipboard.size();
		for(int i=0;i<iClipboardEntries;i++)
		{
			seList2.insert(seList2.begin()+nItem+i,seClipboard[i]);
		}
		InsertList2Items(nItem,nItem,nItem+iClipboardEntries-1);
		if(!m_ctlList2.GetSelectedCount())HighlightListEntry(m_ctlList2,iCurrentSong=0);
		else iCurrentSong+=iClipboardEntries;
		bNeedsSaving=TRUE;

		LVCOLUMN Column;
		Column.mask=LVCF_FMT;
		Column.fmt=LVCFMT_LEFT;
		m_ctlList2.SetColumn(iSortMethod,&Column);
		iSortMethod=-1;
	}

	UpdateTitleBar();
	UpdateButtonStates();
}

void CSuperJukeboxDlg::OnEditDelete() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	bInternalCall=TRUE;
	OnButtonRemove();
	bInternalCall=FALSE;
}

void CSuperJukeboxDlg::OnEditSelectAll() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	for(int i=0;i<m_ctlList2.GetItemCount();i++)
		m_ctlList2.SetItemState(i,LVIS_SELECTED,LVIS_SELECTED);	
}

void CSuperJukeboxDlg::OnEditFind() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	if(FindDlg.DoModal()==IDCANCEL)
		return;

	char *pdest=NULL,szBuffer[1000],szBuffer1[1000];
	strcpy(szBuffer1,FindDlg.m_strFind);
	int iStart=iCurrentSong;

	for(int i=FindDlg.m_iDirection?iStart+1:iStart-1;FindDlg.m_iDirection?i<seList2.size():i>=0;FindDlg.m_iDirection?i++:i--)
	{
		switch(FindDlg.m_iSearchColumn)
		{
		case 0:
			strcpy(szBuffer,seList2[i].szName);
			break;
		case 1:
			strcpy(szBuffer,seList2[i].ID666.Song);
			break;
		case 2:
			strcpy(szBuffer,seList2[i].ID666.Game);
			break;
		case 3:
			strcpy(szBuffer,seList2[i].ID666.Artist);
			break;
		case 4:
			strcpy(szBuffer,seList2[i].ID666.Dumper);
			break;
		case 5:
			strcpy(szBuffer,seList2[i].ID666.Date);
			break;
		case 6:
			strcpy(szBuffer,seList2[i].ID666.Comment);
			break;
		case 7:
			ConvertTimeUp(seList2[i].iLength,szBuffer);
			break;
		case 8:
			ConvertTimeUp(seList2[i].iFadeLength,szBuffer);
			break;
		case 9:
			itoa(seList2[i].iRepetitions,szBuffer,10);
			break;
		}
		if(!FindDlg.m_bCase)
		{
			strlwr(szBuffer);
			strlwr(szBuffer1);
		}
		pdest=strstr(szBuffer,szBuffer1);
		if(pdest!=NULL)
		{
			if(FindDlg.m_bWholeWord)
			{
				BOOL bBefore,bAfter;
				if(pdest>szBuffer)
					bBefore=__iscsym(*(pdest-1));
				else bBefore=FALSE;
				bAfter=__iscsym(*(pdest+strlen(szBuffer1)));
				if(!bBefore&&!bAfter)
					break;
			}
			else break;
		}
	}
	if(pdest!=NULL)
		HighlightListEntry(m_ctlList2,i);
	else
		MessageBox("Search string not found.","Find",MB_ICONINFORMATION);
}

void CSuperJukeboxDlg::OnEditGoTo() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	GoToDlg.m_uiSongNumber=iCurrentSong+1;
	if(GoToDlg.m_uiSongNumber<1)
		GoToDlg.m_uiSongNumber=1;
	GoToDlg.uiTotalSongs=m_ctlList2.GetItemCount();
	if(GoToDlg.DoModal()==IDOK)
	{
		HighlightListEntry(m_ctlList2,GoToDlg.m_uiSongNumber-1);
	}
}

void CSuperJukeboxDlg::OnViewRefresh() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	int iRes;
	char szBuffer[MAX_PATH],szExt[_MAX_EXT];
	_splitpath(szListingSource,NULL,NULL,szBuffer,szExt);
	strcat(szBuffer,szExt);
	switch(iListingType)
	{
	case LIST_ID_DIR:
		iRes=LoadFileList();
		break;
	case LIST_ID_ACE:
		iRes=LoadFileListFromACE(szBuffer);
		break;
	case LIST_ID_RAR:
		iRes=LoadFileListFromRAR(szBuffer);
		break;
	case LIST_ID_ZIP:
		iRes=LoadFileListFromZIP(szBuffer);
		break;
	}
	if(iRes)
	{
		MessageBox("Failed to reload the file list.",NULL,MB_ICONERROR);
	}
	UpdateList1();
	HighlightListEntry(m_ctlList1,iCurrentFileSelection);
	UpdateList2();
	HighlightListEntry(m_ctlList2,iCurrentSong);
	RefreshSkin();
	RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_UPDATENOW|RDW_ERASE|RDW_ALLCHILDREN);
}

void CSuperJukeboxDlg::OnViewHideWindows()
{
	reg.bShowControls^=1;
	m_ctlList1.ModifyStyle(reg.bShowControls?0:WS_VISIBLE,reg.bShowControls?WS_VISIBLE:0);
	m_ctlList2.ModifyStyle(reg.bShowControls?0:WS_VISIBLE,reg.bShowControls?WS_VISIBLE:0);
	for(int i=0;i<NUMBER_OF_BUTTONS;i++)
	{
		btns[i]->ModifyStyle(reg.bShowControls?0:WS_VISIBLE,reg.bShowControls?WS_VISIBLE:0);
	}
	UpdateList1();
	HighlightListEntry(m_ctlList1,iCurrentFileSelection);
	UpdateList2();
	HighlightListEntry(m_ctlList2,iCurrentSong);
	RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_UPDATENOW|RDW_ERASE|RDW_ALLCHILDREN);
}

void CSuperJukeboxDlg::OnViewProperties() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	SongPropsDlg.m_bModified=FALSE;
	if(SongPropsDlg.DoModal()==IDCANCEL)
		return;

	if(SongPropsDlg.m_bModified)
	{
		UpdateList2();
		bNeedsSaving=TRUE;
	}

	UpdateTitleBar();
	UpdateButtonStates();
}

void CSuperJukeboxDlg::OnSettingsConfigure() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	BOOL bReplay=FALSE,bRedraw=FALSE;

	cPropPage1.m_nSpectrumSize=reg.dwSpectrumSize;
	cPropPage1.m_nButtonStyle=reg.dwButtonStyle;
	cPropPage1.m_bShowTitleBar=reg.bShowTitleBar;
	cPropPage1.m_nVisRate=reg.dwVisRate;
	cPropPage1.m_nVisMode=reg.dwVisMode;
	cPropPage1.m_nLayout=reg.dwLayoutScheme;
	cPropPage1.m_bShowVisualization=reg.bShowVisWindow;
	cPropPage1.m_bFullRowSelect=reg.bFullRowSelect;
	cPropPage1.m_bShowGridlines=reg.bShowGridlines;
	cPropPage1.m_bFile=reg.stColumnsInfo[1].bActive;
	cPropPage1.m_bTitle=reg.stColumnsInfo[2].bActive;
	cPropPage1.m_bGame=reg.stColumnsInfo[3].bActive;
	cPropPage1.m_bArtist=reg.stColumnsInfo[4].bActive;
	cPropPage1.m_bDumper=reg.stColumnsInfo[5].bActive;
	cPropPage1.m_bDate=reg.stColumnsInfo[6].bActive;
	cPropPage1.m_bComment=reg.stColumnsInfo[7].bActive;
	cPropPage1.m_bLength=reg.stColumnsInfo[8].bActive;
	cPropPage1.m_bFade=reg.stColumnsInfo[9].bActive;
	cPropPage1.m_bRepetitions=reg.stColumnsInfo[10].bActive;

	cPropPage4.m_nBufferLength=reg.dwBufferLength;
	cPropPage4.m_bUseLPF=reg.bUseLPF;
	cPropPage4.m_bUseOldBRE=reg.bUseOldBRE;
	cPropPage4.m_nBits=reg.dwSampleSize==8?0:1;
	cPropPage4.m_nInterpolation=reg.dwInterpolation;
	cPropPage4.m_nChan=reg.dwChannels==1?0:1;
	cPropPage4.m_iPreamp=reg.dwPreamp;
	cPropPage4.m_nAPR=reg.bAPR;

	cPropPage5.m_bUseID666=reg.bUseID666;
	cPropPage5.m_bAutoLoadPlaylist=reg.bAutoLoadPlaylist;
	cPropPage5.m_bAutoSizeColumns=reg.bAutoSizeColumns;

	switch(reg.dwVisThreadPriority)
	{
	case THREAD_PRIORITY_IDLE:cPropPage1.m_nVisThreadPriority=0;break;
	case THREAD_PRIORITY_LOWEST:cPropPage1.m_nVisThreadPriority=1;break;
	case THREAD_PRIORITY_BELOW_NORMAL:cPropPage1.m_nVisThreadPriority=2;break;
	case THREAD_PRIORITY_NORMAL:cPropPage1.m_nVisThreadPriority=3;break;
	case THREAD_PRIORITY_ABOVE_NORMAL:cPropPage1.m_nVisThreadPriority=4;break;
	case THREAD_PRIORITY_HIGHEST:cPropPage1.m_nVisThreadPriority=5;break;
	case THREAD_PRIORITY_TIME_CRITICAL:cPropPage1.m_nVisThreadPriority=6;break;
	}
	switch(reg.dwSampleRate)
	{
	case 8000:cPropPage4.m_nFreq=0;break;
	case 11025:cPropPage4.m_nFreq=1;break;
	case 16000:cPropPage4.m_nFreq=2;break;
	case 22050:cPropPage4.m_nFreq=3;break;
	case 32000:cPropPage4.m_nFreq=4;break;
	case 44100:cPropPage4.m_nFreq=5;break;
	case 48000:cPropPage4.m_nFreq=6;break;
	case 64000:cPropPage4.m_nFreq=7;break;
	}
	switch(reg.dwMixingThreadPriority)
	{
	case THREAD_PRIORITY_IDLE:cPropPage4.m_nThreadPriority=0;break;
	case THREAD_PRIORITY_LOWEST:cPropPage4.m_nThreadPriority=1;break;
	case THREAD_PRIORITY_BELOW_NORMAL:cPropPage4.m_nThreadPriority=2;break;
	case THREAD_PRIORITY_NORMAL:cPropPage4.m_nThreadPriority=3;break;
	case THREAD_PRIORITY_ABOVE_NORMAL:cPropPage4.m_nThreadPriority=4;break;
	case THREAD_PRIORITY_HIGHEST:cPropPage4.m_nThreadPriority=5;break;
	case THREAD_PRIORITY_TIME_CRITICAL:cPropPage4.m_nThreadPriority=6;break;
	}
	switch(reg.dwPriorityClass)
	{
	case IDLE_PRIORITY_CLASS:cPropPage5.m_nPriority=0;break;
	case NORMAL_PRIORITY_CLASS:cPropPage5.m_nPriority=1;break;
	case HIGH_PRIORITY_CLASS:cPropPage5.m_nPriority=2;break;
	case REALTIME_PRIORITY_CLASS:cPropPage5.m_nPriority=3;break;
	}

	CPropPage1 _cPropPage1;
	_cPropPage1=cPropPage1;
	CPropPage4 _cPropPage4;
	_cPropPage4=cPropPage4;
	CPropPage5 _cPropPage5;
	_cPropPage5=cPropPage5;

	CConfigSheet sheet("Configuration");
	sheet.AddPage(&cPropPage4);
	sheet.AddPage(&cPropPage1);
	sheet.AddPage(&cPropPage5);
	sheet.SetActivePage(iPageJump);

	if(sheet.DoModal()!=IDOK)
		return;

	reg.dwSpectrumSize=cPropPage1.m_nSpectrumSize;
	reg.bShowTitleBar=cPropPage1.m_bShowTitleBar;
	reg.bFullRowSelect=cPropPage1.m_bFullRowSelect;
	reg.bShowGridlines=cPropPage1.m_bShowGridlines;
	reg.dwButtonStyle=cPropPage1.m_nButtonStyle;
	reg.dwVisRate=cPropPage1.m_nVisRate;
	reg.dwVisMode=cPropPage1.m_nVisMode;
	reg.dwLayoutScheme=cPropPage1.m_nLayout;
	reg.bShowVisWindow=cPropPage1.m_bShowVisualization;

	reg.dwBufferLength=cPropPage4.m_nBufferLength;
	reg.bUseLPF=cPropPage4.m_bUseLPF;
	reg.bUseOldBRE=cPropPage4.m_bUseOldBRE;
	reg.dwSampleSize=cPropPage4.m_nBits==0?8:16;
	reg.dwInterpolation=cPropPage4.m_nInterpolation;
	reg.dwChannels=cPropPage4.m_nChan==0?1:2;
	reg.dwPreamp=cPropPage4.m_iPreamp;
	reg.bAPR=cPropPage4.m_nAPR;

	reg.bAutoLoadPlaylist=cPropPage5.m_bAutoLoadPlaylist;
	reg.bAutoSizeColumns=cPropPage5.m_bAutoSizeColumns;
	reg.bUseID666=cPropPage5.m_bUseID666;

	switch(cPropPage1.m_nVisThreadPriority)
	{
	case 0:reg.dwVisThreadPriority=THREAD_PRIORITY_IDLE;break;
	case 1:reg.dwVisThreadPriority=THREAD_PRIORITY_LOWEST;break;
	case 2:reg.dwVisThreadPriority=THREAD_PRIORITY_BELOW_NORMAL;break;
	case 3:reg.dwVisThreadPriority=THREAD_PRIORITY_NORMAL;break;
	case 4:reg.dwVisThreadPriority=THREAD_PRIORITY_ABOVE_NORMAL;break;
	case 5:reg.dwVisThreadPriority=THREAD_PRIORITY_HIGHEST;break;
	case 6:reg.dwVisThreadPriority=THREAD_PRIORITY_TIME_CRITICAL;break;
	}
	switch(cPropPage4.m_nFreq)
	{
	case 0:reg.dwSampleRate=8000;break;
	case 1:reg.dwSampleRate=11025;break;
	case 2:reg.dwSampleRate=16000;break;
	case 3:reg.dwSampleRate=22050;break;
	case 4:reg.dwSampleRate=32000;break;
	case 5:reg.dwSampleRate=44100;break;
	case 6:reg.dwSampleRate=48000;break;
	case 7:reg.dwSampleRate=64000;break;
	}
	switch(cPropPage4.m_nThreadPriority)
	{
	case 0:reg.dwMixingThreadPriority=THREAD_PRIORITY_IDLE;break;
	case 1:reg.dwMixingThreadPriority=THREAD_PRIORITY_LOWEST;break;
	case 2:reg.dwMixingThreadPriority=THREAD_PRIORITY_BELOW_NORMAL;break;
	case 3:reg.dwMixingThreadPriority=THREAD_PRIORITY_NORMAL;break;
	case 4:reg.dwMixingThreadPriority=THREAD_PRIORITY_ABOVE_NORMAL;break;
	case 5:reg.dwMixingThreadPriority=THREAD_PRIORITY_HIGHEST;break;
	case 6:reg.dwMixingThreadPriority=THREAD_PRIORITY_TIME_CRITICAL;break;
	}
	switch(cPropPage5.m_nPriority)
	{
	case 0:reg.dwPriorityClass=IDLE_PRIORITY_CLASS;break;
	case 1:reg.dwPriorityClass=NORMAL_PRIORITY_CLASS;break;
	case 2:reg.dwPriorityClass=HIGH_PRIORITY_CLASS;break;
	case 3:reg.dwPriorityClass=REALTIME_PRIORITY_CLASS;break;
	}

	if(cPropPage1.m_nButtonStyle!=_cPropPage1.m_nButtonStyle)
	{
		char *BtnCaptions[]={"&Add","&Remove","A&dd All","R&emove All","&Play","Pa&use","&Stop","Pre&vious","&Next"};
		for(int i=0;i<NUMBER_OF_BUTTONS;i++)
		{
			btns[i]->ModifyStyle(reg.dwButtonStyle?0:BS_ICON,reg.dwButtonStyle?BS_ICON:0);				
			btns[i]->SetWindowText(reg.dwButtonStyle?"":BtnCaptions[i]);
		}
		bRedraw=TRUE;
	}
	if(cPropPage1.m_bShowTitleBar!=_cPropPage1.m_bShowTitleBar)
	{
		ModifyStyle(reg.bShowTitleBar?0:(WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX|WS_MAXIMIZEBOX),reg.bShowTitleBar?(WS_CAPTION|WS_SYSMENU|WS_MINIMIZEBOX|WS_MAXIMIZEBOX):0,SWP_DRAWFRAME);
	}
	if(cPropPage1.m_nLayout!=_cPropPage1.m_nLayout)
	{
		if(reg.dwLayoutScheme)
			for(int i=0;i<NUMBER_OF_BUTTONS;i++)
			{
				RECT rt;
				btns[i]->GetWindowRect(&rt);
				LONG l=GetWindowLong(btns[i]->m_hWnd,GWL_USERDATA);
				rt.right=rt.left+LOWORD(l);
				rt.bottom=rt.top+HIWORD(l);
				btns[i]->MoveWindow(&rt,FALSE);
			}
		if(!IsZoomed())
		{
			MINMAXINFO mmi;
			SendMessage(WM_GETMINMAXINFO,0,(LPARAM)&mmi);
			RECT rc;
			GetWindowRect(&rc);
			if(rc.right-rc.left<mmi.ptMinTrackSize.x)
				rc.right=rc.left+mmi.ptMinTrackSize.x;
			if(rc.bottom-rc.top<mmi.ptMinTrackSize.y)
				rc.bottom=rc.top+mmi.ptMinTrackSize.y;
			SetWindowPos(NULL,0,0,rc.right-rc.left,rc.bottom-rc.top,SWP_NOZORDER|SWP_NOMOVE|SWP_NOACTIVATE);
			SendMessage(DM_REPOSITION);
		}
		Layout_ComputeLayout(GetSafeHwnd(),LayoutRules[reg.dwLayoutScheme]);
		LoadControlRects();
		bRedraw=TRUE;
	}
	if(cPropPage1.m_bShowVisualization!=_cPropPage1.m_bShowVisualization)
	{
		if(reg.bShowVisWindow)
		{
			RECT rect;
			GetClientRect(&rect);
			if(!m_VisWindow.Create(WS_CHILD|WS_VISIBLE|WS_CLIPCHILDREN,rect,this,IDC_VIS_WINDOW))
				MessageBox("Failed to create the visualization window.",AfxGetApp()->m_pszAppName,MB_ICONERROR);
			if(bPlaying)m_VisWindow.Start();
		}
		else
		{
			m_VisWindow.DestroyWindow();
		}
		UpdateLayout(reg.bShowVisWindow);
		Layout_ComputeLayout(GetSafeHwnd(),LayoutRules[reg.dwLayoutScheme]);
		RECT rt;
		GetClientRect(&rt);
		iSJWidth=rt.right;
		if(reg.bShowVisWindow&&IsWindow(m_VisWindow.GetSafeHwnd()))
			m_VisWindow.GetWindowRect(&rt);
		else if(!reg.bShowVisWindow&&IsWindow(m_StatusBar.GetSafeHwnd()))
			m_StatusBar.GetWindowRect(&rt);
		ScreenToClient(&rt);
		iSJHeight=rt.top;
		RefreshSkin();
		if(reg.bActiveWallpaper)
			m_ActiveWallpaper.SetParameters(this->GetSafeHwnd(),30,iSJWidth,iSJHeight);
		bRedraw=TRUE;
	}
	if(cPropPage5.m_nPriority!=_cPropPage5.m_nPriority)
	{
		SetPriorityClass(GetCurrentProcess(),reg.dwPriorityClass);
	}
	if(cPropPage4.m_nThreadPriority!=_cPropPage4.m_nThreadPriority)
		SNESAmp_SetMixingThreadPriority(reg.dwMixingThreadPriority);
	if(cPropPage1.m_nVisThreadPriority!=_cPropPage1.m_nVisThreadPriority)
		m_VisWindow.SetThreadPriority(reg.dwVisThreadPriority);
	if(cPropPage4.m_nChan!=_cPropPage4.m_nChan||
		cPropPage4.m_nBits!=_cPropPage4.m_nBits||
		cPropPage4.m_nFreq!=_cPropPage4.m_nFreq||
		cPropPage4.m_nInterpolation!=_cPropPage4.m_nInterpolation||
		cPropPage4.m_iPreamp!=_cPropPage4.m_iPreamp||
		cPropPage4.m_nAPR!=_cPropPage4.m_nAPR||
		cPropPage4.m_bUseLPF!=_cPropPage4.m_bUseLPF||
		cPropPage4.m_bUseOldBRE!=_cPropPage4.m_bUseOldBRE||
		cPropPage4.m_nBufferLength!=_cPropPage4.m_nBufferLength||
		cPropPage1.m_nVisRate!=_cPropPage1.m_nVisRate)
		bReplay=TRUE;
	if(cPropPage1.m_bFullRowSelect!=_cPropPage1.m_bFullRowSelect||cPropPage1.m_bShowGridlines!=_cPropPage1.m_bShowGridlines)
	{
		DWORD dwFlags=0;
		dwFlags|=cPropPage1.m_bFullRowSelect?LVS_EX_FULLROWSELECT:0;
		dwFlags|=cPropPage1.m_bShowGridlines?LVS_EX_GRIDLINES:0;
		m_ctlList1.SetExtendedStyle(dwFlags);
		m_ctlList2.SetExtendedStyle(dwFlags);
		HighlightListEntry(m_ctlList1,iCurrentFileSelection);
		HighlightListEntry(m_ctlList2,iCurrentSong);
	}
	if(cPropPage5.m_bAutoSizeColumns!=_cPropPage5.m_bAutoSizeColumns)
	{
		UpdateList2();
	}
	if(cPropPage1.m_bFile!=_cPropPage1.m_bFile||
	   cPropPage1.m_bTitle!=_cPropPage1.m_bTitle||
	   cPropPage1.m_bGame!=_cPropPage1.m_bGame||
	   cPropPage1.m_bArtist!=_cPropPage1.m_bArtist||
	   cPropPage1.m_bDumper!=_cPropPage1.m_bDumper||
	   cPropPage1.m_bDate!=_cPropPage1.m_bDate||
	   cPropPage1.m_bComment!=_cPropPage1.m_bComment||
	   cPropPage1.m_bLength!=_cPropPage1.m_bLength||
	   cPropPage1.m_bFade!=_cPropPage1.m_bFade||
	   cPropPage1.m_bRepetitions!=_cPropPage1.m_bRepetitions)
	{
		for(int i=1,nCol=0;i<NUMBER_OF_COLUMNS;i++)
		{
			if(reg.stColumnsInfo[i].bActive)
			{
				reg.stColumnsInfo[i].iWidth=m_ctlList2.GetColumnWidth(nCol++);
			}
		}
		reg.stColumnsInfo[1].bActive=cPropPage1.m_bFile;
		reg.stColumnsInfo[2].bActive=cPropPage1.m_bTitle;
		reg.stColumnsInfo[3].bActive=cPropPage1.m_bGame;
		reg.stColumnsInfo[4].bActive=cPropPage1.m_bArtist;
		reg.stColumnsInfo[5].bActive=cPropPage1.m_bDumper;
		reg.stColumnsInfo[6].bActive=cPropPage1.m_bDate;
		reg.stColumnsInfo[7].bActive=cPropPage1.m_bComment;
		reg.stColumnsInfo[8].bActive=cPropPage1.m_bLength;
		reg.stColumnsInfo[9].bActive=cPropPage1.m_bFade;
		reg.stColumnsInfo[10].bActive=cPropPage1.m_bRepetitions;
		UpdateListColumns();
		UpdateList2();
	}

	if(bRedraw)
		RedrawWindow(NULL,NULL,RDW_INVALIDATE|RDW_UPDATENOW|RDW_ERASE|RDW_ALLCHILDREN);
	if(bReplay==TRUE&&bPlaying==TRUE)
	{
		iCurrentSong=iPlayingSong;
		OnButtonPlay();
	}

	reg.Save();

	UpdateTitleBar();
	UpdateButtonStates();
}

void CSuperJukeboxDlg::OnHelpContents() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	WinHelp(0L,HELP_CONTENTS);
}

void CSuperJukeboxDlg::OnHelpAboutSuperJukebox() 
{
	// TODO: Add your command handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	CAboutDlg cdlgAbout;
	cdlgAbout.DoModal();
}

void CSuperJukeboxDlg::UpdateTitleBar()
{
	char szBuffer[MAX_PATH];

	_splitpath(cstrOpenedPlaylist,NULL,NULL,szBuffer,NULL);	
	if(bPlaying||bPaused)
	{
		if(strlen(seList2[iPlayingSong].ID666.Song))
			cstrTitle=seList2[iPlayingSong].ID666.Song;
		else
			cstrTitle=seList2[iPlayingSong].szName;
		cstrTitle+=" - ";
	}
	else cstrTitle="";
	cstrTitle+=szBuffer;
	if(bNeedsSaving&&seList2.size())
		cstrTitle+="*";
	cstrTitle+=" - Super Jukebox";

	SetWindowText(cstrTitle);
}

void CSuperJukeboxDlg::UpdateButtonStates()
{
	CWnd *wndFocus=GetFocus();

	UINT iSelFilesCount=m_ctlList1.GetSelectedCount();
	UINT iSelSongsCount=m_ctlList2.GetSelectedCount();

	m_ctlButton1.EnableWindow(iSelFilesCount);
	m_ctlButton2.EnableWindow(iSelSongsCount);
	m_ctlButton3.EnableWindow(m_ctlList1.GetItemCount());
	m_ctlButton4.EnableWindow(m_ctlList2.GetItemCount());
	m_ctlButton5.EnableWindow(iSelSongsCount||bPlaying);
	m_ctlButton6.EnableWindow(iSelSongsCount&&bPlaying);
	m_ctlButton7.EnableWindow(iSelSongsCount&&(bPlaying||bPaused));
	m_ctlButton8.EnableWindow(iSelSongsCount);
	m_ctlButton9.EnableWindow(iSelSongsCount);

	if(wndFocus)
	{
		switch(wndFocus->GetDlgCtrlID())
		{
		case IDC_BUTTON_PAUSE:
			if(!(iCurrentSong>=0&&bPlaying))
				GotoDlgCtrl(&m_ctlButton5);
			break;
		case IDC_BUTTON_STOP:
			if(!(iCurrentSong>=0&&(bPlaying||bPaused)))
				GotoDlgCtrl(&m_ctlButton5);
			break;
		}
	}
}

void CSuperJukeboxDlg::OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// TODO: Add your message handler code here and/or call default
	SIZE sz;
	sz.cx=lpDrawItemStruct->rcItem.right-lpDrawItemStruct->rcItem.left;
	sz.cy=lpDrawItemStruct->rcItem.bottom-lpDrawItemStruct->rcItem.top;

	switch(nIDCtl)
	{
	case IDC_STATUS_BAR:
		switch(lpDrawItemStruct->itemID)
		{
		case 2:
			int iSong=bPlaying?iPlayingSong:iCurrentSong;
			int iLength=0;

			if(PlaylistPropsDlg.m_nMode==1&&iSong>=0)
			{
				iLength=iSongLength*iSongRepetitions;
				if(PlaylistPropsDlg.m_bFadeOut&&iLength>0)
					iLength+=iFadeLength;
			}
			else if(PlaylistPropsDlg.m_nMode==2&&iSong>=0)
			{
				iLength=seList2[iSong].iLength*seList2[iSong].iRepetitions;
				if(PlaylistPropsDlg.m_bFadeOut&&iLength>0)
					iLength+=seList2[iSong].iFadeLength;
			}
			if(iLength>0)
			{
				if(bPlaying)
				{
					int i=(double)SNESAmp_GetPlayTime()/(iLength*1000)*sz.cx;
					RECT rc;
					SetRect(&rc,lpDrawItemStruct->rcItem.left,lpDrawItemStruct->rcItem.top,lpDrawItemStruct->rcItem.left+i,lpDrawItemStruct->rcItem.bottom);
					HBRUSH br=CreateSolidBrush(GetSysColor(COLOR_HIGHLIGHT));
					FillRect(lpDrawItemStruct->hDC,&rc,br);
					DeleteObject(br);
				}
				if(m_StatusBar.m_nLen>=0)
				{
					SetROP2(lpDrawItemStruct->hDC,R2_NOT);
					SetBkMode(lpDrawItemStruct->hDC,TRANSPARENT);
					HPEN old_pen=(HPEN)SelectObject(lpDrawItemStruct->hDC,GetStockObject(BLACK_PEN));					
					char szBuf[20];
					ConvertTimeUp((double)m_StatusBar.m_nLen/97*iLength,szBuf);
					DrawText(lpDrawItemStruct->hDC,szBuf,strlen(szBuf),&lpDrawItemStruct->rcItem,DT_CENTER|DT_VCENTER);
					MoveToEx(lpDrawItemStruct->hDC,lpDrawItemStruct->rcItem.left+m_StatusBar.m_nLen-1,lpDrawItemStruct->rcItem.top,NULL);
					LineTo(lpDrawItemStruct->hDC,lpDrawItemStruct->rcItem.left+m_StatusBar.m_nLen-1,lpDrawItemStruct->rcItem.bottom);
					SelectObject(lpDrawItemStruct->hDC,old_pen);
				}
			}			
			break;
		}
		break;

	default:
		CDialog::OnDrawItem(nIDCtl, lpDrawItemStruct);
		break;
	}	
}

void CSuperJukeboxDlg::OnMenuSelect(UINT nItemID, UINT nFlags, HMENU hSysMenu) 
{
	CDialog::OnMenuSelect(nItemID, nFlags, hSysMenu);
	
	// TODO: Add your message handler code here
	static BOOL bPrinted;

	if(!(nFlags&MF_SYSMENU)&&!(nFlags&MF_POPUP))
	{
		CString str;
		str.LoadString(nItemID);
		if(!str.IsEmpty())
		{
			m_StatusBar.SetText(str,3,0);
			bPrinted=TRUE;
		}
	}
	else if(bPrinted)
	{
		m_StatusBar.SetText("",3,0);
		bPrinted=FALSE;
	}
}

void CSuperJukeboxDlg::OnInitMenu(CMenu* pMenu) 
{
	CDialog::OnInitMenu(pMenu);
	
	// TODO: Add your message handler code here
	CMenu *TempMenu=pMenu->GetSubMenu(0);
	if(TempMenu)
	{
		TempMenu->EnableMenuItem(ID_FILE_SAVE,(bNeedsSaving&&seList2.size())?MF_ENABLED:MF_GRAYED);
		TempMenu->EnableMenuItem(ID_FILE_SAVEAS,seList2.size()?MF_ENABLED:MF_GRAYED);
	}

	TempMenu=pMenu->GetSubMenu(1);
	if(TempMenu)
	{
		UINT iSelectedCount=m_ctlList2.GetSelectedCount();
		TempMenu->EnableMenuItem(ID_EDIT_CUT,iSelectedCount?MF_ENABLED:MF_GRAYED);
		TempMenu->EnableMenuItem(ID_EDIT_COPY,iSelectedCount?MF_ENABLED:MF_GRAYED);
		TempMenu->EnableMenuItem(ID_EDIT_PASTE,seClipboard.size()?MF_ENABLED:MF_GRAYED);
		TempMenu->EnableMenuItem(ID_EDIT_DELETE,iSelectedCount?MF_ENABLED:MF_GRAYED);

		iSelectedCount=m_ctlList2.GetItemCount();
		TempMenu->EnableMenuItem(ID_EDIT_SELECTALL,iSelectedCount?MF_ENABLED:MF_GRAYED);
		TempMenu->EnableMenuItem(ID_EDIT_FIND,iSelectedCount?MF_ENABLED:MF_GRAYED);
		TempMenu->EnableMenuItem(ID_EDIT_GOTO,iSelectedCount?MF_ENABLED:MF_GRAYED);
	}

	TempMenu=pMenu->GetSubMenu(2);
	if(TempMenu)
	{
		UINT iSelectedCount=m_ctlList2.GetSelectedCount();
		TempMenu->EnableMenuItem(ID_VIEW_PROPERTIES,iSelectedCount?MF_ENABLED:MF_GRAYED);
	}
}

void CSuperJukeboxDlg::OnClickStatusBar(NMHDR* pNMHDR, LRESULT* pResult) 
{
	// TODO: Add your control notification handler code here
	if(!bInternalCall)
		bLoadPlayList=FALSE;

	int iSong=bPlaying?iPlayingSong:iCurrentSong;
	int iLength=0;

	if(PlaylistPropsDlg.m_nMode==1&&iSong>=0)
	{
		iLength=iSongLength*iSongRepetitions;
		if(PlaylistPropsDlg.m_bFadeOut&&iLength>0)
			iLength+=iFadeLength;
	}
	else if(PlaylistPropsDlg.m_nMode==2&&iSong>=0)
	{
		iLength=seList2[iSong].iLength*seList2[iSong].iRepetitions;
		if(PlaylistPropsDlg.m_bFadeOut&&iLength>0)
			iLength+=seList2[iSong].iFadeLength;
	}

	if(iLength>0)
	{
		if(!bPlaying)
			OnButtonPlay();
		SNESAmp_SetPlayTime((double)m_StatusBar.m_nLen/97*iLength*1000);
	}

	*pResult = 0;
}
