#if !defined(AFX_PROPPAGE1_H__1225EEC0_250F_11D4_8925_009027C572AB__INCLUDED_)
#define AFX_PROPPAGE1_H__1225EEC0_250F_11D4_8925_009027C572AB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropPage1.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropPage1 dialog

class CPropPage1 : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropPage1)

// Construction
public:
	CPropPage1();
	~CPropPage1();
	CPropPage1 & operator =(const CPropPage1 &dlg);

// Dialog Data
	//{{AFX_DATA(CPropPage1)
	enum { IDD = IDD_DIALOG2 };
	BOOL	m_bFullRowSelect;
	BOOL	m_bShowGridlines;
	BOOL	m_bFile;
	BOOL	m_bTitle;
	BOOL	m_bGame;
	BOOL	m_bArtist;
	BOOL	m_bDumper;
	BOOL	m_bDate;
	BOOL	m_bComment;
	BOOL	m_bLength;
	BOOL	m_bRepetitions;
	BOOL	m_bFade;
	int		m_nLayout;
	BOOL	m_bShowVisualization;
	int		m_nVisMode;
	UINT	m_nVisRate;
	int		m_nVisThreadPriority;
	BOOL	m_bShowTitleBar;
	int		m_nButtonStyle;
	UINT	m_nSpectrumSize;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropPage1)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropPage1)
	virtual BOOL OnInitDialog();
	afx_msg void OnCheckShowVisualization();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPPAGE1_H__1225EEC0_250F_11D4_8925_009027C572AB__INCLUDED_)
