// MyStatusBarCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "super jukebox.h"
#include "MyStatusBarCtrl.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyStatusBarCtrl

CMyStatusBarCtrl::CMyStatusBarCtrl()
{
	m_nLen=-1;
	bCaptured=FALSE;
}

CMyStatusBarCtrl::~CMyStatusBarCtrl()
{
}


BEGIN_MESSAGE_MAP(CMyStatusBarCtrl, CStatusBarCtrl)
	//{{AFX_MSG_MAP(CMyStatusBarCtrl)
	ON_WM_MOUSEMOVE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyStatusBarCtrl message handlers

void CMyStatusBarCtrl::OnMouseMove(UINT nFlags, CPoint point) 
{
	// TODO: Add your message handler code here and/or call default
	CRect rc;
	GetRect(2,rc);
	if(rc.PtInRect(point))
	{
		m_nLen=point.x-rc.left;
		ASSERT(m_nLen>=0);
		SetText("",2,SBT_OWNERDRAW);
		if(!bCaptured)
		{
			SetCapture();
			bCaptured=TRUE;
		}
	}
	else if(m_nLen>=0)
	{
		m_nLen=-1;
		SetText("",2,SBT_OWNERDRAW);
		if(bCaptured)
		{
			ReleaseCapture();
			bCaptured=FALSE;
		}
	}
	
	CStatusBarCtrl::OnMouseMove(nFlags, point);
}
