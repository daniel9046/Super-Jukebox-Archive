#ifndef _GLOBALS_H_
#define _GLOBALS_H_

#define NUMBER_OF_COLUMNS 11
#define NUMBER_OF_BUTTONS 9
#define LIST_ID_DRV 0
#define LIST_ID_DIR 1
#define LIST_ID_SPC 2
#define LIST_ID_RAR 3
#define LIST_ID_ZIP 4
#define LIST_ID_ACE 5
#define PLAYLIST_VERSION 10
#define VIS_HEIGHT 130

#include <vector>
#include "Layout.h"
#include "..\SNESAmp\SNESAmp.h"

struct ColumnInfo
{
	char szName[20];
	int iWidth;
	BOOL bActive;
};

#include "Registry.h"

struct SongEntry
{
	char szName[MAX_PATH],szRealName[MAX_PATH];
	char szDirectory[MAX_PATH];
	int iLength,iFadeLength,iRepetitions,iType,iSubType;
	BOOL bArchived,bSelected;
	int iIcon;
	ID666_TAG ID666;
};

extern int iCurrentSong;
extern int iPlayingSong;
extern int iSongLength;
extern int iFadeLength;
extern int iSongRepetitions;
extern int iSortMethod;
extern bool bSortAscending;
extern bool bPaused;
extern bool bPlaying;
extern bool bNeedsSaving;
extern bool bArchived;
extern bool bLoadPlayList;
extern bool bDeleteSong;
extern char szPlayList[MAX_PATH];
extern char szCurrentSong[MAX_PATH];
extern char szPlaylistLocation[MAX_PATH];
extern char szProgramLocation[MAX_PATH];
extern BOOL fShowExtensions;
extern std::vector<SongEntry>seList1;
extern std::vector<SongEntry>seList2;
extern std::vector<SongEntry>seClipboard;
extern CString cstrOpenedPlaylist;
extern CString cstrTitle;
extern CRegistry reg;
extern ColumnInfo stColumnsInfo[NUMBER_OF_COLUMNS];
extern RULE LayoutRules[5][50];

#ifdef UNIMPORTED_UNRAR_DLL
typedef HANDLE (PASCAL *pfnRAROpenArchive)(struct RAROpenArchiveData *ArchiveData);
typedef int (PASCAL *pfnRARCloseArchive)(HANDLE hArcData);
typedef int (PASCAL *pfnRARReadHeader)(HANDLE hArcData,struct RARHeaderData *HeaderData);
typedef int (PASCAL *pfnRARProcessFile)(HANDLE hArcData,int Operation,const char *DestPath,const char *DestName);
typedef void (PASCAL *pfnRARSetChangeVolProc)(HANDLE hArcData,int (*ChangeVolProc)(char *ArcName,int Mode));
typedef void (PASCAL *pfnRARSetProcessDataProc)(HANDLE hArcData,int (*ProcessDataProc)(unsigned char *Addr,int Size));
typedef void (PASCAL *pfnRARSetPassword)(HANDLE hArcData,char *Password);
extern pfnRAROpenArchive _RAROpenArchive;
extern pfnRARCloseArchive _RARCloseArchive;
extern pfnRARReadHeader _RARReadHeader;
extern pfnRARProcessFile _RARProcessFile;
extern pfnRARSetChangeVolProc _RARSetChangeVolProc;
extern pfnRARSetProcessDataProc _RARSetProcessDataProc;
extern pfnRARSetPassword _RARSetPassword;
#endif
#ifdef UNIMPORTED_UNACE_DLL
typedef HANDLE (__stdcall *pfnACEOpenArchive)(struct ACEOpenArchiveData *ArchiveData);
typedef int (__stdcall *pfnACECloseArchive)(HANDLE hArcData);
typedef int (__stdcall *pfnACEReadHeader)(HANDLE hArcData,struct ACEHeaderData *HeaderData);
typedef int (__stdcall *pfnACEProcessFile)(HANDLE hArcData,int Operation,const char *DestPath);
typedef int (__stdcall *pfnACESetPassword)(HANDLE hArcData,char *Password);
extern pfnACEOpenArchive _ACEOpenArchive;
extern pfnACECloseArchive _ACECloseArchive;
extern pfnACEReadHeader _ACEReadHeader;
extern pfnACEProcessFile _ACEProcessFile;
extern pfnACESetPassword _ACESetPassword;
#endif
typedef DWORD (CALLBACK* GETLONGPATHNAMEPROC)(LPCTSTR,LPTSTR,DWORD);
DWORD _GetLongPathName(LPCTSTR lpszShortPath,LPTSTR lpszLongPath,DWORD cchBuffer);
bool operator<(const SongEntry & se1, const SongEntry & se2);
void ConvertTimeUp(int iSeconds, LPSTR lpszBuffer);
int ConvertTimeDown(LPCTSTR lpszBuffer);
BOOL IsInRange(int i0,int i1,int iRange);
BOOL IsFileTypeRegistered(LPCTSTR lpszExtension);
BOOL IsOverlapped(RECT rtSrc,int iCount,int iSkip,RECT rtDest[20]);
void AdjustRect(RECT *rtSrc,RECT rtDest,BOOL bMove,BOOL bSize);
void TrimString(LPTSTR lpszString);

#endif