// Super JukeboxDlg.h : header file
//

#if !defined(AFX_SUPERJUKEBOXDLG_H__41579E4A_5D7E_11D3_9105_444553540001__INCLUDED_)
#define AFX_SUPERJUKEBOXDLG_H__41579E4A_5D7E_11D3_9105_444553540001__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Globals.h"
#include "FindDlg.h"
#include "GoToDlg.h"
#include "PropPage1.h"
#include "PropPage4.h"
#include "PropPage5.h"
#include "VisWindow.h"
#include "SongPropsDlg.h"
#include "PlaylistPropsDlg.h"
#include "ActiveWallpaper.h"	// Added by ClassView
#include "MyStatusBarCtrl.h"

/////////////////////////////////////////////////////////////////////////////
// CSuperJukeboxDlg dialog

class CSuperJukeboxDlg : public CDialog
{
// Construction
public:
	BOOL bDebug;
	BOOL bJustStarted;
	int iOldElapsedSeconds;
	void UpdateButtonStates();
	void UpdateLayout(BOOL bShowVis);
	void LoadControlRects();
	CButton *btns[NUMBER_OF_BUTTONS];
	BOOL bInternalCall;
	HBRUSH hBrushes[5];
	HPEN hPens[5];
	BOOL bVisWindowActive;
	void UpdateListColumns();
	CImageList * pImageHdrSmall;
	CImageList * pSmallSysImage;
	void PositionControls(DWORD dwFlags);
	static int CALLBACK CompFunc(LPARAM lParam1, LPARAM lParam2, LPARAM lParamSort);
	static int GetColumnText(int iColumn, LPTSTR lpszText, int nMaxChar);
	DWORD dwMouseButtons;
	HCURSOR hCursor0,hCursor1;
	int iMousePos;
	BOOL LoadSkin(LPCTSTR lpszSkinFile);
	CString cstrOldSkinFile;
	char szListingSource[MAX_PATH];
	int iListingType;
	CFindDlg FindDlg;
	CGoToDlg GoToDlg;
	CSongPropsDlg SongPropsDlg;
	CPlaylistPropsDlg PlaylistPropsDlg;
	void UpdateTitleBar();
	int iPageJump;
	int iCurrentFileSelection;
	int MapColumnText(LPCTSTR lpszColumn);
	void SetColumnText(int nItem,LPCTSTR lpszColumn,LPCTSTR lpszText,int nImage);
	CPropPage1 cPropPage1;
	CPropPage4 cPropPage4;
	CPropPage5 cPropPage5;
	void RefreshSkin();
	int iSJWidth,iSJHeight,iSkinWidth,iSkinHeight;
	HDC hDCSkin,hDCAdjustedSkin;
	HBITMAP hBmpSkin,hBmpAdjustedSkin;
	CMenu cMenu1;
	void InsertList1Items(int iInsertPos,int iStart,int iEnd);
	void InsertList2Items(int iInsertPos,int iStart,int iEnd);
	void UpdateList1();
	void UpdateList2();
	void HighlightListEntry(CListCtrl &ctlList,int iEntry);
	int GetSettingValue(const char*szSetting);
	void LoadDriveList();
	int LoadFileListFromACE(CString cstrArchiveName);
	int SavePlayList(const char *szPlayList);
	int LoadPlayList(const char *szPlayList);
	int LoadFileListFromRAR(CString cstrArchiveName);
	int LoadFileListFromZIP(CString cstrArchiveName);
	int LoadFileList();
	CSuperJukeboxDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	//{{AFX_DATA(CSuperJukeboxDlg)
	enum { IDD = IDD_SUPERJUKEBOX_DIALOG };
	CButton	m_ctlButton1;
	CButton	m_ctlButton2;
	CButton	m_ctlButton3;
	CButton	m_ctlButton4;
	CButton	m_ctlButton5;
	CButton	m_ctlButton6;
	CButton	m_ctlButton7;
	CButton	m_ctlButton8;
	CButton	m_ctlButton9;
	CListCtrl	m_ctlList1;
	CListCtrl	m_ctlList2;
	//}}AFX_DATA

	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSuperJukeboxDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	CVisWindow m_VisWindow;
	CMyStatusBarCtrl m_StatusBar;
	void OnCancel();
	void OnOK();
	HICON m_hIcon;

	// Generated message map functions
	//{{AFX_MSG(CSuperJukeboxDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnDestroy();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	afx_msg void OnButtonAdd();
	afx_msg void OnButtonRemove();
	afx_msg void OnButtonAddAll();
	afx_msg void OnButtonRemoveAll();
	afx_msg void OnButtonPlay();
	afx_msg void OnButtonPause();
	afx_msg void OnButtonStop();
	afx_msg void OnButtonPrevious();
	afx_msg void OnButtonNext();
	afx_msg void OnItemchangedList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnItemchangedList2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclkList2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclkList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSetfocusList1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnSetfocusList2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnKeydownList2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnTimer(UINT nIDEvent);
	afx_msg void OnRclickList2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnEraseBkgnd(CDC* pDC);
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg void OnColumnclickList2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnQueryEndSession();
	afx_msg void OnEndSession(BOOL bEnding);
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	afx_msg void OnLButtonDown(UINT nFlags, CPoint point);
	afx_msg void OnLButtonUp(UINT nFlags, CPoint point);
	afx_msg void OnFileNew();
	afx_msg void OnFileOpen();
	afx_msg void OnFileSave();
	afx_msg void OnFileSaveAs();
	afx_msg void OnFileProperties();
	afx_msg void OnFileExit();
	afx_msg void OnEditCut();
	afx_msg void OnEditCopy();
	afx_msg void OnEditPaste();
	afx_msg void OnEditDelete();
	afx_msg void OnEditSelectAll();
	afx_msg void OnEditFind();
	afx_msg void OnEditGoTo();
	afx_msg void OnViewRefresh();
	afx_msg void OnViewProperties();
	afx_msg void OnSettingsConfigure();
	afx_msg void OnHelpContents();
	afx_msg void OnHelpAboutSuperJukebox();
	afx_msg void OnGetMinMaxInfo(MINMAXINFO FAR* lpMMI);
	afx_msg void OnDrawItem(int nIDCtl, LPDRAWITEMSTRUCT lpDrawItemStruct);
	afx_msg void OnMenuSelect(UINT nItemID, UINT nFlags, HMENU hSysMenu);
	afx_msg void OnInitMenu(CMenu* pMenu);
	afx_msg void OnViewHideWindows();
	afx_msg void OnClickStatusBar(NMHDR* pNMHDR, LRESULT* pResult);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	CActiveWallpaper m_ActiveWallpaper;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SUPERJUKEBOXDLG_H__41579E4A_5D7E_11D3_9105_444553540001__INCLUDED_)
