// MyButton.cpp : implementation file
//

#include "stdafx.h"
#include "super jukebox.h"
#include "MyButton.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMyButton

CMyButton::CMyButton()
{
	iXPos=iYPos=iWidth=iHeight=-1;
	pParentDC=NULL;
}

CMyButton::~CMyButton()
{
}


BEGIN_MESSAGE_MAP(CMyButton, CButton)
	//{{AFX_MSG_MAP(CMyButton)
	ON_WM_ENABLE()
	ON_WM_ERASEBKGND()
	ON_WM_MOVE()
	ON_WM_SIZE()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyButton message handlers

void CMyButton::OnEnable(BOOL bEnable) 
{
	CButton::OnEnable(bEnable);
	
	// TODO: Add your message handler code here
	
}

BOOL CMyButton::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	if(iXPos==-1||iWidth==-1||pParentDC==NULL)
		return CButton::OnEraseBkgnd(pDC);

	CDC SpareDC;
	ASSERT(SpareDC.CreateCompatibleDC(pDC));
	CBitmap SpareBitmap;
	ASSERT(SpareBitmap.CreateCompatibleBitmap(pDC,iWidth,iHeight));
	ASSERT(SpareDC.SelectObject(&SpareBitmap));
	CBrush brush;
	ASSERT(brush.CreateSolidBrush(RGB(0,0,0)));
	CRect rect;
	rect.SetRect(0,0,iWidth,iHeight);
	SpareDC.FillRect(&rect,&brush);
	BLENDFUNCTION bf;
	bf.BlendOp=AC_SRC_OVER;
	bf.BlendFlags=0;
	bf.SourceConstantAlpha=96;
	bf.AlphaFormat=0;
	//ASSERT(::AlphaBlend(SpareDC.GetSafeHdc(),0,0,iWidth,iHeight,pParentDC,iXPos,iYPos,iWidth,iHeight,bf));
	pDC->BitBlt(0,0,iWidth,iHeight,&SpareDC,0,0,SRCCOPY);
	SpareDC.DeleteDC();
	SpareBitmap.DeleteObject();
	brush.DeleteObject();
	return TRUE;	
}

void CMyButton::OnMove(int x, int y) 
{
	CButton::OnMove(x, y);
	
	// TODO: Add your message handler code here
	iXPos=x;
	iYPos=y;	
}

void CMyButton::OnSize(UINT nType, int cx, int cy) 
{
	CButton::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	iWidth=cx;
	iHeight=cy;
}

BOOL Line(HDC hdc,HPEN hpen,int nXStart,int nYStart,int nXEnd,int nYEnd)
{
	HPEN hOldPen=(HPEN)SelectObject(hdc,hpen);
	if(!MoveToEx(hdc,nXStart,nYStart,NULL))return FALSE;
	if(!LineTo(hdc,nXEnd,nYEnd))return FALSE;
	SelectObject(hdc,hOldPen);
	return TRUE;
}

void CMyButton::DrawItem(LPDRAWITEMSTRUCT lpDrawItemStruct) 
{
	// TODO: Add your code to draw the specified item
	switch(lpDrawItemStruct->itemAction)
	{
	case ODA_DRAWENTIRE:
		HBRUSH brush[10];
		HPEN pen[10];
		HDC hdc=lpDrawItemStruct->hDC;
		RECT *rt=&lpDrawItemStruct->rcItem;
		rt->right--;rt->bottom--;

		brush[1]=CreateSolidBrush(RGB(255,255,255));
		brush[2]=CreateSolidBrush(RGB(0,0,0));
		pen[1]=CreatePen(PS_SOLID,0,GetSysColor(COLOR_3DHIGHLIGHT));
		pen[2]=CreatePen(PS_SOLID,0,GetSysColor(COLOR_3DLIGHT));
		pen[3]=CreatePen(PS_SOLID,0,GetSysColor(COLOR_3DSHADOW));
		pen[4]=CreatePen(PS_SOLID,0,GetSysColor(COLOR_3DDKSHADOW));

		Line(hdc,pen[1],0,0,rt->right,0);
		Line(hdc,pen[1],0,0,0,rt->bottom);
		Line(hdc,pen[2],1,1,rt->right-1,1);
		Line(hdc,pen[2],1,1,1,rt->bottom-1);
		Line(hdc,pen[3],1,rt->bottom-1,rt->right-1,rt->bottom-1);
		Line(hdc,pen[3],rt->right-1,1,rt->right-1,rt->bottom-1);
		Line(hdc,pen[4],0,rt->bottom,rt->right,rt->bottom);
		Line(hdc,pen[4],rt->right,0,rt->right,rt->bottom);

		DeleteObject(brush[1]);
		DeleteObject(brush[2]);
		DeleteObject(pen[1]);
		DeleteObject(pen[2]);
		break;
	}	
}
