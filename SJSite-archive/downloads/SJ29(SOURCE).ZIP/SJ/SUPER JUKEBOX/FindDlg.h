#if !defined(AFX_FINDDLG_H__C093CA21_37E0_11D4_B079_AFBCBE01B53A__INCLUDED_)
#define AFX_FINDDLG_H__C093CA21_37E0_11D4_B079_AFBCBE01B53A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// FindDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CFindDlg dialog

class CFindDlg : public CDialog
{
// Construction
public:
	CFindDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CFindDlg)
	enum { IDD = IDD_DIALOG5 };
	CEdit	m_edFind;
	int		m_iDirection;
	int		m_iSearchColumn;
	BOOL	m_bWholeWord;
	BOOL	m_bCase;
	CString	m_strFind;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CFindDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CFindDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnChangeEdit5_1();
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_FINDDLG_H__C093CA21_37E0_11D4_B079_AFBCBE01B53A__INCLUDED_)
