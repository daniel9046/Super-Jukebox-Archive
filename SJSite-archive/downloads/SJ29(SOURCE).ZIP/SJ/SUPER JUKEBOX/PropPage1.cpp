// PropPage1.cpp : implementation file
//

#include "stdafx.h"
#include "Super Jukebox.h"
#include "PropPage1.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropPage1 property page

IMPLEMENT_DYNCREATE(CPropPage1, CPropertyPage)

CPropPage1::CPropPage1() : CPropertyPage(CPropPage1::IDD)
{
	//{{AFX_DATA_INIT(CPropPage1)
	m_bFullRowSelect = FALSE;
	m_bShowGridlines = FALSE;
	m_bFile = FALSE;
	m_bTitle = FALSE;
	m_bGame = FALSE;
	m_bArtist = FALSE;
	m_bDumper = FALSE;
	m_bDate = FALSE;
	m_bComment = FALSE;
	m_bLength = FALSE;
	m_bRepetitions = FALSE;
	m_bFade = FALSE;
	m_nLayout = -1;
	m_bShowVisualization = FALSE;
	m_nVisMode = -1;
	m_nVisRate = 0;
	m_nVisThreadPriority = -1;
	m_bShowTitleBar = FALSE;
	m_nButtonStyle = -1;
	m_nSpectrumSize = 0;
	//}}AFX_DATA_INIT
}

CPropPage1::~CPropPage1()
{
}

void CPropPage1::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPage1)
	DDX_Check(pDX, IDC_CHECK_FULL_ROW_SELECT, m_bFullRowSelect);
	DDX_Check(pDX, IDC_CHECK_SHOW_GRIDLINES, m_bShowGridlines);
	DDX_Check(pDX, IDC_CHECK_FILE, m_bFile);
	DDX_Check(pDX, IDC_CHECK_TITLE, m_bTitle);
	DDX_Check(pDX, IDC_CHECK_GAME, m_bGame);
	DDX_Check(pDX, IDC_CHECK_ARTIST, m_bArtist);
	DDX_Check(pDX, IDC_CHECK_DUMPER, m_bDumper);
	DDX_Check(pDX, IDC_CHECK_DATE, m_bDate);
	DDX_Check(pDX, IDC_CHECK_COMMENT, m_bComment);
	DDX_Check(pDX, IDC_CHECK_LENGTH, m_bLength);
	DDX_Check(pDX, IDC_CHECK_REPETITIONS, m_bRepetitions);
	DDX_Check(pDX, IDC_CHECK_FADE, m_bFade);
	DDX_CBIndex(pDX, IDC_COMBO_LAYOUT, m_nLayout);
	DDX_Check(pDX, IDC_CHECK_SHOW_VISUALIZATION, m_bShowVisualization);
	DDX_CBIndex(pDX, IDC_COMBO_VIS_MODE, m_nVisMode);
	DDX_Text(pDX, IDC_EDIT_VIS_RATE, m_nVisRate);
	DDV_MinMaxUInt(pDX, m_nVisRate, 10, 120);
	DDX_CBIndex(pDX, IDC_COMBO_VIS_PRIORITY, m_nVisThreadPriority);
	DDX_Check(pDX, IDC_CHECK_SHOW_TITLE_BAR, m_bShowTitleBar);
	DDX_CBIndex(pDX, IDC_COMBO_BUTTON_STYLE, m_nButtonStyle);
	DDX_Text(pDX, IDC_EDIT_SPECTRUM_SIZE, m_nSpectrumSize);
	DDV_MinMaxUInt(pDX, m_nSpectrumSize, 1, 100);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPage1, CPropertyPage)
	//{{AFX_MSG_MAP(CPropPage1)
	ON_BN_CLICKED(IDC_CHECK_SHOW_VISUALIZATION, OnCheckShowVisualization)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropPage1 message handlers

CPropPage1 & CPropPage1::operator =(const CPropPage1 &obj)
{
	if(this==&obj)
		return *this;
	m_nSpectrumSize=obj.m_nSpectrumSize;
	m_nButtonStyle=obj.m_nButtonStyle;
	m_bShowTitleBar=obj.m_bShowTitleBar;
	m_nVisThreadPriority=obj.m_nVisThreadPriority;
	m_nVisRate=obj.m_nVisRate;
	m_nVisMode=obj.m_nVisMode;
	m_bShowVisualization=obj.m_bShowVisualization;
	m_nLayout=obj.m_nLayout;
	m_bFile=obj.m_bFile;
	m_bTitle=obj.m_bTitle;
	m_bGame=obj.m_bGame;
	m_bArtist=obj.m_bArtist;
	m_bDumper=obj.m_bDumper;
	m_bDate=obj.m_bDate;
	m_bComment=obj.m_bComment;
	m_bLength=obj.m_bLength;
	m_bFade=obj.m_bFade;
	m_bRepetitions=obj.m_bRepetitions;
	m_bShowGridlines=obj.m_bShowGridlines;
	m_bFullRowSelect=obj.m_bFullRowSelect;
	return *this;
}
BOOL CPropPage1::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_SPECTRUM_SIZE))->SetRange(1,100);
	((CSpinButtonCtrl*)GetDlgItem(IDC_SPIN_VIS_RATE))->SetRange(10,120);
	BOOL bOn=((CButton*)GetDlgItem(IDC_CHECK_SHOW_VISUALIZATION))->GetCheck();
	GetDlgItem(IDC_COMBO_VIS_MODE)->EnableWindow(bOn);
	GetDlgItem(IDC_EDIT_SPECTRUM_SIZE)->EnableWindow(bOn);
	GetDlgItem(IDC_SPIN_SPECTRUM_SIZE)->EnableWindow(bOn);
	GetDlgItem(IDC_EDIT_VIS_RATE)->EnableWindow(bOn);
	GetDlgItem(IDC_SPIN_VIS_RATE)->EnableWindow(bOn);
	GetDlgItem(IDC_COMBO_VIS_PRIORITY)->EnableWindow(bOn);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPropPage1::OnCheckShowVisualization() 
{
	// TODO: Add your control notification handler code here
	BOOL bOn=((CButton*)GetDlgItem(IDC_CHECK_SHOW_VISUALIZATION))->GetCheck();
	GetDlgItem(IDC_COMBO_VIS_MODE)->EnableWindow(bOn);
	GetDlgItem(IDC_EDIT_SPECTRUM_SIZE)->EnableWindow(bOn);
	GetDlgItem(IDC_SPIN_SPECTRUM_SIZE)->EnableWindow(bOn);
	GetDlgItem(IDC_EDIT_VIS_RATE)->EnableWindow(bOn);
	GetDlgItem(IDC_SPIN_VIS_RATE)->EnableWindow(bOn);
	GetDlgItem(IDC_COMBO_VIS_PRIORITY)->EnableWindow(bOn);
}
