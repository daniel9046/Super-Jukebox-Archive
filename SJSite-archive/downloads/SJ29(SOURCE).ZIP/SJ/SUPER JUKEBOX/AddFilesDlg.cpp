// AddFilesDlg.cpp : implementation file
//

#include "stdafx.h"
#include "resource.h"
#include "super jukebox.h"
#include "AddFilesDlg.h"
#include "Extractors.h"
#include "..\SNESAmp\SNESAmp.h"
#include "Globals.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CAddFilesDlg dialog

BOOL CAddFilesDlg::m_bUseID666;
int CAddFilesDlg::KillThread,CAddFilesDlg::iFileCount,CAddFilesDlg::iCurrentFile;

CAddFilesDlg::CAddFilesDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CAddFilesDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CAddFilesDlg)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CAddFilesDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAddFilesDlg)
	DDX_Control(pDX, IDC_STATIC_ADDING_FILE, m_Static1_1);
	DDX_Control(pDX, IDC_PROGRESS_ADDING_FILE, m_Progress1_1);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CAddFilesDlg, CDialog)
	//{{AFX_MSG_MAP(CAddFilesDlg)
	ON_WM_TIMER()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CAddFilesDlg message handlers

UINT CAddFilesDlg::Thread(LPVOID lpParameter)
{
	for(int nItem=0;nItem<seList1.size()&&!KillThread;nItem++)
		if(seList1[nItem].iType==LIST_ID_SPC&&seList1[nItem].bSelected&&!KillThread)
		{
			char szBuf0[MAX_PATH];
			seList2.push_back(seList1[nItem]);
			iCurrentFile=seList2.size()-1;
			if(m_bUseID666)
			{
				if(seList2[iCurrentFile].bArchived==FALSE)
				{
					sprintf(szBuf0,"%s%s",seList2[iCurrentFile].szDirectory,seList2[iCurrentFile].szRealName);
				}
				else
				{
					char *szTempName=_tempnam(NULL,NULL);
					strcpy(szBuf0,szTempName);
					free(szTempName);
					switch(seList2[iCurrentFile].iSubType)
					{
					case LIST_ID_ACE:
						ExtractFileFromACE(seList2[iCurrentFile].szDirectory,seList2[iCurrentFile].szRealName,szBuf0);
						break;
					case LIST_ID_RAR:
						ExtractFileFromRAR(seList2[iCurrentFile].szDirectory,seList2[iCurrentFile].szRealName,szBuf0);
						break;
					case LIST_ID_ZIP:
						ExtractFileFromZIP(seList2[iCurrentFile].szDirectory,seList2[iCurrentFile].szRealName,szBuf0);
						break;
					}
					SetFileAttributes(szBuf0,FILE_ATTRIBUTE_NORMAL);
				}
				SNESAmp_GetID666Tag(szBuf0,&seList2[iCurrentFile].ID666);
				if(!seList2[iCurrentFile].ID666.bHasID666)
				{
					seList2[iCurrentFile].iLength=0;
					seList2[iCurrentFile].iFadeLength=0;
					seList2[iCurrentFile].iRepetitions=1;
				}
				else
				{
					seList2[iCurrentFile].iLength=seList2[iCurrentFile].ID666.Song_ms/1000;
					if(seList2[iCurrentFile].ID666.Song_ms%1000)
						seList2[iCurrentFile].iLength++;
					seList2[iCurrentFile].iFadeLength=seList2[iCurrentFile].ID666.Fade_ms/1000;
					if(seList2[iCurrentFile].ID666.Fade_ms%1000)
						seList2[iCurrentFile].iFadeLength++;
					seList2[iCurrentFile].iRepetitions=1;
				}
				if(seList2[iCurrentFile].bArchived==TRUE)
					remove(szBuf0);
			}
			else
			{
				seList2[iCurrentFile].iLength=0;
				seList2[iCurrentFile].iFadeLength=0;
				seList2[iCurrentFile].iRepetitions=1;
			}
			iFileCount++;
		}
	return 0;
}

BOOL CAddFilesDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	int nItem,iSPCCount;
	for(nItem=iSPCCount=0;nItem<seList1.size();nItem++)
		if(seList1[nItem].iType==LIST_ID_SPC&&seList1[nItem].bSelected)iSPCCount++;
	m_Progress1_1.SetRange(0,iSPCCount);
	KillThread=iFileCount=iCurrentFile=0;
	THand=AfxBeginThread(Thread,0);
	SetTimer(1,0,NULL);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CAddFilesDlg::OnCancel() 
{
	// TODO: Add extra cleanup here
	KillThread=1;
	if(WaitForSingleObject(THand->m_hThread,INFINITE)==WAIT_FAILED)
	{
		CloseHandle(THand->m_hThread);
		CDialog::OnCancel();
	}
}

void CAddFilesDlg::OnTimer(UINT nIDEvent) 
{
	// TODO: Add your message handler code here and/or call default
	m_Static1_1.SetWindowText(seList2[iCurrentFile].szName);
	m_Progress1_1.SetPos(iFileCount);
	if(WaitForSingleObject(THand->m_hThread,0)==WAIT_FAILED)
		EndDialog(IDCANCEL);

	CDialog::OnTimer(nIDEvent);
}