#ifndef _MIXER_H_
#define _MIXER_H_

UINT GetMixerIDForWaveMapper();
DWORD GetMixerControlID(UINT uMixerID,DWORD dwComponentType,DWORD dwControlType);
DWORD GetMixerControlValue(UINT uMixerID,DWORD dwControlID);
DWORD SetMixerControlValue(UINT uMixerID,DWORD dwControlID,DWORD dwControlValue);
void FadeOutVolume(UINT uMixerID,DWORD dwLength);

#endif