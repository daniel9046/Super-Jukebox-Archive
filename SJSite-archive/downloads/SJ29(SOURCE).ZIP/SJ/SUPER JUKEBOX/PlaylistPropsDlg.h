#if !defined(AFX_PLAYLISTPROPSDLG_H__CE61B4C3_6EB6_11D4_8925_009027C5CF93__INCLUDED_)
#define AFX_PLAYLISTPROPSDLG_H__CE61B4C3_6EB6_11D4_8925_009027C5CF93__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PlaylistPropsDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPlaylistPropsDlg dialog

class CPlaylistPropsDlg : public CDialog
{
// Construction
public:
	int iSJHeight;
	int iSJWidth;
	CPlaylistPropsDlg & operator =(const CPlaylistPropsDlg &dlg);
	CPlaylistPropsDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CPlaylistPropsDlg)
	enum { IDD = IDD_DIALOG3 };
	CEdit	m_edSkinFile;
	CComboBox	m_cbSkinLayout;
	CSpinButtonCtrl	m_ctlSpin3_1;
	CSpinButtonCtrl	m_ctlSpin3_2;
	CSpinButtonCtrl	m_ctlSpin3_3;
	int		m_nMode;
	BOOL	m_bAutoRewind;
	BOOL	m_bFadeOut;
	BOOL	m_bRandomize;
	BOOL	m_bDetectSilence;
	BOOL	m_bUseSkin;
	int		m_nSkinLayout;
	CString	m_cstrSkinFile;
	CString	m_strLength;
	CString	m_strFade;
	CString	m_strRepetitions;
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CPlaylistPropsDlg)
	public:
	virtual void OnOK();
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CPlaylistPropsDlg)
	virtual BOOL OnInitDialog();
	afx_msg void OnRadio3_1();
	afx_msg void OnRadio3_2();
	afx_msg void OnRadio3_3();
	afx_msg void OnButton3_1();
	afx_msg void OnCheck3_5();
	afx_msg void OnDeltaposSpin3_1(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDeltaposSpin3_2(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg BOOL OnHelpInfo(HELPINFO* pHelpInfo);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PLAYLISTPROPSDLG_H__CE61B4C3_6EB6_11D4_8925_009027C5CF93__INCLUDED_)
