// Super Jukebox.cpp : Defines the class behaviors for the application.
//

#include "stdafx.h"
#include "afxpriv.h"
#include "Super Jukebox.h"
#include "Super JukeboxDlg.h"
#include <mmsystem.h>
#include <direct.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSuperJukeboxApp

BEGIN_MESSAGE_MAP(CSuperJukeboxApp, CWinApp)
	//{{AFX_MSG_MAP(CSuperJukeboxApp)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSuperJukeboxApp construction

CSuperJukeboxApp::CSuperJukeboxApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance
}

/////////////////////////////////////////////////////////////////////////////
// The one and only CSuperJukeboxApp object

CSuperJukeboxApp theApp;

/////////////////////////////////////////////////////////////////////////////
// CSuperJukeboxApp initialization

BOOL CSuperJukeboxApp::InitInstance()
{
	// Standard initialization
	// If you are not using these features and wish to reduce the size
	//  of your final executable, you should remove from the following
	//  the specific initialization routines you do not need.

#ifdef _AFXDLL
	Enable3dControls();			// Call this when using MFC in a shared DLL
#else
	Enable3dControlsStatic();	// Call this when linking to MFC statically
#endif

	WNDCLASS wc;
	wc.style=CS_OWNDC;
	wc.lpfnWndProc=AfxWndProc;
	wc.cbClsExtra=0;
	wc.cbWndExtra=0;
	wc.hInstance=AfxGetInstanceHandle();
	wc.hIcon=NULL;
	wc.hCursor=(HCURSOR)::LoadCursor(NULL,IDC_ARROW);
	wc.hbrBackground=(HBRUSH)GetStockObject(BLACK_BRUSH);
	wc.lpszMenuName=NULL;
	wc.lpszClassName="VisWindow";
	if(!AfxRegisterClass(&wc))
		MessageBox(NULL,"Failed to register the visualization window class.",this->m_pszAppName,MB_ICONERROR);

#ifdef UNIMPORTED_UNRAR_DLL
	HMODULE hLibrary0;
	if((hLibrary0=LoadLibrary("UNRAR.DLL"))==NULL)
	{
		MessageBox(NULL,"A required .DLL file, UNRAR.DLL, was not found.","Error Starting Program",MB_ICONEXCLAMATION);
		return FALSE;
	}
	_RAROpenArchive=(pfnRAROpenArchive)GetProcAddress(hLibrary0,"RAROpenArchive");
	_RARCloseArchive=(pfnRARCloseArchive)GetProcAddress(hLibrary0,"RARCloseArchive");
	_RARReadHeader=(pfnRARReadHeader)GetProcAddress(hLibrary0,"RARReadHeader");
	_RARProcessFile=(pfnRARProcessFile)GetProcAddress(hLibrary0,"RARProcessFile");
	_RARSetChangeVolProc=(pfnRARSetChangeVolProc)GetProcAddress(hLibrary0,"RARSetChangeVolProc");
	_RARSetProcessDataProc=(pfnRARSetProcessDataProc)GetProcAddress(hLibrary0,"RARSetProcessDataProc");
	_RARSetPassword=(pfnRARSetPassword)GetProcAddress(hLibrary0,"RARSetPassword");
#endif
#ifdef UNIMPORTED_UNACE_DLL
	HMODULE hLibrary1;
	if((hLibrary1=LoadLibrary("UNACE.DLL"))==NULL)
	{
		MessageBox(NULL,"A required .DLL file, UNACE.DLL, was not found.","Error Starting Program",MB_ICONEXCLAMATION);
		return FALSE;
	}
	_ACEOpenArchive=(pfnACEOpenArchive)GetProcAddress(hLibrary1,"ACEOpenArchive");
	_ACECloseArchive=(pfnACECloseArchive)GetProcAddress(hLibrary1,"ACECloseArchive");
	_ACEReadHeader=(pfnACEReadHeader)GetProcAddress(hLibrary1,"ACEReadHeader");
	_ACEProcessFile=(pfnACEProcessFile)GetProcAddress(hLibrary1,"ACEProcessFile");
	_ACESetPassword=(pfnACESetPassword)GetProcAddress(hLibrary1,"ACESetPassword");
#endif

	srand(time(NULL));
	GetModuleFileName(theApp.m_hInstance,szProgramLocation,MAX_PATH);
	char szDrive[_MAX_DRIVE],szDir[_MAX_DIR];
	_splitpath(szProgramLocation,szDrive,szDir,NULL,NULL);
	strcpy(szProgramLocation,szDrive);strcat(szProgramLocation,szDir);
	if(strlen(theApp.m_lpCmdLine)>0)
	{
		if(theApp.m_lpCmdLine[0]=='/'||theApp.m_lpCmdLine[0]=='-')
		{
			char szBuffer[1000];
			strncpy(szBuffer,&theApp.m_lpCmdLine[1],999);
			if(!stricmp(szBuffer,"clear"))
			{
				RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Marius Fodor\\Super Jukebox");
			}
		}
		else
		{
			bLoadPlayList=TRUE;
			char szBuffer[MAX_PATH];
			_GetLongPathName(theApp.m_lpCmdLine,szBuffer,MAX_PATH-1);
			char szExt[_MAX_EXT];
			_splitpath(szBuffer,NULL,NULL,NULL,szExt);
			if(!stricmp(szExt,".lnk"))
				GetShortcutInfo(szBuffer,szPlayList,NULL);
			else
				strcpy(szPlayList,szBuffer);
		}
	}
	HKEY hKey;
	if(RegOpenKeyEx(HKEY_CURRENT_USER,"Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\Advanced",0,KEY_ALL_ACCESS,&hKey)==ERROR_SUCCESS)
	{
		DWORD dwSpare=0,dwSize=sizeof(dwSpare);
		RegQueryValueEx(hKey,"HideFileExt",NULL,NULL,(LPBYTE)&dwSpare,&dwSize);
		RegCloseKey(hKey);
		fShowExtensions=dwSpare^1;
	}
	hAccel=LoadAccelerators(m_hInstance,MAKEINTRESOURCE(IDR_ACCELERATOR_SUPER_JUKEBOX));
	ASSERT(hAccel);

	CSuperJukeboxDlg dlg;
	m_pMainWnd = &dlg;
	if(!dlg.Create(IDD_SUPERJUKEBOX_DIALOG))
	{
		MessageBox(NULL,"Failed to create the main dialog box.",m_pszAppName,MB_ICONERROR);
	}
	else
	{
		MSG msg;
		while(GetMessage(&msg,NULL,0,0)>0)
		{
			if(!TranslateAccelerator(dlg.GetSafeHwnd(),hAccel,&msg)&&!IsDialogMessage(dlg.GetSafeHwnd(),&msg))
			{
				TranslateMessage(&msg);
				DispatchMessage(&msg);
			}
		}
	}

#ifdef UNIMPORTED_UNRAR_DLL
	FreeLibrary(hLibrary0);
#endif
#ifdef UNIMPORTED_UNACE_DLL
	FreeLibrary(hLibrary1);
#endif

	// Since the dialog has been closed, return FALSE so that we exit the
	//  application, rather than start the application's message pump.
	return FALSE;
}

HRESULT CSuperJukeboxApp::GetShortcutInfo(LPCSTR lpszPathLink, LPSTR lpszPathObj, LPSTR lpszDesc)
{
	HRESULT hres;
	IShellLink* psl;

	if(SUCCEEDED(CoInitialize(NULL)))
	{
		hres=CoCreateInstance(CLSID_ShellLink,NULL,CLSCTX_INPROC_SERVER,IID_IShellLink,(LPVOID*)&psl);
		if(SUCCEEDED(hres))
		{
			IPersistFile* ppf;
			hres=psl->QueryInterface(IID_IPersistFile,(void**)&ppf);
			if(SUCCEEDED(hres))
			{
				WCHAR wsz[MAX_PATH];

				MultiByteToWideChar(CP_ACP,0,lpszPathLink,-1,wsz,MAX_PATH);
				hres=ppf->Load(wsz,0);
				if(!SUCCEEDED(hres))
					return hres;
				
				WIN32_FIND_DATA w32fd;
				if(lpszPathObj!=NULL)
				{
					hres=psl->GetPath(lpszPathObj,MAX_PATH,&w32fd,SLGP_UNCPRIORITY);
					if(!SUCCEEDED(hres))
						return hres;
				}
				if(lpszDesc!=NULL)
				{
					hres=psl->GetDescription(lpszDesc,MAX_PATH);
					if(!SUCCEEDED(hres))
						return hres;
				}

				ppf->Release();
				psl->Release();
			}
		}
		CoUninitialize();
	}
	return hres;
}