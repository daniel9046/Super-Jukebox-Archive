#include "stdafx.h"
#include "Unzip.h"
#include "Unrar.h"
#include "Unace.h"
#include "Globals.h"

BOOL ExtractFileFromZIP(const char *szArchiveName,const char *szFileName,const char *szOutputFileName)
{
	voidp vpBuffer;
	uLong l;
	unz_file_info ufiInfo;
	unzFile ufFile;
	FILE *fileOutFileHandle;

	if((ufFile=unzOpen(szArchiveName))==NULL) return FALSE;
	if(unzLocateFile(ufFile,szFileName,2)==UNZ_OK)
	{
		unzGetCurrentFileInfo(ufFile,&ufiInfo,NULL,0,NULL,0,NULL,0);
		if((vpBuffer=malloc(ufiInfo.uncompressed_size))==NULL) return FALSE;
		if(unzOpenCurrentFile(ufFile)!=UNZ_OK) {free(vpBuffer); return FALSE;}
		l=unzReadCurrentFile(ufFile,vpBuffer,ufiInfo.uncompressed_size);
		if(l<=0||l!=ufiInfo.uncompressed_size) {free(vpBuffer); return FALSE;}
		if(unzCloseCurrentFile(ufFile)==UNZ_CRCERROR) {free(vpBuffer); return FALSE;}
		if(unzClose(ufFile)!=UNZ_OK) {free(vpBuffer); return FALSE;}

		if((fileOutFileHandle=fopen(szOutputFileName,"wb"))==NULL) {free(vpBuffer); return FALSE;}
		if(fwrite(vpBuffer,ufiInfo.uncompressed_size,1,fileOutFileHandle)!=1) {free(vpBuffer); return FALSE;}
		if(fclose(fileOutFileHandle)!=0) {free(vpBuffer); return FALSE;}
		free(vpBuffer);
		return TRUE;
	}
	return FALSE;
}

BOOL ExtractFileFromRAR(const char *szArchiveName,const char *szFileName,const char *szOutputFileName)
{
	HANDLE hArcData;
	int RHCode,PFCode;
	RARHeaderData HeaderData;
	RAROpenArchiveData OpenArchiveData;

	OpenArchiveData.ArcName=(char*)szArchiveName;
	OpenArchiveData.CmtBuf=NULL;
	OpenArchiveData.OpenMode=RAR_OM_EXTRACT;
	if((hArcData=_RAROpenArchive(&OpenArchiveData))==NULL)return FALSE;
	HeaderData.CmtBuf=NULL;
	int iOp;
	while((RHCode=_RARReadHeader(hArcData,&HeaderData))==0)
	{
		if(!stricmp(HeaderData.FileName,szFileName))
			iOp=RAR_EXTRACT;
		else
			iOp=RAR_SKIP;
		if((PFCode=_RARProcessFile(hArcData,iOp,NULL,szOutputFileName))!=0)break;
		if(iOp==RAR_EXTRACT)break;
	}
	_RARCloseArchive(hArcData);
	if(RHCode==ERAR_BAD_DATA||PFCode)return FALSE;
	if(iOp!=RAR_EXTRACT)return FALSE;
	return TRUE;
}

BOOL ExtractFileFromACE(const char *szArchiveName,const char *szFileName,const char *szOutputFileName)
{
	HANDLE hArcData;
	int RHCode,PFCode;
	ACEHeaderData HeaderData;
	ACEOpenArchiveData OpenArchiveData;

	OpenArchiveData.ArcName=(char*)szArchiveName;
	OpenArchiveData.CmtBuf=NULL;
	OpenArchiveData.OpenMode=ACEOPEN_EXTRACT;
	OpenArchiveData.ChangeVolProc=NULL;
	OpenArchiveData.ProcessDataProc=NULL;
	if((hArcData=_ACEOpenArchive(&OpenArchiveData))==NULL)return FALSE;
	if(OpenArchiveData.OpenResult)return FALSE;
	HeaderData.CmtBuf=NULL;
	int iOp;
	while((RHCode=_ACEReadHeader(hArcData,&HeaderData))==0)
	{
		if(!stricmp(HeaderData.FileName,szFileName))
			iOp=ACECMD_EXTRACT;
		else
			iOp=ACECMD_SKIP;
		if((PFCode=_ACEProcessFile(hArcData,iOp,szOutputFileName))!=0)break;
		if(iOp==ACECMD_EXTRACT)break;
	}
	_ACECloseArchive(hArcData);
	if(RHCode==ACEERR_READ||PFCode)return FALSE;
	if(iOp!=ACECMD_EXTRACT)return FALSE;
	return TRUE;
}