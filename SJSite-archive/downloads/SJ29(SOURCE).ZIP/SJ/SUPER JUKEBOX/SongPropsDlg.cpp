// SongPropsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "super jukebox.h"
#include "SongPropsDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CSongPropsDlg dialog


CSongPropsDlg::CSongPropsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CSongPropsDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CSongPropsDlg)
	m_strTitle = _T("");
	m_strGame = _T("");
	m_strArtist = _T("");
	m_strDumper = _T("");
	m_strDate = _T("");
	m_strComment = _T("");
	m_strLength = _T("");
	m_strFade = _T("");
	m_strRepetitions = _T("");
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CSongPropsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CSongPropsDlg)
	DDX_Control(pDX, IDC_SPIN_ED_LENGTH, m_ctlSpin4_1);
	DDX_Control(pDX, IDC_SPIN_ED_FADE, m_ctlSpin4_2);
	DDX_Control(pDX, IDC_SPIN_ED_REPETITIONS, m_ctlSpin4_3);
	DDX_Control(pDX, IDC_EDIT_ED_REPETITIONS, m_edRepetitions);
	DDX_Control(pDX, IDC_EDIT_ED_FADE, m_edFade);
	DDX_Control(pDX, IDC_EDIT_ED_LENGTH, m_edLength);
	DDX_Control(pDX, IDC_EDIT_ED_COMMENT, m_edComment);
	DDX_Control(pDX, IDC_EDIT_ED_DATE, m_edDate);
	DDX_Control(pDX, IDC_EDIT_ED_DUMPER, m_edDumper);
	DDX_Control(pDX, IDC_EDIT_ED_ARTIST, m_edArtist);
	DDX_Control(pDX, IDC_EDIT_ED_GAME, m_edGame);
	DDX_Control(pDX, IDC_EDIT_ED_TITLE, m_edTitle);
	DDX_Control(pDX, IDC_LIST_ED_PLAYLIST, m_lbList4_1);
	DDX_Text(pDX, IDC_EDIT_ED_TITLE, m_strTitle);
	DDX_Text(pDX, IDC_EDIT_ED_GAME, m_strGame);
	DDX_Text(pDX, IDC_EDIT_ED_ARTIST, m_strArtist);
	DDX_Text(pDX, IDC_EDIT_ED_DUMPER, m_strDumper);
	DDX_Text(pDX, IDC_EDIT_ED_DATE, m_strDate);
	DDX_Text(pDX, IDC_EDIT_ED_COMMENT, m_strComment);
	DDX_Text(pDX, IDC_EDIT_ED_LENGTH, m_strLength);
	DDX_Text(pDX, IDC_EDIT_ED_FADE, m_strFade);
	DDX_Text(pDX, IDC_EDIT_ED_REPETITIONS, m_strRepetitions);
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CSongPropsDlg, CDialog)
	//{{AFX_MSG_MAP(CSongPropsDlg)
	ON_LBN_SELCHANGE(IDC_LIST_ED_PLAYLIST, OnSelchangeList4_1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_ED_LENGTH, OnDeltaposSpin4_1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_ED_FADE, OnDeltaposSpin4_2)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CSongPropsDlg message handlers

BOOL CSongPropsDlg::OnInitDialog()
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	seSpareList.clear();
	for(int i=0;i<seList2.size();i++)
	{
		seSpareList.push_back(seList2[i]);
		m_lbList4_1.AddString(seList2[i].szName);
	}

	iOldSelection=-1;
	if(seSpareList.size()&&iCurrentSong>=0)
	{
		m_lbList4_1.SetCurSel(iCurrentSong);
		m_strTitle=seSpareList[iCurrentSong].ID666.Song;
		m_strGame=seSpareList[iCurrentSong].ID666.Game;
		m_strArtist=seSpareList[iCurrentSong].ID666.Artist;
		m_strDumper=seSpareList[iCurrentSong].ID666.Dumper;
		m_strDate=seSpareList[iCurrentSong].ID666.Date;
		m_strComment=seSpareList[iCurrentSong].ID666.Comment;
		char szBuf[20];
		ConvertTimeUp(seSpareList[iCurrentSong].iLength,szBuf);
		m_strLength=szBuf;
		ConvertTimeUp(seSpareList[iCurrentSong].iFadeLength,szBuf);
		m_strFade=szBuf;
		m_strRepetitions.Format("%d",seSpareList[iCurrentSong].iRepetitions);		
		OnSelchangeList4_1();
	}
	else
	{
		m_strTitle="";
		m_edTitle.SetWindowText(m_strTitle);
		m_strGame="";
		m_edGame.SetWindowText(m_strGame);
		m_strArtist="";
		m_edArtist.SetWindowText(m_strArtist);
		m_strDumper="";
		m_edDumper.SetWindowText(m_strDumper);
		m_strDate="";
		m_edDate.SetWindowText(m_strDate);
		m_strComment="";
		m_edComment.SetWindowText(m_strComment);
		m_strLength="0";
		m_edLength.SetWindowText("0");
		m_strFade="0";
		m_edFade.SetWindowText("0");
		m_strRepetitions="1";
		m_edRepetitions.SetWindowText("1");
		if(!seSpareList.size())
		{
			m_lbList4_1.EnableWindow(FALSE);
			m_edTitle.EnableWindow(FALSE);
			m_edGame.EnableWindow(FALSE);
			m_edArtist.EnableWindow(FALSE);
			m_edDumper.EnableWindow(FALSE);
			m_edDate.EnableWindow(FALSE);
			m_edComment.EnableWindow(FALSE);
			m_edLength.EnableWindow(FALSE);
			m_edFade.EnableWindow(FALSE);
			m_edRepetitions.EnableWindow(FALSE);
		}
	}
	m_ctlSpin4_1.SetRange(0,UD_MAXVAL);
	m_ctlSpin4_2.SetRange(0,UD_MAXVAL);
	m_ctlSpin4_3.SetRange(1,UD_MAXVAL);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CSongPropsDlg::OnSelchangeList4_1() 
{
	// TODO: Add your control notification handler code here
	int iIndex=m_lbList4_1.GetCurSel();
	char szBuffer[200];

	if(iOldSelection>=0&&iOldSelection!=iIndex)
	{
		m_edTitle.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(strcmp((char*)seSpareList[iOldSelection].ID666.Song,szBuffer))
		{
			strcpy((char*)seSpareList[iOldSelection].ID666.Song,szBuffer);
			m_bModified=TRUE;
		}
		m_edGame.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(strcmp((char*)seSpareList[iOldSelection].ID666.Game,szBuffer))
		{
			strcpy((char*)seSpareList[iOldSelection].ID666.Game,szBuffer);
			m_bModified=TRUE;
		}
		m_edArtist.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(strcmp((char*)seSpareList[iOldSelection].ID666.Artist,szBuffer))
		{
			strcpy((char*)seSpareList[iOldSelection].ID666.Artist,szBuffer);
			m_bModified=TRUE;
		}
		m_edDumper.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(strcmp((char*)seSpareList[iOldSelection].ID666.Dumper,szBuffer))
		{
			strcpy((char*)seSpareList[iOldSelection].ID666.Dumper,szBuffer);
			m_bModified=TRUE;
		}
		m_edDate.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(strcmp((char*)seSpareList[iOldSelection].ID666.Date,szBuffer))
		{
			strcpy((char*)seSpareList[iOldSelection].ID666.Date,szBuffer);
			m_bModified=TRUE;
		}
		m_edComment.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(strcmp((char*)seSpareList[iOldSelection].ID666.Comment,szBuffer))
		{
			strcpy((char*)seSpareList[iOldSelection].ID666.Comment,szBuffer);
			m_bModified=TRUE;
		}
		m_edLength.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(seSpareList[iOldSelection].iLength!=ConvertTimeDown(szBuffer))
		{
			seSpareList[iOldSelection].iLength=ConvertTimeDown(szBuffer);
			m_bModified=TRUE;
		}
		m_edFade.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(seSpareList[iOldSelection].iFadeLength!=ConvertTimeDown(szBuffer))
		{
			seSpareList[iOldSelection].iFadeLength=ConvertTimeDown(szBuffer);
			m_bModified=TRUE;
		}
		m_edRepetitions.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(seSpareList[iOldSelection].iRepetitions!=atoi(szBuffer))
		{
			seSpareList[iOldSelection].iRepetitions=atoi(szBuffer);
			m_bModified=TRUE;
		}
	}
	
	m_edTitle.SetWindowText((char*)seSpareList[iIndex].ID666.Song);
	m_edGame.SetWindowText((char*)seSpareList[iIndex].ID666.Game);
	m_edArtist.SetWindowText((char*)seSpareList[iIndex].ID666.Artist);
	m_edDumper.SetWindowText((char*)seSpareList[iIndex].ID666.Dumper);
	m_edDate.SetWindowText((char*)seSpareList[iIndex].ID666.Date);
	m_edComment.SetWindowText((char*)seSpareList[iIndex].ID666.Comment);
	char szBuf[20];
	ConvertTimeUp(seSpareList[iIndex].iLength,szBuf);
	m_edLength.SetWindowText(szBuf);
	ConvertTimeUp(seSpareList[iIndex].iFadeLength,szBuf);
	m_edFade.SetWindowText(szBuf);
	itoa(seSpareList[iIndex].iRepetitions,szBuffer,10);
	m_edRepetitions.SetWindowText(szBuffer);

	iOldSelection=iIndex;
}

void CSongPropsDlg::OnOK() 
{
	// TODO: Add your specialized code here and/or call the base class
	int iIndex=m_lbList4_1.GetCurSel();
	char szBuffer[200];

	if(iIndex>=0)
	{
		m_edTitle.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(strcmp((char*)seSpareList[iIndex].ID666.Song,szBuffer))
		{
			strcpy((char*)seSpareList[iIndex].ID666.Song,szBuffer);
			m_bModified=TRUE;
		}
		m_edGame.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(strcmp((char*)seSpareList[iIndex].ID666.Game,szBuffer))
		{
			strcpy((char*)seSpareList[iIndex].ID666.Game,szBuffer);
			m_bModified=TRUE;
		}
		m_edArtist.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(strcmp((char*)seSpareList[iIndex].ID666.Artist,szBuffer))
		{
			strcpy((char*)seSpareList[iIndex].ID666.Artist,szBuffer);
			m_bModified=TRUE;
		}
		m_edDumper.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(strcmp((char*)seSpareList[iIndex].ID666.Dumper,szBuffer))
		{
			strcpy((char*)seSpareList[iIndex].ID666.Dumper,szBuffer);
			m_bModified=TRUE;
		}
		m_edDate.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(strcmp((char*)seSpareList[iIndex].ID666.Date,szBuffer))
		{
			strcpy((char*)seSpareList[iIndex].ID666.Date,szBuffer);
			m_bModified=TRUE;
		}
		m_edComment.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(strcmp((char*)seSpareList[iIndex].ID666.Comment,szBuffer))
		{
			strcpy((char*)seSpareList[iIndex].ID666.Comment,szBuffer);
			m_bModified=TRUE;
		}
		m_edLength.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(seSpareList[iIndex].iLength!=ConvertTimeDown(szBuffer))
		{
			seSpareList[iIndex].iLength=ConvertTimeDown(szBuffer);
			m_bModified=TRUE;
		}
		m_edFade.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(seSpareList[iIndex].iFadeLength!=ConvertTimeDown(szBuffer))
		{
			seSpareList[iIndex].iFadeLength=ConvertTimeDown(szBuffer);
			m_bModified=TRUE;
		}
		m_edRepetitions.GetWindowText(szBuffer,sizeof(szBuffer)-1);
		if(seSpareList[iIndex].iRepetitions!=atoi(szBuffer))
		{
			seSpareList[iIndex].iRepetitions=atoi(szBuffer);
			m_bModified=TRUE;
		}

	}

	if(m_bModified)
	{
		seList2.clear();
		for(int i=0;i<seSpareList.size();i++)
			seList2.push_back(seSpareList[i]);
	}
	
	CDialog::OnOK();
}

void CSongPropsDlg::OnDeltaposSpin4_1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	char szBuf[500];

	m_edLength.GetWindowText(szBuf,500);
	ConvertTimeUp(ConvertTimeDown(szBuf)+pNMUpDown->iDelta,szBuf);
	m_edLength.SetWindowText(szBuf);
	
	*pResult = 1;
}

void CSongPropsDlg::OnDeltaposSpin4_2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	char szBuf[500];

	m_edFade.GetWindowText(szBuf,500);
	ConvertTimeUp(ConvertTimeDown(szBuf)+pNMUpDown->iDelta,szBuf);
	m_edFade.SetWindowText(szBuf);

	*pResult = 1;
}

BOOL CSongPropsDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	// TODO: Add your message handler code here and/or call default
	if(pHelpInfo->iContextType==HELPINFO_WINDOW)
	{
		WinHelp(pHelpInfo->dwContextId,HELP_CONTEXTPOPUP);
	}
	
	return CDialog::OnHelpInfo(pHelpInfo);
}
