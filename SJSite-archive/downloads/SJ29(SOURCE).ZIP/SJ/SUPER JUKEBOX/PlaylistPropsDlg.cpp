// PlaylistPropsDlg.cpp : implementation file
//

#include "stdafx.h"
#include "super jukebox.h"
#include "PlaylistPropsDlg.h"
#include "Globals.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPlaylistPropsDlg dialog


CPlaylistPropsDlg::CPlaylistPropsDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CPlaylistPropsDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CPlaylistPropsDlg)
	m_nMode = 0;
	m_bAutoRewind = FALSE;
	m_bFadeOut = FALSE;
	m_bRandomize = FALSE;
	m_bDetectSilence = FALSE;
	m_bUseSkin = FALSE;
	m_nSkinLayout = 0;
	m_cstrSkinFile = _T("");
	m_strLength = _T("");
	m_strFade = _T("");
	m_strRepetitions = _T("");
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CPlaylistPropsDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPlaylistPropsDlg)
	DDX_Control(pDX, IDC_EDIT_SKIN_FILE, m_edSkinFile);
	DDX_Control(pDX, IDC_COMBO_SKIN_LAYOUT, m_cbSkinLayout);
	DDX_Control(pDX, IDC_SPIN_UNI_LENGTH, m_ctlSpin3_1);
	DDX_Control(pDX, IDC_SPIN_UNI_FADE, m_ctlSpin3_2);
	DDX_Control(pDX, IDC_SPIN_UNI_REPETITIONS, m_ctlSpin3_3);
	DDX_Radio(pDX, IDC_RADIO_INDEFINITE, m_nMode);
	DDX_Check(pDX, IDC_CHECK_AUTO_REWIND, m_bAutoRewind);
	DDX_Check(pDX, IDC_CHECK_FADE_OUT, m_bFadeOut);
	DDX_Check(pDX, IDC_CHECK_RANDOMIZE, m_bRandomize);
	DDX_Check(pDX, IDC_CHECK_DETECT_INACTIVITY, m_bDetectSilence);
	DDX_Check(pDX, IDC_CHECK_USE_SKIN, m_bUseSkin);
	DDX_CBIndex(pDX, IDC_COMBO_SKIN_LAYOUT, m_nSkinLayout);
	DDX_Text(pDX, IDC_EDIT_SKIN_FILE, m_cstrSkinFile);
	DDX_Text(pDX, IDC_EDIT_UNI_LENGTH, m_strLength);
	DDX_Text(pDX, IDC_EDIT_UNI_FADE, m_strFade);
	DDX_Text(pDX, IDC_EDIT_UNI_REPETITIONS, m_strRepetitions);
		// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPlaylistPropsDlg, CDialog)
	//{{AFX_MSG_MAP(CPlaylistPropsDlg)
	ON_BN_CLICKED(IDC_RADIO_INDEFINITE, OnRadio3_1)
	ON_BN_CLICKED(IDC_RADIO_UNIVERSAL, OnRadio3_2)
	ON_BN_CLICKED(IDC_RADIO_INDIVIDUAL, OnRadio3_3)
	ON_BN_CLICKED(IDC_BUTTON_BROWSE_SKIN, OnButton3_1)
	ON_BN_CLICKED(IDC_CHECK_USE_SKIN, OnCheck3_5)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_UNI_LENGTH, OnDeltaposSpin3_1)
	ON_NOTIFY(UDN_DELTAPOS, IDC_SPIN_UNI_FADE, OnDeltaposSpin3_2)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPlaylistPropsDlg message handlers

CPlaylistPropsDlg & CPlaylistPropsDlg::operator =(const CPlaylistPropsDlg &obj)
{
	if(this==&obj)
		return *this;
	m_nMode=obj.m_nMode;
	m_strLength=obj.m_strLength;
	m_strFade=obj.m_strFade;
	m_strRepetitions=obj.m_strRepetitions;
	m_bAutoRewind=obj.m_bAutoRewind;
	m_bFadeOut=obj.m_bFadeOut;
	m_bRandomize=obj.m_bRandomize;
	m_bDetectSilence=obj.m_bDetectSilence;
	m_bUseSkin=obj.m_bUseSkin;
	m_nSkinLayout=obj.m_nSkinLayout;
	m_cstrSkinFile=obj.m_cstrSkinFile;
	return *this;
}

BOOL CPlaylistPropsDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	GetDlgItem(IDC_EDIT_UNI_LENGTH)->EnableWindow(m_nMode==1);
	GetDlgItem(IDC_SPIN_UNI_LENGTH)->EnableWindow(m_nMode==1);
	GetDlgItem(IDC_EDIT_UNI_FADE)->EnableWindow(m_nMode==1);
	GetDlgItem(IDC_SPIN_UNI_FADE)->EnableWindow(m_nMode==1);
	GetDlgItem(IDC_EDIT_UNI_REPETITIONS)->EnableWindow(m_nMode==1);
	GetDlgItem(IDC_SPIN_UNI_REPETITIONS)->EnableWindow(m_nMode==1);
	m_ctlSpin3_1.SetRange(0,UD_MAXVAL);
	m_ctlSpin3_2.SetRange(0,UD_MAXVAL);
	m_ctlSpin3_3.SetRange(1,UD_MAXVAL);
	GetDlgItem(IDC_RADIO_INDIVIDUAL)->EnableWindow(seList2.size());
	GetDlgItem(IDC_COMBO_SKIN_LAYOUT)->EnableWindow(m_bUseSkin);
	GetDlgItem(IDC_EDIT_SKIN_FILE)->EnableWindow(m_bUseSkin);	
	GetDlgItem(IDC_BUTTON_BROWSE_SKIN)->EnableWindow(m_bUseSkin);	
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CPlaylistPropsDlg::OnRadio3_1() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_EDIT_UNI_LENGTH)->EnableWindow(FALSE);
	GetDlgItem(IDC_SPIN_UNI_LENGTH)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_UNI_FADE)->EnableWindow(FALSE);
	GetDlgItem(IDC_SPIN_UNI_FADE)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_UNI_REPETITIONS)->EnableWindow(FALSE);
	GetDlgItem(IDC_SPIN_UNI_REPETITIONS)->EnableWindow(FALSE);
}

void CPlaylistPropsDlg::OnRadio3_2() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_EDIT_UNI_LENGTH)->EnableWindow(TRUE);
	GetDlgItem(IDC_SPIN_UNI_LENGTH)->EnableWindow(TRUE);
	GetDlgItem(IDC_EDIT_UNI_FADE)->EnableWindow(TRUE);
	GetDlgItem(IDC_SPIN_UNI_FADE)->EnableWindow(TRUE);
	GetDlgItem(IDC_EDIT_UNI_REPETITIONS)->EnableWindow(TRUE);
	GetDlgItem(IDC_SPIN_UNI_REPETITIONS)->EnableWindow(TRUE);
	char szBuffer[10];
	ConvertTimeUp(iSongLength,szBuffer);
	GetDlgItem(IDC_EDIT_UNI_LENGTH)->SetWindowText(szBuffer);
	ConvertTimeUp(iFadeLength,szBuffer);
	GetDlgItem(IDC_EDIT_UNI_FADE)->SetWindowText(szBuffer);
	itoa(iSongRepetitions,szBuffer,10);
	GetDlgItem(IDC_EDIT_UNI_REPETITIONS)->SetWindowText(szBuffer);
}

void CPlaylistPropsDlg::OnRadio3_3() 
{
	// TODO: Add your control notification handler code here
	GetDlgItem(IDC_EDIT_UNI_LENGTH)->EnableWindow(FALSE);
	GetDlgItem(IDC_SPIN_UNI_LENGTH)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_UNI_FADE)->EnableWindow(FALSE);
	GetDlgItem(IDC_SPIN_UNI_FADE)->EnableWindow(FALSE);
	GetDlgItem(IDC_EDIT_UNI_REPETITIONS)->EnableWindow(FALSE);
	GetDlgItem(IDC_SPIN_UNI_REPETITIONS)->EnableWindow(FALSE);
}

void CPlaylistPropsDlg::OnButton3_1() 
{
	// TODO: Add your control notification handler code here
	CFileDialog dlg(TRUE,"BMP",m_cstrSkinFile,OFN_NOCHANGEDIR|OFN_HIDEREADONLY,"Bitmap Files (.BMP)|*.BMP|All Files (*.*)|*.*||");
	if(dlg.DoModal()!=IDOK)return;
	GetDlgItem(IDC_EDIT_SKIN_FILE)->SetWindowText(dlg.GetPathName());
}

void CPlaylistPropsDlg::OnCheck3_5() 
{
	// TODO: Add your control notification handler code here
	if(IsDlgButtonChecked(IDC_CHECK_USE_SKIN))
	{
		GetDlgItem(IDC_COMBO_SKIN_LAYOUT)->EnableWindow(TRUE);
		GetDlgItem(IDC_EDIT_SKIN_FILE)->EnableWindow(TRUE);	
		GetDlgItem(IDC_BUTTON_BROWSE_SKIN)->EnableWindow(TRUE);	
	}
	else
	{
		GetDlgItem(IDC_COMBO_SKIN_LAYOUT)->EnableWindow(FALSE);
		GetDlgItem(IDC_EDIT_SKIN_FILE)->EnableWindow(FALSE);	
		GetDlgItem(IDC_BUTTON_BROWSE_SKIN)->EnableWindow(FALSE);	
	}
}

void CPlaylistPropsDlg::OnOK() 
{
	// TODO: Add your specialized code here and/or call the base class
	if(IsDlgButtonChecked(IDC_CHECK_USE_SKIN))
	{
		char szBuffer[MAX_PATH];
		m_edSkinFile.GetWindowText(szBuffer,MAX_PATH);
		if(!strlen(szBuffer))
		{
			MessageBox("You must enter a value for the 'Skin file' field.",NULL,MB_ICONINFORMATION);
			m_edSkinFile.SetFocus();
			return;
		}
		HBITMAP hBmp,hBmp0;
		HDC hDC,hDC0;
		if((hBmp=(HBITMAP)LoadImage(NULL,szBuffer,IMAGE_BITMAP,0,0,LR_LOADFROMFILE))==NULL)
		{
			MessageBox("Could not load the specified bitmap file, please verify.",NULL,MB_ICONINFORMATION);
			return;
		}
		if(m_cbSkinLayout.GetCurSel()==1)
		{
			BITMAP bitmap;
			if(!GetObject(hBmp,sizeof(BITMAP),&bitmap))
			{
				DeleteObject(hBmp);
				MessageBox("Could not read the specified bitmap file.",NULL,MB_ICONINFORMATION);
				return;
			}
			hDC=CreateCompatibleDC(GetDC()->m_hDC);
			SelectObject(hDC,hBmp);
			hDC0=CreateCompatibleDC(GetDC()->m_hDC);
			hBmp0=CreateCompatibleBitmap(hDC0,iSJWidth,iSJHeight);
			SelectObject(hDC0,hBmp0);
			if(!StretchBlt(hDC0,0,0,iSJWidth,iSJHeight,hDC,0,0,bitmap.bmWidth,bitmap.bmHeight,SRCCOPY))
			{
				DeleteDC(hDC0);
				DeleteObject(hBmp0);
				DeleteDC(hDC);
				DeleteObject(hBmp);
				MessageBox("The specified bitmap file cannot be stretched onto the current size of the Super Jukebox window, try reducing the size of the Super Jukebox window or select Tile mode instead.",NULL,MB_ICONINFORMATION);
				return;
			}
			DeleteDC(hDC0);
			DeleteObject(hBmp0);
			DeleteDC(hDC);
			DeleteObject(hBmp);
		}
		else
		{
			DeleteObject(hBmp);
		}
	}
	
	CDialog::OnOK();
}

void CPlaylistPropsDlg::OnDeltaposSpin3_1(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	char szBuf[500];

	GetDlgItem(IDC_EDIT_UNI_LENGTH)->GetWindowText(szBuf,500);
	ConvertTimeUp(ConvertTimeDown(szBuf)+pNMUpDown->iDelta,szBuf);
	GetDlgItem(IDC_EDIT_UNI_LENGTH)->SetWindowText(szBuf);
	
	*pResult = 1;
}

void CPlaylistPropsDlg::OnDeltaposSpin3_2(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NM_UPDOWN* pNMUpDown = (NM_UPDOWN*)pNMHDR;
	// TODO: Add your control notification handler code here
	char szBuf[500];

	GetDlgItem(IDC_EDIT_UNI_FADE)->GetWindowText(szBuf,500);
	ConvertTimeUp(ConvertTimeDown(szBuf)+pNMUpDown->iDelta,szBuf);
	GetDlgItem(IDC_EDIT_UNI_FADE)->SetWindowText(szBuf);
	
	*pResult = 1;
}
BOOL CPlaylistPropsDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	// TODO: Add your message handler code here and/or call default
	if(pHelpInfo->iContextType==HELPINFO_WINDOW)
	{
		WinHelp(pHelpInfo->dwContextId,HELP_CONTEXTPOPUP);
	}
	
	return CDialog::OnHelpInfo(pHelpInfo);
}
