// ActiveWallpaper.cpp: implementation of the CActiveWallpaper class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "super jukebox.h"
#include "ActiveWallpaper.h"
#include <math.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

int VUMeter(int VMax);

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CString CActiveWallpaper::strSpare;
BOOL CActiveWallpaper::bKillThread;
HWND CActiveWallpaper::hWndParent;
int CActiveWallpaper::nWidth,CActiveWallpaper::nHeight,CActiveWallpaper::nRate;
TCHAR CActiveWallpaper::szDllName[MAX_PATH];
CStatusBarCtrl *CActiveWallpaper::m_StatusBar;
AW1_RENDERPROC CActiveWallpaper::pAW1_Render;
BOOL CActiveWallpaper::bRunning,CActiveWallpaper::bLibLoaded;

CActiveWallpaper::CActiveWallpaper()
{
	THand=NULL;
	hWndParent=NULL;
	bPaused=bRunning=bLibLoaded=FALSE;
	pAW1_SetParameters=NULL;
	pAW1_Render=NULL;
	hPluginLib=NULL;
}

CActiveWallpaper::~CActiveWallpaper()
{

}

int CActiveWallpaper::Start()
{
	if(!bLibLoaded)
		return 0;

	if(!THand)
	{
		HDC hDCParent=GetDC(hWndParent);
		HDC hDCBack=CreateCompatibleDC(hDCParent);
		HBITMAP hBmpBack=CreateCompatibleBitmap(hDCParent,nWidth,nHeight);
		SaveDC(hDCBack);
		SelectObject(hDCBack,hBmpBack);
		if(!bPaused&&!(*pAW1_Start)(hDCBack))
		{
			MessageBox(hWndParent,"Failed to start the Active Wallpaper.",AfxGetApp()->m_pszAppName,MB_ICONERROR);
			return 0;
		}
		BitBlt(hDCParent,0,0,nWidth,nHeight,hDCBack,0,0,SRCCOPY);
		RestoreDC(hDCBack,-1);
		DeleteDC(hDCBack);
		DeleteObject(hBmpBack);
		ReleaseDC(hWndParent,hDCParent);
		bKillThread=FALSE;
		DWORD dwThreadID;
		if((THand=::CreateThread(NULL,0,Thread,NULL,0,&dwThreadID))!=NULL)
		{
			bRunning=TRUE;
			bPaused=FALSE;
			return 1;
		}
	}
	return 0;
}

int CActiveWallpaper::Stop(int Pause)
{
	if(!bLibLoaded)
		return 0;

	if(THand)
	{
		bKillThread=TRUE;
		if(WaitForSingleObject(THand,3000)==WAIT_TIMEOUT)
		{
			MessageBox(NULL,"The Active Wallpaper thread won't cooperate. Press OK to terminate.",AfxGetApp()->m_pszAppName,MB_ICONERROR);
			TerminateThread(THand,0);
		}
		CloseHandle(THand);
		if(!Pause)
		{
			HDC hDCParent=GetDC(hWndParent);
			HDC hDCBack=CreateCompatibleDC(hDCParent);
			HBITMAP hBmpBack=CreateCompatibleBitmap(hDCParent,nWidth,nHeight);
			SaveDC(hDCBack);
			SelectObject(hDCBack,hBmpBack);
			if(!(*pAW1_Stop)(hDCBack))
			{
				MessageBox(hWndParent,"Failed to stop the Active Wallpaper.",AfxGetApp()->m_pszAppName,MB_ICONERROR);
				return 0;
			}
			BitBlt(hDCParent,0,0,nWidth,nHeight,hDCBack,0,0,SRCCOPY);
			RestoreDC(hDCBack,-1);
			DeleteDC(hDCBack);
			DeleteObject(hBmpBack);
			ReleaseDC(hWndParent,hDCParent);
		}
		bPaused=Pause;
		THand=NULL;
		bRunning=FALSE;
		return 1;
	}
	else if(bPaused)
	{
		HDC hDCParent=GetDC(hWndParent);
		HDC hDCBack=CreateCompatibleDC(hDCParent);
		HBITMAP hBmpBack=CreateCompatibleBitmap(hDCParent,nWidth,nHeight);
		SaveDC(hDCBack);
		SelectObject(hDCBack,hBmpBack);
		if(!(*pAW1_Stop)(hDCBack))
		{
			MessageBox(hWndParent,"Failed to stop the Active Wallpaper.",AfxGetApp()->m_pszAppName,MB_ICONERROR);
			return 0;
		}
		BitBlt(hDCParent,0,0,nWidth,nHeight,hDCBack,0,0,SRCCOPY);
		RestoreDC(hDCBack,-1);
		DeleteDC(hDCBack);
		DeleteObject(hBmpBack);
		ReleaseDC(hWndParent,hDCParent);
		bPaused=FALSE;
		bRunning=FALSE;
		return 1;
	}
	return 0;
}

DWORD WINAPI CActiveWallpaper::Thread(LPVOID lpParameter)
{
	HDC hDCParent=GetDC(hWndParent);
	HDC hDCBack=CreateCompatibleDC(hDCParent);
	HBITMAP hBmpBack=CreateCompatibleBitmap(hDCParent,nWidth,nHeight);
	SaveDC(hDCBack);
	SelectObject(hDCBack,hBmpBack);

	DWORD dwStartTime=GetTickCount(),dwCount=0;
	VIS_PARAMS vp,old_vp;
	SNESAmp_GetVisParams(&old_vp);
	while(!bKillThread)
	{
		SNESAmp_GetVisParams(&vp);
		if(vp.dwCount!=old_vp.dwCount)
		{
			if(!Render(hDCBack,&vp))
				MessageBox(hWndParent,"The Render function has failed.",AfxGetApp()->m_pszAppName,MB_ICONERROR);
			BitBlt(hDCParent,0,0,nWidth,nHeight,hDCBack,0,0,SRCCOPY);
			old_vp=vp;
		}
		Sleep(10);		
		dwCount++;
		int nFrameRate=1000/((GetTickCount()-dwStartTime)/dwCount);
		strSpare.Format("%d",nFrameRate);
	}
	RestoreDC(hDCBack,-1);
	DeleteDC(hDCBack);
	DeleteObject(hBmpBack);
	ReleaseDC(hWndParent,hDCParent);
	return 0;
}

int CActiveWallpaper::Render(HDC hDCDest,VIS_PARAMS *vp)
{
	if(!bLibLoaded)
		return 0;

	if(!(*pAW1_Render)(hDCDest,vp))
		return 0;

	return 1;
}

int CActiveWallpaper::SetParameters(HWND hWndParent,int nRate,int nWidth,int nHeight)
{
	if(!bLibLoaded)
		return 0;

	BOOL bTemp=bRunning;
	if(bTemp)
		Stop(1);

	this->nRate=nRate;
	this->hWndParent=hWndParent;
	this->nWidth=nWidth;
	this->nHeight=nHeight;
	if(!(*pAW1_SetParameters)(nRate,nWidth,nHeight))
		return 0;

	if(bTemp)
		Start();
	return 1;
}

int CActiveWallpaper::LoadPlugin(LPCTSTR lpszDllName)
{
	if(bLibLoaded)
		return 0;

	TCHAR szFullDllName[MAX_PATH];

	sprintf(szFullDllName,"plugins\\%s",lpszDllName);
	hPluginLib=LoadLibrary(szFullDllName);
	if(!hPluginLib)
		return 0;

	pAW1_SetParameters=(AW1_SETPARAMETERSPROC)GetProcAddress(hPluginLib,"AW1_SetParameters");
	pAW1_Render=(AW1_RENDERPROC)GetProcAddress(hPluginLib,"AW1_Render");
	pAW1_Start=(AW1_STARTPROC)GetProcAddress(hPluginLib,"AW1_Start");
	pAW1_Stop=(AW1_STOPPROC)GetProcAddress(hPluginLib,"AW1_Stop");
	if(!pAW1_SetParameters||
	   !pAW1_Render||
	   !pAW1_Start||
	   !pAW1_Stop)
	{
		FreeLibrary(hPluginLib);
		hPluginLib=NULL;
		return 0;
	}
	bLibLoaded=TRUE;
	return 1;
}

int CActiveWallpaper::UnloadPlugin()
{
	if(!bLibLoaded)
		return 0;

	FreeLibrary(hPluginLib);
	hPluginLib=NULL;
	bLibLoaded=FALSE;
	return 1;
}