// PropPage5.cpp : implementation file
//

#include "stdafx.h"
#include "super jukebox.h"
#include "PropPage5.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropPage5 property page

IMPLEMENT_DYNCREATE(CPropPage5, CPropertyPage)

CPropPage5::CPropPage5() : CPropertyPage(CPropPage5::IDD)
{
	//{{AFX_DATA_INIT(CPropPage5)
		// NOTE: the ClassWizard will add member initialization here
	m_nPriority = -1;
	m_bUseID666 = FALSE;
	m_bAutoLoadPlaylist = FALSE;
	m_bAutoSizeColumns = FALSE;
	//}}AFX_DATA_INIT
}

CPropPage5::~CPropPage5()
{
}

void CPropPage5::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPage5)
		// NOTE: the ClassWizard will add DDX and DDV calls here
	DDX_CBIndex(pDX, IDC_COMBO_PRIORITY_CLASS, m_nPriority);
	DDX_Check(pDX, IDC_CHECK_READ_ID666_TAGS, m_bUseID666);
	DDX_Check(pDX, IDC_CHECK_AL_LAST_PL, m_bAutoLoadPlaylist);
	DDX_Check(pDX, IDC_CHECK_AS_PL_COLUMNS, m_bAutoSizeColumns);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPage5, CPropertyPage)
	//{{AFX_MSG_MAP(CPropPage5)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropPage5 message handlers

CPropPage5 & CPropPage5::operator =(const CPropPage5 &obj)
{
	if(this==&obj)
		return *this;
	m_nPriority=obj.m_nPriority;
	m_bUseID666=obj.m_bUseID666;
	m_bAutoLoadPlaylist=obj.m_bAutoLoadPlaylist;
	m_bAutoSizeColumns=obj.m_bAutoSizeColumns;
	return *this;
}