#ifndef _MSG_H_
#define _MSG_H_

struct Message
{
	UINT uMsg;
	WPARAM wParam;
	LPARAM lParam;
	LPTSTR lpszName;
	LPVOID lpNext;
};

void DumpMessages(Message *msg);
void AddMessage(Message *msg,UINT uMsg,WPARAM wParam,LPARAM lParam);

#endif