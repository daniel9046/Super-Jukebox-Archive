#if !defined(AFX_PROPPAGE4_H__C35B2541_6969_11D4_8925_009027C5CF93__INCLUDED_)
#define AFX_PROPPAGE4_H__C35B2541_6969_11D4_8925_009027C5CF93__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropPage4.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropPage4 dialog

class CPropPage4 : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropPage4)

// Construction
public:
	CPropPage4();
	~CPropPage4();
	CPropPage4 & operator =(const CPropPage4 &obj);

// Dialog Data
	//{{AFX_DATA(CPropPage4)
	enum { IDD = IDD_DIALOG6 };
	CSpinButtonCtrl	m_ctlSpinBufferLength;
	CSpinButtonCtrl	m_ctlSpinPreamp;
	int		m_nFreq;
	int		m_nBits;
	int		m_nChan;
	int		m_iPreamp;
	int		m_nInterpolation;
	int		m_nAPR;
	BOOL	m_bUseOldBRE;
	BOOL	m_bUseLPF;
	int		m_nThreadPriority;
	UINT	m_nBufferLength;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropPage4)
	public:
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropPage4)
	virtual BOOL OnInitDialog();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPPAGE4_H__C35B2541_6969_11D4_8925_009027C5CF93__INCLUDED_)
