#if !defined(AFX_ADDFILESDLG_H__3981EE21_21E9_11D4_8925_006097C04AC0__INCLUDED_)
#define AFX_ADDFILESDLG_H__3981EE21_21E9_11D4_8925_006097C04AC0__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// AddFilesDlg.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CAddFilesDlg dialog

class CAddFilesDlg : public CDialog
{
// Construction
public:
	CWinThread *THand;
	static int KillThread,iFileCount,iCurrentFile;
	static BOOL m_bUseID666;
	static UINT Thread(LPVOID lpParameter);
	CAddFilesDlg(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CAddFilesDlg)
	enum { IDD = IDD_DIALOG1 };
	CStatic	m_Static1_1;
	CProgressCtrl	m_Progress1_1;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CAddFilesDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CAddFilesDlg)
	virtual BOOL OnInitDialog();
	virtual void OnCancel();
	afx_msg void OnTimer(UINT nIDEvent);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_ADDFILESDLG_H__3981EE21_21E9_11D4_8925_006097C04AC0__INCLUDED_)
