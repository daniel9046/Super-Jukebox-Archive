#ifndef _EXTRACTORS_H_
#define _EXTRACTORS_H_

BOOL ExtractFileFromZIP(const char *szArchiveName,const char *szFileName,const char *szOutputFileName);
BOOL ExtractFileFromRAR(const char *szArchiveName,const char *szFileName,const char *szOutputFileName);
BOOL ExtractFileFromACE(const char *szArchiveName,const char *szFileName,const char *szOutputFileName);

#endif