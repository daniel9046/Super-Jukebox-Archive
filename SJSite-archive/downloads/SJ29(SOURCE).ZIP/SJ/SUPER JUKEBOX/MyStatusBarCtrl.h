#if !defined(AFX_MYSTATUSBARCTRL_H__CEA7A122_7FFE_11D4_8925_009027C5CF93__INCLUDED_)
#define AFX_MYSTATUSBARCTRL_H__CEA7A122_7FFE_11D4_8925_009027C5CF93__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// MyStatusBarCtrl.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CMyStatusBarCtrl window

class CMyStatusBarCtrl : public CStatusBarCtrl
{
// Construction
public:
	CMyStatusBarCtrl();

// Attributes
public:

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMyStatusBarCtrl)
	//}}AFX_VIRTUAL

// Implementation
public:
	int m_nLen;
	BOOL bCaptured;
	virtual ~CMyStatusBarCtrl();

	// Generated message map functions
protected:
	//{{AFX_MSG(CMyStatusBarCtrl)
	afx_msg void OnMouseMove(UINT nFlags, CPoint point);
	//}}AFX_MSG

	DECLARE_MESSAGE_MAP()
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_MYSTATUSBARCTRL_H__CEA7A122_7FFE_11D4_8925_009027C5CF93__INCLUDED_)
