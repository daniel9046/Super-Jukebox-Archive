// PropPage4.cpp : implementation file
//

#include "stdafx.h"
#include "super jukebox.h"
#include "PropPage4.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CPropPage4 property page

IMPLEMENT_DYNCREATE(CPropPage4, CPropertyPage)

CPropPage4::CPropPage4() : CPropertyPage(CPropPage4::IDD)
{
	//{{AFX_DATA_INIT(CPropPage4)
	m_nFreq = -1;
	m_nBits = -1;
	m_nChan = -1;
	m_iPreamp = 0;
	m_nInterpolation = -1;
	m_nAPR = -1;
	m_bUseOldBRE = FALSE;
	m_bUseLPF = FALSE;
	m_nThreadPriority = -1;
	m_nBufferLength = 0;
	//}}AFX_DATA_INIT
}

CPropPage4::~CPropPage4()
{
}

void CPropPage4::DoDataExchange(CDataExchange* pDX)
{
	CPropertyPage::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CPropPage4)
	DDX_Control(pDX, IDC_SPIN_BUFFER_LENGTH, m_ctlSpinBufferLength);
	DDX_Control(pDX, IDC_SPIN_PREAMP, m_ctlSpinPreamp);
	DDX_CBIndex(pDX, IDC_COMBO_SAMPLE_RATE, m_nFreq);
	DDX_Radio(pDX, IDC_RADIO_8BIT, m_nBits);
	DDX_Radio(pDX, IDC_RADIO_MONO, m_nChan);
	DDX_Text(pDX, IDC_EDIT_PREAMP, m_iPreamp);
	DDV_MinMaxInt(pDX, m_iPreamp, 1, 100);
	DDX_CBIndex(pDX, IDC_COMBO_INTERPOLATION, m_nInterpolation);
	DDX_Radio(pDX, IDC_RADIO_APR_OFF, m_nAPR);
	DDX_Check(pDX, IDC_CHECK_USE_OLD_SCHOOL_BRE, m_bUseOldBRE);
	DDX_Check(pDX, IDC_CHECK_USE_LOW_PASS_FILTER, m_bUseLPF);
	DDX_CBIndex(pDX, IDC_COMBO_PRIORITY_LEVEL, m_nThreadPriority);
	DDX_Text(pDX, IDC_EDIT_BUFFER_LENGTH, m_nBufferLength);
	DDV_MinMaxUInt(pDX, m_nBufferLength, 100, 10000);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CPropPage4, CPropertyPage)
	//{{AFX_MSG_MAP(CPropPage4)
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CPropPage4 message handlers

CPropPage4 & CPropPage4::operator =(const CPropPage4 &obj)
{
	if(this==&obj)
		return *this;
	m_bUseLPF=obj.m_bUseLPF;
	m_bUseOldBRE=obj.m_bUseOldBRE;
	m_iPreamp=obj.m_iPreamp;
	m_nAPR=obj.m_nAPR;
	m_nBits=obj.m_nBits;
	m_nChan=obj.m_nChan;
	m_nFreq=obj.m_nFreq;
	m_nInterpolation=obj.m_nInterpolation;
	m_nBufferLength=obj.m_nBufferLength;
	m_nThreadPriority=obj.m_nThreadPriority;
	return *this;
}

BOOL CPropPage4::OnInitDialog() 
{
	CPropertyPage::OnInitDialog();
	
	// TODO: Add extra initialization here
	m_ctlSpinPreamp.SetRange(1,100);
	m_ctlSpinBufferLength.SetRange(100,10000);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}
