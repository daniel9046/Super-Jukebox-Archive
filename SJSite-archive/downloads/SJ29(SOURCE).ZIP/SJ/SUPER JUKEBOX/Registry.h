// Registry.h: interface for the CRegistry class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_REGISTRY_H__9BD52540_529C_11D4_8925_009027C572AB__INCLUDED_)
#define AFX_REGISTRY_H__9BD52540_529C_11D4_8925_009027C572AB__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

class CRegistry  
{
public:
	BOOL bActiveWallpaper;
	BOOL bShowControls;
	DWORD dwSpectrumSize;
	DWORD dwButtonStyle;
	BOOL bShowTitleBar;
	DWORD dwVisRate;
	DWORD dwVisMode;
	DWORD dwBufferLength;
	DWORD dwLayoutScheme;
	BOOL bShowVisWindow;
	DWORD dwActiveChannels;
	BOOL bAutoSizeColumns;
	DWORD dwSampleRate;
	DWORD dwSampleSize;
	DWORD dwChannels;
	DWORD dwInterpolation;
	DWORD dwPreamp;
	DWORD dwPriorityClass;
	DWORD dwMixingThreadPriority;
	DWORD dwVisThreadPriority;
	BOOL bFullRowSelect;
	BOOL bShowGridlines;
	BOOL bUseID666;
	BOOL bAPR;
	BOOL bUseLPF;
	BOOL bUseOldBRE;
	BOOL bAutoLoadPlaylist;
	TCHAR szLastDirectory[MAX_PATH];
	TCHAR szLastPlaylist[MAX_PATH];
	ColumnInfo stColumnsInfo[NUMBER_OF_COLUMNS];
	WINDOWPLACEMENT wp;
	RECT List0Rect,List1Rect,ButtonsRect;

	CRegistry();
	virtual ~CRegistry();
	BOOL Load();
	BOOL Save();

};

#endif // !defined(AFX_REGISTRY_H__9BD52540_529C_11D4_8925_009027C572AB__INCLUDED_)
