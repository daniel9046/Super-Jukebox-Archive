// MyListCtrl.cpp : implementation file
//

#include "stdafx.h"
#include "super jukebox.h"
#include "MyListCtrl.h"
#include "Msg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

Message msgs;

/////////////////////////////////////////////////////////////////////////////
// CMyListCtrl

CMyListCtrl::CMyListCtrl()
{
	iXPos=iYPos=iWidth=iHeight=-1;
	AdjustedBkGndBmp=NULL;
	AdjustedBkGndDC=pParentDC=NULL;
	bPass=FALSE;
}

CMyListCtrl::~CMyListCtrl()
{
}


BEGIN_MESSAGE_MAP(CMyListCtrl, CListCtrl)
	//{{AFX_MSG_MAP(CMyListCtrl)
	ON_WM_ERASEBKGND()
	ON_WM_MOVE()
	ON_WM_SIZE()
	ON_WM_VSCROLL()
	ON_WM_HSCROLL()
	ON_WM_CREATE()
	ON_WM_SHOWWINDOW()
	ON_WM_WINDOWPOSCHANGED()
	ON_WM_PAINT()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMyListCtrl message handlers

BOOL CMyListCtrl::OnEraseBkgnd(CDC* pDC) 
{
	// TODO: Add your message handler code here and/or call default
	BOOL bRes=TRUE;
	bPass=TRUE;
	if(iXPos==-1||iYPos==-1||iWidth==-1||iHeight==-1||pParentDC==NULL)
	{
		bRes=CListCtrl::OnEraseBkgnd(pDC);
	}
	else if(AdjustedBkGndDC)
	{
		BitBlt(pDC->GetSafeHdc(),0,0,iWidth,iHeight,AdjustedBkGndDC,0,0,SRCCOPY);
	}
	bPass=FALSE;
	return bRes;	
}

void CMyListCtrl::OnMove(int x, int y) 
{
	CListCtrl::OnMove(x, y);
	
	// TODO: Add your message handler code here
	iXPos=x;
	iYPos=y;	
}

void CMyListCtrl::OnSize(UINT nType, int cx, int cy) 
{
	CListCtrl::OnSize(nType, cx, cy);
	
	// TODO: Add your message handler code here
	iWidth=cx;
	iHeight=cy;
}

void CMyListCtrl::OnHScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	SIZE size={0},ListViewSize={0};
	RECT rect={0};

	GetClientRect(&rect);
	ListViewSize.cx=rect.right-rect.left;
	ListViewSize.cy=rect.bottom-rect.top;

	switch(nSBCode)
	{
	case SB_LEFT:
		break;
	case SB_RIGHT:
		break;
	case SB_LINELEFT:
		size.cx=-14;
		break;
	case SB_LINERIGHT:
		size.cx=14;
		break;
	case SB_PAGELEFT:
		size.cx=-ListViewSize.cx;
		break;
	case SB_PAGERIGHT:
		size.cx=ListViewSize.cx;
		break;
	case SB_THUMBPOSITION:
		size.cx=nPos;
		size.cx-=GetScrollPos(SB_HORZ);
		break;
	case SB_THUMBTRACK:
		size.cx=nPos;
		size.cx-=GetScrollPos(SB_HORZ);
		break;
	}
	if(size.cx||size.cy)
		Scroll(size);
	//EnsureVisible(64,FALSE);
}

void CMyListCtrl::OnVScroll(UINT nSBCode, UINT nPos, CScrollBar* pScrollBar) 
{
	// TODO: Add your message handler code here and/or call default
	SIZE size={0},ListViewSize={0};
	RECT rect={0};
	UINT RowHeight;

	GetItemRect(0,&rect,LVIR_BOUNDS);
	RowHeight=rect.bottom-rect.top;

	GetClientRect(&rect);
	ListViewSize.cx=rect.right-rect.left;
	ListViewSize.cy=rect.bottom-rect.top;

	switch(nSBCode)
	{
	case SB_TOP:
		break;
	case SB_BOTTOM:
		break;
	case SB_LINEUP:
		size.cy=-14;
		break;
	case SB_LINEDOWN:
		size.cy=14;
		break;
	case SB_PAGEUP:
		size.cy=-ListViewSize.cy;
		break;
	case SB_PAGEDOWN:
		size.cy=ListViewSize.cy;
		break;
	case SB_THUMBPOSITION:
		size.cy=nPos;
		size.cy-=GetScrollPos(SB_VERT);
		size.cy*=RowHeight;
		break;
	case SB_THUMBTRACK:
		size.cy=nPos;
		size.cy-=GetScrollPos(SB_VERT);
		size.cy*=RowHeight;
		break;
	}
	Scroll(size);
	//EnsureVisible(64,FALSE);
}

LRESULT CMyListCtrl::WindowProc(UINT message, WPARAM wParam, LPARAM lParam) 
{
	// TODO: Add your specialized code here and/or call the base class
	AddMessage(&msgs,message,wParam,lParam);

	switch(message)
	{
	case LVM_SCROLL:
		return OnScroll(wParam,lParam);
		break;
	case LVM_ENSUREVISIBLE:
		return TRUE;
		break;
	}

	return CListCtrl::WindowProc(message, wParam, lParam);
}

BOOL CMyListCtrl::OnScroll(int dx, int dy)
{
	RECT rect={0};
	SIZE ListSize={0},ListViewSize={0};
	UINT RowHeight;

	GetItemRect(0,&rect,LVIR_BOUNDS);
	RowHeight=rect.bottom-rect.top;
	ListSize.cy=RowHeight*(GetItemCount()+1);

	CHeaderCtrl* pHdrCtrl=GetHeaderCtrl();
	pHdrCtrl->GetItemRect(pHdrCtrl->GetItemCount()-1,&rect);
	ListSize.cx=rect.right;

	GetClientRect(&rect);
	ListViewSize.cx=rect.right-rect.left;
	ListViewSize.cy=rect.bottom-rect.top;

	pHdrCtrl->GetWindowRect(&rect);
	ListViewSize.cy-=rect.bottom-rect.top;

	int *pWnd=(int*)GetWindowLong(this->GetSafeHwnd(),0);

	int OldXPos=pWnd[81];
	pWnd[81]+=dx;

	int OldYPos=pWnd[82];
	pWnd[82]+=dy;

	if(pWnd[81]>ListSize.cx-ListViewSize.cx)
		pWnd[81]=ListSize.cx-ListViewSize.cx;
	if(pWnd[81]<0)pWnd[81]=0;

	if(pWnd[82]>ListSize.cy-ListViewSize.cy)
		pWnd[82]=ListSize.cy-ListViewSize.cy;
	if(pWnd[82]<0)pWnd[82]=0;

	if(OldXPos!=pWnd[81]||OldYPos!=pWnd[82])
	{
		if(OldXPos!=pWnd[81])
			SetScrollPos(SB_HORZ,pWnd[81]);
		if(OldYPos!=pWnd[82])
			SetScrollPos(SB_VERT,pWnd[82]/RowHeight);
		InvalidateRect(NULL);
		ScreenToClient(&rect);
		rect.left=-pWnd[81];
		pHdrCtrl->MoveWindow(&rect);
		UpdateWindow();
	}

	CString str;
	str.Format("%d %d %d %d",pWnd[81],pWnd[82],ListSize.cy,ListViewSize.cy);
	m_StatusBar->SetText(str,0,0);

	return TRUE;
}

int CMyListCtrl::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CListCtrl::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Add your specialized creation code here
	iXPos=lpCreateStruct->x;
	iYPos=lpCreateStruct->y;
	iWidth=lpCreateStruct->cx;
	iHeight=lpCreateStruct->cy;
	
	return 0;
}

void CMyListCtrl::OnShowWindow(BOOL bShow, UINT nStatus) 
{
	CListCtrl::OnShowWindow(bShow, nStatus);
	
	// TODO: Add your message handler code here
	
}

void CMyListCtrl::OnWindowPosChanged(WINDOWPOS FAR* lpwndpos) 
{
	CListCtrl::OnWindowPosChanged(lpwndpos);
	
	// TODO: Add your message handler code here
	//iXPos=lpwndpos->x;
	//iYPos=lpwndpos->y;
	//iWidth=lpwndpos->cx;
	//iHeight=lpwndpos->cy;

	if(!pParentDC)return;

	if(AdjustedBkGndDC)DeleteDC(AdjustedBkGndDC);
	if(AdjustedBkGndBmp)DeleteObject(AdjustedBkGndBmp);

	AdjustedBkGndDC=CreateCompatibleDC(GetDC()->GetSafeHdc());
	AdjustedBkGndBmp=CreateCompatibleBitmap(GetDC()->GetSafeHdc(),iWidth,iHeight);
	SelectObject(AdjustedBkGndDC,AdjustedBkGndBmp);

	HBRUSH brush=CreateSolidBrush(RGB(255,192,50));
	RECT rect;
	rect.left=0;rect.top=0;
	rect.right=iWidth;rect.bottom=iHeight;
	FillRect(AdjustedBkGndDC,&rect,brush);
	BLENDFUNCTION bf;
	bf.BlendOp=AC_SRC_OVER;
	bf.BlendFlags=0;
	bf.SourceConstantAlpha=128;
	bf.AlphaFormat=0;
	if(!AlphaBlend(AdjustedBkGndDC,0,0,iWidth,iHeight,pParentDC,iXPos,iYPos,iWidth,iHeight,bf))
	{
		MessageBox("The AlphaBlend function failed, tell Marius about this.");
	}
	DeleteObject(brush);
}

void CMyListCtrl::OnPaint() 
{
	//CPaintDC dc(this); // device context for painting
	
	// TODO: Add your message handler code here
	//CDC *pDC=GetDC();
	//CBitmap SpareBmp;
	//SpareBmp.CreateCompatibleBitmap(pDC,iWidth,iHeight);
	//CBitmap *pOldBmp=pDC->SelectObject(&SpareBmp);
	CListCtrl::OnPaint();
	//pDC->SelectObject(pOldBmp);
	//ReleaseDC(pDC);
	//SpareBmp.DeleteObject();
	
	// Do not call CListCtrl::OnPaint() for painting messages
}
