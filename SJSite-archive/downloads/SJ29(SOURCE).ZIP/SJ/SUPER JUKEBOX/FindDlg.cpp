// FindDlg.cpp : implementation file
//

#include "stdafx.h"
#include "super jukebox.h"
#include "FindDlg.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CFindDlg dialog


CFindDlg::CFindDlg(CWnd* pParent /*=NULL*/)
	: CDialog(CFindDlg::IDD, pParent)
{
	//{{AFX_DATA_INIT(CFindDlg)
	m_iDirection = 1;
	m_iSearchColumn = 0;
	m_bWholeWord = FALSE;
	m_bCase = FALSE;
	m_strFind = _T("");
	//}}AFX_DATA_INIT
}


void CFindDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CFindDlg)
	DDX_Control(pDX, IDC_EDIT_FIND_WHAT, m_edFind);
	DDX_Radio(pDX, IDC_RADIO_FIND_UP, m_iDirection);
	DDX_CBIndex(pDX, IDC_COMBO_SEARCH_COLUMN, m_iSearchColumn);
	DDX_Check(pDX, IDC_CHECK_MATCH_WHOLE_WORD_ONLY, m_bWholeWord);
	DDX_Check(pDX, IDC_CHECK_MATCH_CASE, m_bCase);
	DDX_Text(pDX, IDC_EDIT_FIND_WHAT, m_strFind);
	//}}AFX_DATA_MAP
}


BEGIN_MESSAGE_MAP(CFindDlg, CDialog)
	//{{AFX_MSG_MAP(CFindDlg)
	ON_EN_CHANGE(IDC_EDIT_FIND_WHAT, OnChangeEdit5_1)
	ON_WM_HELPINFO()
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CFindDlg message handlers

BOOL CFindDlg::OnInitDialog() 
{
	CDialog::OnInitDialog();
	
	// TODO: Add extra initialization here
	char szBuffer[1000];
	m_edFind.GetWindowText(szBuffer,1000);
	if(!strlen(szBuffer))
		GetDlgItem(IDOK)->EnableWindow(FALSE);
	else
		GetDlgItem(IDOK)->EnableWindow(TRUE);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

void CFindDlg::OnChangeEdit5_1() 
{
	// TODO: If this is a RICHEDIT control, the control will not
	// send this notification unless you override the CDialog::OnInitDialog()
	// function and call CRichEditCtrl().SetEventMask()
	// with the ENM_CHANGE flag ORed into the mask.
	
	// TODO: Add your control notification handler code here
	char szBuffer[1000];
	m_edFind.GetWindowText(szBuffer,1000);
	if(!strlen(szBuffer))
		GetDlgItem(IDOK)->EnableWindow(FALSE);
	else
		GetDlgItem(IDOK)->EnableWindow(TRUE);
}

BOOL CFindDlg::OnHelpInfo(HELPINFO* pHelpInfo) 
{
	// TODO: Add your message handler code here and/or call default
	if(pHelpInfo->iContextType==HELPINFO_WINDOW)
	{
		WinHelp(pHelpInfo->dwContextId,HELP_CONTEXTPOPUP);
	}
	
	return CDialog::OnHelpInfo(pHelpInfo);
}