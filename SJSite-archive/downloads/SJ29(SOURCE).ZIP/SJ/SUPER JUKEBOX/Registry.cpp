// Registry.cpp: implementation of the CRegistry class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "super jukebox.h"
#include "Globals.h"
#include <direct.h>

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CRegistry::CRegistry()
{
	bActiveWallpaper=0;
	bShowControls=TRUE;
	dwSpectrumSize=50;
	dwButtonStyle=0;
	bShowTitleBar=TRUE;
	dwVisRate=30;
	dwVisMode=0;
	dwBufferLength=1000;
	dwLayoutScheme=1;
	dwActiveChannels=0xFF;
	dwSampleRate=44100;
	dwSampleSize=16;
	dwChannels=2;
	dwInterpolation=0;
	dwPreamp=50;
	dwPriorityClass=NORMAL_PRIORITY_CLASS;
	dwMixingThreadPriority=THREAD_PRIORITY_NORMAL;
	dwVisThreadPriority=THREAD_PRIORITY_NORMAL;
	bAPR=FALSE;
	bUseLPF=FALSE;
	bUseOldBRE=FALSE;
	bUseID666=FALSE;
	bFullRowSelect=TRUE;
	bShowGridlines=FALSE;
	bAutoLoadPlaylist=FALSE;
	bAutoSizeColumns=TRUE;
	bShowVisWindow=TRUE;
	szLastDirectory[0]='\0';
	szLastPlaylist[0]='\0';

	wp.length=sizeof(WINDOWPLACEMENT);
	wp.flags=0;
	wp.showCmd=SW_SHOWNORMAL;
	wp.ptMaxPosition.x=-1;
	wp.ptMaxPosition.y=-1;
	wp.ptMinPosition.x=-1;
	wp.ptMinPosition.y=-1;
	wp.rcNormalPosition.left=20;
	wp.rcNormalPosition.right=GetSystemMetrics(SM_CXSCREEN)-20;
	UINT uHeight=415+GetSystemMetrics(SM_CYSIZEFRAME)*2+GetSystemMetrics(SM_CYCAPTION)+GetSystemMetrics(SM_CYMENU);
	wp.rcNormalPosition.top=(GetSystemMetrics(SM_CYSCREEN)-uHeight)/2;
	wp.rcNormalPosition.bottom=wp.rcNormalPosition.top+uHeight;

	int iWidth=(wp.rcNormalPosition.right-wp.rcNormalPosition.left)-GetSystemMetrics(SM_CXSIZEFRAME)*2;

	ButtonsRect.left=(iWidth-75)/2;
	ButtonsRect.top=11;
	ButtonsRect.right=ButtonsRect.left+75;
	ButtonsRect.bottom=ButtonsRect.top+203;
	List0Rect.left=11;
	List0Rect.top=ButtonsRect.top;
	List0Rect.right=ButtonsRect.left-11;
	List0Rect.bottom=ButtonsRect.bottom;
	List1Rect.left=ButtonsRect.right+11;
	List1Rect.top=ButtonsRect.top;
	List1Rect.right=iWidth-11;
	List1Rect.bottom=ButtonsRect.bottom;

	memcpy(stColumnsInfo,::stColumnsInfo,sizeof(ColumnInfo)*NUMBER_OF_COLUMNS);
}

CRegistry::~CRegistry()
{

}

BOOL CRegistry::Load()
{
	HKEY hKey;
	DWORD dwSize;

	if(RegOpenKeyEx(HKEY_LOCAL_MACHINE,"SOFTWARE\\Marius Fodor\\Super Jukebox",0,KEY_ALL_ACCESS,&hKey)!=ERROR_SUCCESS)
		return FALSE;
	dwSize=sizeof(bShowControls);
	RegQueryValueEx(hKey,"Show controls",NULL,NULL,(LPBYTE)&bShowControls,&dwSize);
	dwSize=sizeof(dwSpectrumSize);
	RegQueryValueEx(hKey,"Spectrum size",NULL,NULL,(LPBYTE)&dwSpectrumSize,&dwSize);
	dwSize=sizeof(dwButtonStyle);
	RegQueryValueEx(hKey,"Button style",NULL,NULL,(LPBYTE)&dwButtonStyle,&dwSize);
	dwSize=sizeof(bShowTitleBar);
	RegQueryValueEx(hKey,"Show title bar",NULL,NULL,(LPBYTE)&bShowTitleBar,&dwSize);
	dwSize=sizeof(dwVisRate);
	RegQueryValueEx(hKey,"Visualization rate",NULL,NULL,(LPBYTE)&dwVisRate,&dwSize);
	dwSize=sizeof(dwVisMode);
	RegQueryValueEx(hKey,"Visualization mode",NULL,NULL,(LPBYTE)&dwVisMode,&dwSize);
	dwSize=sizeof(dwBufferLength);
	RegQueryValueEx(hKey,"Buffer length",NULL,NULL,(LPBYTE)&dwBufferLength,&dwSize);
	dwSize=sizeof(dwMixingThreadPriority);
	RegQueryValueEx(hKey,"Mixing thread priority",NULL,NULL,(LPBYTE)&dwMixingThreadPriority,&dwSize);
	dwSize=sizeof(dwVisThreadPriority);
	RegQueryValueEx(hKey,"Visualization thread priority",NULL,NULL,(LPBYTE)&dwVisThreadPriority,&dwSize);
	dwSize=sizeof(dwLayoutScheme);
	RegQueryValueEx(hKey,"Layout scheme",NULL,NULL,(LPBYTE)&dwLayoutScheme,&dwSize);
	dwSize=sizeof(dwActiveChannels);
	RegQueryValueEx(hKey,"Active channels",NULL,NULL,(LPBYTE)&dwActiveChannels,&dwSize);
	dwSize=sizeof(dwSampleRate);
	RegQueryValueEx(hKey,"Sample rate",NULL,NULL,(LPBYTE)&dwSampleRate,&dwSize);
	dwSize=sizeof(dwSampleSize);
	RegQueryValueEx(hKey,"Sample size",NULL,NULL,(LPBYTE)&dwSampleSize,&dwSize);
	dwSize=sizeof(dwChannels);
	RegQueryValueEx(hKey,"Channels",NULL,NULL,(LPBYTE)&dwChannels,&dwSize);
	dwSize=sizeof(dwInterpolation);
	RegQueryValueEx(hKey,"Interpolation",NULL,NULL,(LPBYTE)&dwInterpolation,&dwSize);
	dwSize=sizeof(dwPreamp);
	RegQueryValueEx(hKey,"Preamp",NULL,NULL,(LPBYTE)&dwPreamp,&dwSize);
	dwSize=sizeof(dwPriorityClass);
	RegQueryValueEx(hKey,"Priority class",NULL,NULL,(LPBYTE)&dwPriorityClass,&dwSize);
	dwSize=sizeof(bUseID666);
	RegQueryValueEx(hKey,"Use ID666",NULL,NULL,(LPBYTE)&bUseID666,&dwSize);
	dwSize=sizeof(bFullRowSelect);
	RegQueryValueEx(hKey,"Full row select",NULL,NULL,(LPBYTE)&bFullRowSelect,&dwSize);
	dwSize=sizeof(bShowGridlines);
	RegQueryValueEx(hKey,"Show gridlines",NULL,NULL,(LPBYTE)&bShowGridlines,&dwSize);
	dwSize=sizeof(bAutoLoadPlaylist);
	RegQueryValueEx(hKey,"Auto-load last playlist",NULL,NULL,(LPBYTE)&bAutoLoadPlaylist,&dwSize);
	dwSize=sizeof(bAutoSizeColumns);
	RegQueryValueEx(hKey,"Auto-size playlist columns",NULL,NULL,(LPBYTE)&bAutoSizeColumns,&dwSize);
	dwSize=sizeof(bShowVisWindow);
	RegQueryValueEx(hKey,"Show visualization window",NULL,NULL,(LPBYTE)&bShowVisWindow,&dwSize);
	dwSize=sizeof(bAPR);
	RegQueryValueEx(hKey,"APR",NULL,NULL,(LPBYTE)&bAPR,&dwSize);
	dwSize=sizeof(bUseLPF);
	RegQueryValueEx(hKey,"Use low-pass filter",NULL,NULL,(LPBYTE)&bUseLPF,&dwSize);
	dwSize=sizeof(bUseOldBRE);
	RegQueryValueEx(hKey,"Use old school BRE",NULL,NULL,(LPBYTE)&bUseOldBRE,&dwSize);
	dwSize=sizeof(szLastDirectory);
	RegQueryValueEx(hKey,"Last directory",NULL,NULL,(LPBYTE)szLastDirectory,&dwSize);
	dwSize=sizeof(szLastPlaylist);
	RegQueryValueEx(hKey,"Last playlist",NULL,NULL,(LPBYTE)szLastPlaylist,&dwSize);
	dwSize=sizeof(stColumnsInfo);
	RegQueryValueEx(hKey,"Columns info",NULL,NULL,(LPBYTE)&stColumnsInfo,&dwSize);
	dwSize=sizeof(wp);
	RegQueryValueEx(hKey,"Window placement",NULL,NULL,(LPBYTE)&wp,&dwSize);
	dwSize=sizeof(List0Rect);
	RegQueryValueEx(hKey,"File list rect",NULL,NULL,(LPBYTE)&List0Rect,&dwSize);
	dwSize=sizeof(List1Rect);
	RegQueryValueEx(hKey,"Play list rect",NULL,NULL,(LPBYTE)&List1Rect,&dwSize);
	dwSize=sizeof(ButtonsRect);
	RegQueryValueEx(hKey,"Buttons rect",NULL,NULL,(LPBYTE)&ButtonsRect,&dwSize);
	RegCloseKey(hKey);

	if(dwPreamp<1)dwPreamp=1;
	else if(dwPreamp>MaxAmp)dwPreamp=MaxAmp;

	return TRUE;
}

BOOL CRegistry::Save()
{
	HKEY hKey;

	if(RegCreateKeyEx(HKEY_LOCAL_MACHINE,"SOFTWARE\\Marius Fodor\\Super Jukebox",0,NULL,REG_OPTION_NON_VOLATILE,KEY_ALL_ACCESS,NULL,&hKey,NULL)!=ERROR_SUCCESS)
		return FALSE;
	RegSetValueEx(hKey,"Show controls",0,REG_BINARY,(LPBYTE)&bShowControls,sizeof(bShowControls));
	RegSetValueEx(hKey,"Spectrum size",0,REG_BINARY,(LPBYTE)&dwSpectrumSize,sizeof(dwSpectrumSize));
	RegSetValueEx(hKey,"Button style",0,REG_BINARY,(LPBYTE)&dwButtonStyle,sizeof(dwButtonStyle));
	RegSetValueEx(hKey,"Show title bar",0,REG_BINARY,(LPBYTE)&bShowTitleBar,sizeof(bShowTitleBar));
	RegSetValueEx(hKey,"Visualization rate",0,REG_BINARY,(LPBYTE)&dwVisRate,sizeof(dwVisRate));
	RegSetValueEx(hKey,"Visualization mode",0,REG_BINARY,(LPBYTE)&dwVisMode,sizeof(dwVisMode));
	RegSetValueEx(hKey,"Buffer length",0,REG_BINARY,(LPBYTE)&dwBufferLength,sizeof(dwBufferLength));
	RegSetValueEx(hKey,"Mixing thread priority",0,REG_BINARY,(LPBYTE)&dwMixingThreadPriority,sizeof(dwMixingThreadPriority));
	RegSetValueEx(hKey,"Visualization thread priority",0,REG_BINARY,(LPBYTE)&dwVisThreadPriority,sizeof(dwVisThreadPriority));
	RegSetValueEx(hKey,"Layout scheme",0,REG_BINARY,(LPBYTE)&dwLayoutScheme,sizeof(dwLayoutScheme));
	RegSetValueEx(hKey,"Active channels",0,REG_BINARY,(LPBYTE)&dwActiveChannels,sizeof(dwActiveChannels));
	RegSetValueEx(hKey,"Sample rate",0,REG_BINARY,(LPBYTE)&dwSampleRate,sizeof(dwSampleRate));
	RegSetValueEx(hKey,"Sample size",0,REG_BINARY,(LPBYTE)&dwSampleSize,sizeof(dwSampleSize));
	RegSetValueEx(hKey,"Channels",0,REG_BINARY,(LPBYTE)&dwChannels,sizeof(dwChannels));
	RegSetValueEx(hKey,"Interpolation",0,REG_BINARY,(LPBYTE)&dwInterpolation,sizeof(dwInterpolation));
	RegSetValueEx(hKey,"Preamp",0,REG_BINARY,(LPBYTE)&dwPreamp,sizeof(dwPreamp));
	RegSetValueEx(hKey,"Priority class",0,REG_BINARY,(LPBYTE)&dwPriorityClass,sizeof(dwPriorityClass));
	RegSetValueEx(hKey,"Use ID666",0,REG_BINARY,(LPBYTE)&bUseID666,sizeof(bUseID666));
	RegSetValueEx(hKey,"Full row select",0,REG_BINARY,(LPBYTE)&bFullRowSelect,sizeof(bFullRowSelect));
	RegSetValueEx(hKey,"Show gridlines",0,REG_BINARY,(LPBYTE)&bShowGridlines,sizeof(bShowGridlines));
	RegSetValueEx(hKey,"Auto-load last playlist",0,REG_BINARY,(LPBYTE)&bAutoLoadPlaylist,sizeof(bAutoLoadPlaylist));
	RegSetValueEx(hKey,"Auto-size playlist columns",0,REG_BINARY,(LPBYTE)&bAutoSizeColumns,sizeof(bAutoSizeColumns));
	RegSetValueEx(hKey,"Show visualization window",0,REG_BINARY,(LPBYTE)&bShowVisWindow,sizeof(bShowVisWindow));
	RegSetValueEx(hKey,"APR",0,REG_BINARY,(LPBYTE)&bAPR,sizeof(bAPR));
	RegSetValueEx(hKey,"Use low-pass filter",0,REG_BINARY,(LPBYTE)&bUseLPF,sizeof(bUseLPF));
	RegSetValueEx(hKey,"Use old school BRE",0,REG_BINARY,(LPBYTE)&bUseOldBRE,sizeof(bUseOldBRE));
	RegSetValueEx(hKey,"Last directory",0,REG_SZ,(LPBYTE)szLastDirectory,sizeof(szLastDirectory));
	RegSetValueEx(hKey,"Last playlist",0,REG_SZ,(LPBYTE)szLastPlaylist,sizeof(szLastPlaylist));
	RegSetValueEx(hKey,"Columns info",0,REG_BINARY,(LPBYTE)&stColumnsInfo,sizeof(stColumnsInfo));
	RegSetValueEx(hKey,"Window placement",0,REG_BINARY,(LPBYTE)&wp,sizeof(wp));
	RegSetValueEx(hKey,"File list rect",0,REG_BINARY,(LPBYTE)&List0Rect,sizeof(List0Rect));
	RegSetValueEx(hKey,"Play list rect",0,REG_BINARY,(LPBYTE)&List1Rect,sizeof(List1Rect));
	RegSetValueEx(hKey,"Buttons rect",0,REG_BINARY,(LPBYTE)&ButtonsRect,sizeof(ButtonsRect));
	RegCloseKey(hKey);

	return TRUE;
}