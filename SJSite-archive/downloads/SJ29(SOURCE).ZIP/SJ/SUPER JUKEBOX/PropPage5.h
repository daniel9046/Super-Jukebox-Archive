#if !defined(AFX_PROPPAGE5_H__96547501_6E0B_11D4_8925_009027C5CF93__INCLUDED_)
#define AFX_PROPPAGE5_H__96547501_6E0B_11D4_8925_009027C5CF93__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// PropPage5.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CPropPage5 dialog

class CPropPage5 : public CPropertyPage
{
	DECLARE_DYNCREATE(CPropPage5)

// Construction
public:
	CPropPage5();
	~CPropPage5();
	CPropPage5 & operator =(const CPropPage5 &dlg);

// Dialog Data
	//{{AFX_DATA(CPropPage5)
	enum { IDD = IDD_DIALOG7 };
		// NOTE - ClassWizard will add data members here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	int		m_nPriority;
	BOOL	m_bUseID666;
	BOOL	m_bAutoLoadPlaylist;
	BOOL	m_bAutoSizeColumns;
	//}}AFX_DATA


// Overrides
	// ClassWizard generate virtual function overrides
	//{{AFX_VIRTUAL(CPropPage5)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:
	// Generated message map functions
	//{{AFX_MSG(CPropPage5)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()

};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_PROPPAGE5_H__96547501_6E0B_11D4_8925_009027C5CF93__INCLUDED_)
