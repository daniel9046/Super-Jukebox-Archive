// Super Jukebox.h : main header file for the SUPER JUKEBOX application
//

#if !defined(AFX_SUPERJUKEBOX_H__41579E48_5D7E_11D3_9105_444553540001__INCLUDED_)
#define AFX_SUPERJUKEBOX_H__41579E48_5D7E_11D3_9105_444553540001__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#define	MaxAmp 100                         //Maximum pre-amp level

#include "resource.h"

/////////////////////////////////////////////////////////////////////////////
// CSuperJukeboxApp:
// See Super Jukebox.cpp for the implementation of this class
//

class CSuperJukeboxApp : public CWinApp
{
public:
	HACCEL hAccel;
	HRESULT GetShortcutInfo(LPCSTR lpszPathLink, LPSTR lpszPathObj, LPSTR lpszDesc);
	HMODULE hLibrary1;
	HMODULE hLibrary0;
	CSuperJukeboxApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CSuperJukeboxApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation

	//{{AFX_MSG(CSuperJukeboxApp)
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
protected:
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_SUPERJUKEBOX_H__41579E48_5D7E_11D3_9105_444553540001__INCLUDED_)
