// ActiveWallpaper.h: interface for the CActiveWallpaper class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_ACTIVEWALLPAPER_H__104A3743_7F1F_11D4_8925_009027C5CF93__INCLUDED_)
#define AFX_ACTIVEWALLPAPER_H__104A3743_7F1F_11D4_8925_009027C5CF93__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "..\SNESAmp\SNESAmp.h"

typedef int (*AW1_SETPARAMETERSPROC)(int,int,int);
typedef int (*AW1_RENDERPROC)(HDC,VIS_PARAMS*);
typedef int (*AW1_STARTPROC)(HDC);
typedef int (*AW1_STOPPROC)(HDC);

class CActiveWallpaper  
{
public:
	static CString strSpare;
	int LoadPlugin(LPCTSTR lpszDllName);
	int UnloadPlugin();
	int SetParameters(HWND hWndParent,int nRate,int nWidth,int nHeight);
	static int Render(HDC hDCDest,VIS_PARAMS *vp);
	int Start();
	int Stop(int Pause);
	static CStatusBarCtrl *m_StatusBar;
	CActiveWallpaper();
	virtual ~CActiveWallpaper();

private:
	BOOL bPaused;
	HINSTANCE hPluginLib;
	static BOOL bRunning,bLibLoaded;
	AW1_SETPARAMETERSPROC pAW1_SetParameters;
	static AW1_RENDERPROC pAW1_Render;
	AW1_STARTPROC pAW1_Start;
	AW1_STOPPROC pAW1_Stop;
	static TCHAR szDllName[MAX_PATH];
	static int nWidth,nHeight,nRate;
	static DWORD WINAPI Thread(LPVOID lpParameter);
	static HWND hWndParent;
	static BOOL bKillThread;
	HANDLE THand;
};

#endif // !defined(AFX_ACTIVEWALLPAPER_H__104A3743_7F1F_11D4_8925_009027C5CF93__INCLUDED_)
