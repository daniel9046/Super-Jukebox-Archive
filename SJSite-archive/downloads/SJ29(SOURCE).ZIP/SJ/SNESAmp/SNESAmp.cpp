#include <windows.h>
#include <stdio.h>
#include "SNESAmp.h"
#include "out_wave.h"
#include "ID666.h"
#include "in_snes.h"
#include "dsp.h"

BOOL bSetSongLength=FALSE;
INT Song_ms,Fade_ms;
BOOL bSetThreadPriority=FALSE;
INT nThreadPriority=THREAD_PRIORITY_NORMAL;

LPCTSTR lpszDllName="SNESAmp.DLL";
BOOL bSNESAmp_Loaded,bSNESAmp_Playing;

SNESAMP_CONFIG Config=
{
	44100,
	16,
	2,
	0,
	0,
	0,
	1,
	0,
	35,
	7872,
	120000,
	8000,
	1000,
	30,
};

BOOL WINAPI DllMain(HINSTANCE hinstDLL,DWORD fdwReason,LPVOID lpvReserved)
{
	switch(fdwReason)
	{
	case DLL_PROCESS_ATTACH:
		bSNESAmp_Loaded=TRUE;
		Init();
		SNESAmp_SetConfig(&Config);
		SynchedVisParams.PCMBuffer=NULL;
		return TRUE;

	case DLL_PROCESS_DETACH:
		if(bSNESAmp_Loaded==FALSE)
			return FALSE;
		if(bSNESAmp_Playing)
			SNESAmp_Stop();
		Quit();
		bSNESAmp_Loaded=FALSE;
		return TRUE;
	}
	return FALSE;
}

extern "C" BOOL WINAPI SNESAmp_Play(LPCTSTR lpszFileName)
{
	if(bSNESAmp_Loaded==FALSE)
		return FALSE;

	if(Play((char*)lpszFileName))
		return FALSE;

	bSNESAmp_Playing=TRUE;
	return TRUE;
}

extern "C" BOOL WINAPI SNESAmp_Pause()
{
	if(bSNESAmp_Loaded==FALSE)
		return FALSE;

	Pause();
	return TRUE;
}

extern "C" BOOL WINAPI SNESAmp_UnPause()
{
	if(bSNESAmp_Loaded==FALSE)
		return FALSE;

	UnPause();
	return TRUE;
}

extern "C" BOOL WINAPI SNESAmp_Stop()
{
	if(bSNESAmp_Loaded==FALSE)
		return FALSE;

	Stop();
	bSNESAmp_Playing=FALSE;
	return TRUE;
}

extern "C" BOOL WINAPI SNESAmp_SetConfig(LPSNESAMP_CONFIG lpCfg)
{
	if(bSNESAmp_Loaded==FALSE)
		return FALSE;

	memcpy(&Config,lpCfg,sizeof(SNESAMP_CONFIG));
	SetConfig();
	return TRUE;
}

extern "C" BOOL WINAPI SNESAmp_GetConfig(LPSNESAMP_CONFIG lpCfg)
{
	if(bSNESAmp_Loaded==FALSE)
		return FALSE;

	memcpy(lpCfg,&Config,sizeof(SNESAMP_CONFIG));
	return TRUE;
}

extern "C" BOOL WINAPI SNESAmp_GetID666Tag(LPCTSTR lpszFileName,LPID666_TAG lpTag)
{
	memset(lpTag,0,sizeof(ID666_TAG));

	if(bSNESAmp_Loaded==FALSE)
		return FALSE;

	SPCHdr SPC;
	FILE *inFile;
	if((inFile=fopen(lpszFileName,"rb"))==NULL)
		return FALSE;
	fread(&SPC,256,1,inFile);
	fclose(inFile);

	ID666 id666(SPC);

	memcpy(lpTag->Song,id666.Song,33);
	memcpy(lpTag->Game,id666.Game,33);
	memcpy(lpTag->Artist,id666.Artist,33);
	memcpy(lpTag->Dumper,id666.Dumper,17);
	memcpy(lpTag->Date,id666.Date,12);
	lpTag->Emu=id666.Emu;
	memcpy(lpTag->Comment,id666.Comment,33);
	lpTag->Song_ms=id666.Song_ms;
	lpTag->Fade_ms=id666.Fade_ms;
	lpTag->bHasID666=id666.bHasID666;

	return TRUE;
}

extern "C" BOOL WINAPI SNESAmp_SetSongLength(INT nPlayLength,INT nFadeLength)
{
	if(bSNESAmp_Loaded==FALSE)
		return FALSE;

	bSetSongLength=TRUE;
	Song_ms=nPlayLength;
	Fade_ms=nFadeLength;
	return TRUE;
}

extern "C" BOOL WINAPI SNESAmp_IsPlaying()
{
	if(bSNESAmp_Loaded==FALSE||LastKeyOnTime<=OutputTime-2500)
		return FALSE;

	return TRUE;
}

extern "C" INT WINAPI SNESAmp_GetPlayTime()
{
	if(bSNESAmp_Loaded==FALSE)
		return 0;

	return Seek!=-1?SongTime:OutputTime;
}

extern "C" BOOL WINAPI SNESAmp_SetPlayTime(INT nPlayTime)
{
	if(bSNESAmp_Loaded==FALSE)
		return FALSE;

	bSeek=TRUE;
	Seek=nPlayTime;
	return TRUE;
}

extern "C" BOOL WINAPI SNESAmp_MuteChannels(int nChannels)
{
	if(bSNESAmp_Loaded==FALSE)
		return FALSE;

	for(int i=0;i<8;i++)
	{
		if(nChannels&(1<<i))
			Mix[i].MOpt|=(char)0x10;
		else
			Mix[i].MOpt&=(char)~0x10;
	}
	return TRUE;
}

extern "C" BOOL WINAPI SNESAmp_SetMixingThreadPriority(INT nPriority)
{
	if(bSNESAmp_Loaded==FALSE)
		return FALSE;

	bSetThreadPriority=TRUE;
	nThreadPriority=nPriority;
	return TRUE;
}

extern "C" BOOL WINAPI SNESAmp_GetVisParams(LPVIS_PARAMS lpVisParams)
{
	if(bSNESAmp_Loaded==FALSE)
		return FALSE;

	if(bSNESAmp_Playing)
	{
		lpVisParams->VMMaxL=SynchedVisParams.VMMaxL;
		lpVisParams->VMMaxR=SynchedVisParams.VMMaxR;
		lpVisParams->PCMBuffer=SynchedVisParams.PCMBuffer;
		lpVisParams->PCMBufferLength=SynchedVisParams.PCMBufferLength;
		lpVisParams->dwCount=SynchedVisParams.dwCount;
		memcpy(&lpVisParams->DSP,&SynchedVisParams.DSP,sizeof(SynchedVisParams.DSP));
		memcpy(lpVisParams->Mix,SynchedVisParams.Mix,sizeof(SynchedVisParams.Mix));		
	}
	else
	{
		memset(lpVisParams,0,sizeof(VIS_PARAMS));
	}
		
	return TRUE;
}