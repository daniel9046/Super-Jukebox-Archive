#include <windows.h>
#include <stdio.h>
#include <conio.h>
#include "SNESAmp.h"
#include "dsp.h"
#include "out_wave.h"
#include "in_snes.h"

VIS_PARAMS SynchedVisParams;
HWAVEOUT hwo;
struct SndBuffer
{
	BOOL bFull,bPlaying;
	DWORD dwSize;
	WAVEHDR wh;
	VIS_PARAMS VP;
}
*SndBuffers;
INT OutputTime,bps;
BOOL bFlushing;

void CALLBACK waveOutProc(HWAVEOUT hwo,UINT uMsg,DWORD dwInstance,DWORD dwParam1,DWORD dwParam2)
{
	WAVEHDR *whdr=(WAVEHDR*)dwParam1;
	
	switch(uMsg)
	{
	case WOM_DONE:
		waveOutUnprepareHeader(hwo,whdr,sizeof(WAVEHDR));
		int b=whdr->dwUser;

		if(!bFlushing)
		{
			memcpy(&SynchedVisParams.DSP,&SndBuffers[b].VP.DSP,sizeof(SndBuffers[b].VP.DSP));
			memcpy(SynchedVisParams.Mix,SndBuffers[b].VP.Mix,sizeof(SndBuffers[b].VP.Mix));
			memcpy(SynchedVisParams.PCMBuffer,SndBuffers[b].VP.PCMBuffer,SndBuffers[b].VP.PCMBufferLength);
			SynchedVisParams.VMMaxL=SndBuffers[b].VP.VMMaxL;
			SynchedVisParams.VMMaxR=SndBuffers[b].VP.VMMaxR;
			SynchedVisParams.PCMBufferLength=SndBuffers[b].VP.PCMBufferLength;
			SynchedVisParams.dwCount++;

			OutputTime+=(NumSmp*1000)/SmpRate;
			if(SndBuffers[b].VP.DSP.KOn)
				LastKeyOnTime=OutputTime;
		}
		SndBuffers[b].bPlaying=FALSE;
		SndBuffers[b].bFull=FALSE;
		break;
	}
}
int OW_Open(int SampleRate, int NumChannels, int BitsPerSmp, int BufferLenms, int VisRate)
{
	int FrameSize=(NumChannels-1)+(BitsPerSmp>>4);

	WAVEFORMATEX wfx;
	wfx.wFormatTag=WAVE_FORMAT_PCM;
	wfx.nChannels=(unsigned short)NumChannels;
	wfx.nSamplesPerSec=SampleRate;
	wfx.wBitsPerSample=(unsigned short)BitsPerSmp;
	wfx.nBlockAlign=(unsigned short)(NumChannels*BitsPerSmp/8);
	wfx.nAvgBytesPerSec=SampleRate*wfx.nBlockAlign;
	wfx.cbSize=0;

	if(waveOutOpen(&hwo,WAVE_MAPPER,&wfx,(DWORD)waveOutProc,0,CALLBACK_FUNCTION)!=MMSYSERR_NOERROR)
		return -1;

	bps=VisRate*BufferLenms/1000;
	int bpb=(NumSmp<<FrameSize);
	SndBuffers=(SndBuffer*)malloc(sizeof(SndBuffer)*bps);
	for(int b=0;b<bps;b++)
	{		
		SndBuffers[b].bFull=FALSE;
		SndBuffers[b].bPlaying=FALSE;
		SndBuffers[b].wh.dwBufferLength=SndBuffers[b].dwSize=SndBuffers[b].VP.PCMBufferLength=bpb;
		SndBuffers[b].wh.dwUser=b;
		if((SndBuffers[b].VP.PCMBuffer=SndBuffers[b].wh.lpData=(LPSTR)malloc(bpb))==NULL)
			return -1;
	}
	if((SynchedVisParams.PCMBuffer=malloc(bpb))==NULL)
		return -1;
	SynchedVisParams.dwCount=OutputTime=0;

	return bpb*bps*1000/wfx.nAvgBytesPerSec;
}
void OW_Close()
{
	OW_Flush();
	waveOutClose(hwo);
	for(int b=0;b<bps;b++)
		free(SndBuffers[b].VP.PCMBuffer);
	free(SndBuffers);
	free(SynchedVisParams.PCMBuffer);
	memset(&SynchedVisParams,0,sizeof(VIS_PARAMS));
}
int OW_Write(char *Buf, int Len)
{
	BOOL bWritten=FALSE;

	for(int b=0;b<bps;b++)
	{
		if(!SndBuffers[b].bFull&&!bWritten)
		{
			memcpy(SndBuffers[b].VP.PCMBuffer,Buf,Len);
			memcpy(&SndBuffers[b].VP.DSP,&DSP,sizeof(DSP));
			memcpy(SndBuffers[b].VP.Mix,Mix,sizeof(Mix));
			SndBuffers[b].VP.VMMaxL=VMMaxL;
			SndBuffers[b].VP.VMMaxR=VMMaxR;
			SndBuffers[b].bFull=TRUE;
			bWritten=TRUE;
		}
		if(SndBuffers[b].bFull&&!SndBuffers[b].bPlaying)
		{
			SndBuffers[b].bPlaying=TRUE;
			SndBuffers[b].wh.dwFlags=0;
			waveOutPrepareHeader(hwo,&SndBuffers[b].wh,sizeof(WAVEHDR));
			waveOutWrite(hwo,&SndBuffers[b].wh,sizeof(WAVEHDR));
		}
	}

	return bWritten?0:1;
}
int OW_CanWrite()
{
	for(int b=0;b<bps;b++)
	{
		if(!SndBuffers[b].bFull)
			return SndBuffers[b].dwSize;
	}
	return 0;
}
int OW_IsPlaying()
{
	int iPlayingCount=0;
	for(int b=0;b<bps;b++)
		if(SndBuffers[b].bPlaying)iPlayingCount++;
	return iPlayingCount;
}
int OW_Pause(int Pause)
{
	Pause?waveOutPause(hwo):waveOutRestart(hwo);
	return 0;
}
void OW_Flush(void)
{
	bFlushing=TRUE;
	waveOutReset(hwo);
	int iPlayingCount;
	do
	{
		iPlayingCount=0;
		for(int b=0;b<bps;b++)
			if(SndBuffers[b].bPlaying)iPlayingCount++;
	}
	while(iPlayingCount);
	for(int b=0;b<bps;b++)
		SndBuffers[b].bFull=FALSE;
	bFlushing=FALSE;
}