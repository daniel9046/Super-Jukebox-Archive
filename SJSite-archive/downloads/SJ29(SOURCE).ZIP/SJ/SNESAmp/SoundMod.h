/**************************************************************************************************
* Program:    SNES Sound Module Emulator
* Platform:   Intel 80386 / Pentium II
* Programmer: Anti Resonance
* 
* Permission to use, copy, modify and distribute Snes9x in both binary and source form, for non-
* commercial purposes, is hereby granted without fee, providing that this license information and
* copyright notice appear with all copies and any derived work.
* 
* This software is provided 'as-is', without any express or implied warranty. In no event shall the
* Artists be held liable for any damages arising from the use of this software.
* 
* Snes9x is freeware for PERSONAL USE only. Commercial users should seek permission of the copyright
* holders first. Commercial use includes charging money for Snes9x or software derived from Snes9x.
*
* The copyright holders request that bug fixes and improvements to the code should be forwarded to
* them so everyone can benefit from the modifications in future versions.
*
* Super NES and Super Nintendo Entertainment System are trademarks of Nintendo Co., Limited and its
* subsidiary companies.
*
* --------------------------------------------------------------------------------------------------
* Revision History:
*
* 1.1  04.04.2000 SNESAmp v1.0
*
* 1.0  17.03.2000 SNESAmp v0.9
*																				 Copyright (C)2000 Alpha-II Productions
***************************************************************************************************/

//*************************************************************************************************
//External Functions

//**************************************************************************************************
// Initialize Sound Processing Unit
//
// Desc:
//    Initializes internal tables, memory, and registers.
//    This only needs to be called once, and must be proceeded by ResetSPU and SetSPUOpt.
// In:
//    -> 128KB RAM
// Out:
//    -> 64KB RAM aligned on a 64K boundary

void* InitSPU(void*);


//**************************************************************************************************
// Reset Sound Processor
//
// Desc:
//    Clears all memory, sets registers to default values, and sets pre-amplification level.
// In:
//    Level of amplification (0-99)
// Out:
//    nothing

void ResetSPU(int);


//*************************************************************************************************
// Fix Sound Processor After Load
//
// Desc:
//    Prepares the sound processor for emulation after a saved state is loaded.
// In:
//    SPC internal registers
// Out:
//    nothing
// Destroys:
//    nothing

void FixSPU(short PC,char A,char Y,char X,char PS,char S);


//**************************************************************************************************
// Set Sound Processor Options
//
// Desc:
//    Configures the SPC700 emulator
// In:
//    Output sample rate (8000-64000)
//    DSP Options
// Out:
//    nothing

void SetSPUOpt(int, DOpt);


//**************************************************************************************************
// Shutdown Sound Module Emulator
//
// Desc:
//    Does nothing
// In:
//    nothing
// Out:
//    nothing

void ShutSPU();


//**************************************************************************************************
// Emulate Sound Module
//
// Desc:
//    Emulates the SPC700 for a specified amount of time.  DSP output is placed in a buffer to be
//    handled by the main program.
// In:
//    Buf-> Buffer to store output samples
//    Cyc = Clock cycles to emulate (1-2048000)
// Out:
//    -> End of buffer

void* EmuSPU(void *Buf,int Cyc);