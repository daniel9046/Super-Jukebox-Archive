/**************************************************************************************************
* Program:    SNES Sound Module Emulator v1.2 for Winamp
* Platform:   Win32
* Programmer: Anti Resonance
*
* This plug-in was created to test the 32-bit emulation core used in Snes9x.
*
* Thanks to Marp for the YMAMP source, and Nitro and Gary Henderson for answering my questions
* about C.
*
* For more information about the OutModule and InModule structures, get the input plug-in SDK from
* www.winamp.com
*
* -------------------------------------------------------------------------------------------------
* Revision History:
*
* 1.2  22.5.00 Import Release with Bonus Tracks
*      + Switched to C++ (code is mostly non-OO, though)
*      + Added auto preamplifcation reduction (APR)
*      + Added context sensitive help to dialog boxes
*      + ZST's are loadable
*      + Removed the ability to save tags in binary format
*      + ID666 editor has an Apply button
*      + Added out port status to control window
*      - Files are checked for validity
*      - Song length must be at least 1 second
*      - Removed an invalid line of code that was causing crashes in the ID666 editor
*      - ID666 editor terminates when a file handle is invalid
*      - Fade and song length are based off NumSmp instead of 576
*
* 1.0  15.4.00 Final Release
*      + Configuration changes are applied to the next song
*      + Changes to the time in the ID666 tag have an immediate effect
*      + Command sub-window can be disabled
*
* 0.91 1.4.00 Bugfix
*      - Configuration gets saved
*      - Coded a workaround for SD3 .SPC's that were playing too slow
*
* 0.9  25.03.00 Initial test release
*                                                            Copyright (C)2000 Alpha-II Productions
**************************************************************************************************/

//Internal function headers
void	SetPreamp(int);
void	Init();
void	Quit();
int	Play(char*);
void	Pause();
void	UnPause();										
int	IsPaused();
void	Stop();
DWORD	EmuSPCThread(void*);
void SetConfig();

extern int		SongTime;                          //Elapsed time in ms
extern int		LastKeyOnTime;					   //Last time in ms that a key was pressed
extern int		Seek;                              //Position to seek to in song
extern BOOL     bSeek;
extern int		NumSmp;                         //Number of samples needed for Winamp's DSP buffer
extern int		Done;                              //Done with emulation thread
extern int		SmpRate;                           //Output sample rate