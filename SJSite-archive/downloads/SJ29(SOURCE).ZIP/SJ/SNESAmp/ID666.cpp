/**************************************************************************************************
* ID666 Tag Manager
*                                                            Copyright (C)2000 Alpha-II Productions
**************************************************************************************************/

#include	<windows.h>
#include "id666.h"

extern int DefSong;
extern int DefFade;

ID666::ID666()
{
	memset(this,0,sizeof(ID666));
}

ID666::ID666(ID666 &ID6)
{
	memcpy(this,&ID6,sizeof(ID666));
}

ID666::ID666(SPCHdr &SPC)
{
	FixID6(SPC);
}

ID666::~ID666() {}

bool ID666::IsString(char *Str, int Len)
{
	while ((--Len>=0)&&((Str[Len]==0)||((Str[Len]>=0x30)&&(Str[Len]<=0x39))));
	return((Len==-1) ? 1 : 0);
}

void ID666::FixID6(SPCHdr &SPC)
{
	int	i,j;
	char	str[7];

	memset(this,0,sizeof(ID666));

	memcpy(Song,SPC.Song,32);
	memcpy(Game,SPC.Game,32);
	memcpy(Dumper,SPC.Dumper,16);
	memcpy(Comment,SPC.Comment,32);
	memcpy(SongStr,SPC.SongLen,3);
	memcpy(FadeStr,SPC.FadeLen,5);
	Bin=false;

	//Get song and fade length
	if ((IsString(SongStr,3) && IsString(FadeStr,5)) && (SongStr[0]!=0 || FadeStr[0]!=0))
	{
		Song_ms=atoi(SongStr);
		Fade_ms=atoi(FadeStr);
		if (Song_ms>959) Song_ms=959;

		memcpy(Artist,SPC.Artist,32);
		Emu=SPC.Emulator;
		if	(Emu>=0x30 && Emu<=0x39) Emu-=0x30;
		else Emu=0;
	}
	else
	{
		for(j=0,i=3;i>=0;i--)
			j=(j<<8)+(unsigned char)FadeStr[i];
		if (j>90000) j=90000;

		i=((unsigned char)SongStr[1]<<8)+(unsigned char)SongStr[0];
		if (i>959) i=959;

		Song_ms=i;
		Fade_ms=j;

		memcpy(Artist,SPC.Artist-1,32);
		Emu=SPC.ChnDis;
		Bin=true;
	}

	if (Song_ms<=0)                     //Does song have a length?
	{
		Song_ms=DefSong/1000;
		Fade_ms=DefFade;
		bHasID666=false;
	}
	else bHasID666=true;
	if (Fade_ms<=0) Fade_ms=0;

	//Change song/fade length to strings
	wsprintf(SongMin,"%i",Song_ms/60);
	wsprintf(SongSec,"%02i",Song_ms%60);
	Song_ms*=1000;
	wsprintf(FadeSec,"%i.%03i",Fade_ms/1000,Fade_ms%1000);

	if (Fade_ms==0) Fade_ms=1;     //Internally, fade length can't be 0

	//Get date
	if (SPC.Date[0]!=0)                     //Does a date exist?
	{
		if (SPC.Date[0]<=31 && SPC.Date[1]<=12) //Is the date in binary format?
		{
			itoa(SPC.Date[1],Date,10);
			itoa(SPC.Date[0],str,10);
			strcat(Date,"/");
			strcat(Date,str);
			i=((SPC.Date[3])<<8)+(unsigned char)(SPC.Date[2]);
			itoa(i,str,10);
			strcat(Date,"/");
			strcat(Date,str);
			Bin=true;
		}
		else
		{
			memcpy(Date,SPC.Date,11);
		}
	}
}

ID666 ID666::operator=(ID666 &ID6)
{
	memcpy(this,&ID6,sizeof(ID666));
	return(*this);
}

ID666 ID666::operator=(SPCHdr &SPC)
{
	FixID6(SPC);
	return(*this);
}

void ID666::ToSPC(SPCHdr &SPC)
{
//	char	SPCDate[12];

	memset((&SPC)+0x2e,0,0xa5);

/*	if (Bin)
	{
		memcpy(SPC.Artist-1,Artist,32);
		memcpy(SPC.SongLen,&Song_ms,3);
		memcpy(SPC.FadeLen,&Fade_ms,4);
		memcpy(SPCDate,Date,12);
		__asm
		{
			mov	ax,word ptr [SPCDate]
			xchg	al,ah
			and	ax,0xf0f
			aad
			mov	[SPCDate],al

			mov	ax,word ptr [SPCDate+3]
			xchg	al,ah
			and	ax,0xf0f
			aad
			mov	[SPCDate+1],al

			mov	ax,word ptr [SPCDate+6]
			xchg	al,ah
			and	ax,0xf0f
			aad
			mov	dl,100
			mul	dl
			mov	dx,ax
			mov	ax,word ptr [SPCDate+8]
			xchg	al,ah
			and	ax,0xf0f
			aad
			add	ax,dx
			mov	word ptr [SPCDate+2],ax
		}
		if (Date[2]=='/')
		__asm
		{
			mov	ax,word ptr [SPCDate]
			xchg	al,ah
			mov	word ptr [SPCDate],ax
		}
		memcpy(SPC.Date,SPCDate,4);
		SPC.ChnDis=Emu;
	}
	else */
	{
		memcpy(SPC.Artist,Artist,32);
		memcpy(SPC.Date,Date,11);
		memcpy(SPC.SongLen,SongStr,3);
		memcpy(SPC.FadeLen,FadeStr,5);
		SPC.Emulator=(char)(Emu+0x30);
	}

	memcpy(SPC.Song,Song,32);
	memcpy(SPC.Game,Game,32);
	memcpy(SPC.Dumper,Dumper,16);
	memcpy(SPC.Comment,Comment,32);
}

bool ID666::IsBin()
{
	return(Bin);
}