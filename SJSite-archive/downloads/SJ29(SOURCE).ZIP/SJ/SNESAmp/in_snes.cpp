/**************************************************************************************************
* SNES Sound Module Emulator v1.2 for Winamp
*
* This is the first time I've made a Winamp plug-in, the first time I've made a .DLL, and the first
* time I've used VC++.  Don't laugh at my code.
*
*                                                            Copyright (C)2000 Alpha-II Productions
**************************************************************************************************/

#include <windows.h>
#include "id666.h"                          //Functions for ID666 tag
#include "spc700.h"                         //SPC700 processor
#include "dsp.h"                            //DSP
#include "soundmod.h"                       //Sound module
#include "in_snes.h"                        //Function definitions
#include "SNESAmp.h"
#include "out_wave.h"

#define	MaxAmp 100                         //Maximum pre-amp level

//Emulation pointers
void		*SPCBase,*SPCRAM;                  //Base pointer and aligned pointer to SPC RAM
char		*Backup;                           //Pointer to backup .SPC
char		*DSPBase;                          //DSP output buffer

//User defined settings
DOpt		SmpOpt;                            //User defined options for the DSP
int		SmpRate;                           //Output sample rate
int		BPS;                               //Bits per sample
int		NChn;                              //Number of output channels
int		DefSong,DefFade;                   //Default song and fade length
int		NoTime;                            //Disable ID666 song length
int		APR;                               //bits-10 - Type  bit-2 Clipped
int		InitAmp;                           //Initial preamp level
int		Threshold;                         //Maximum amplitude allowed

//Playback thread
int		MixType;                           //Mixing rountine
int		FrameSize;                         //Size of each sample frame Log2
int		SongTime;                          //Elapsed time in ms
int		LastKeyOnTime;					   //Last time in ms that a key was pressed
int		Seek;                              //Position to seek to in song
BOOL    bSeek;
int		Paused;                            //Are we paused?
int		Preamp;                            //Current pre-amplification level
int		IncTime;                           //Samples that have passed since preamp was increased
int		NumSmp;                         //Number of samples needed for Winamp's DSP buffer

//ID666 Tag
SPCHdr	SPCCur;                            //Header of current .SPC playing
ID666	ID6Cur;                            //ID666 tag split apart for internal use

//Emulation thread
HANDLE	THand;                             //Thread handle
int		KillThread;                        //The kill switch for the output thread
int		Done;                              //Done with emulation thread
char	FPUState[108];                     //Array for FPU saved state

extern SNESAMP_CONFIG Config;
extern BOOL bSetSongLength;
extern INT Song_ms,Fade_ms;
extern BOOL bSetThreadPriority;
extern INT nThreadPriority;

//=================================================================================================

//*************************************************************************************************
// Get Configuration
//
// Desc:
//
// In:
//    nothing
// Out:
//    nothing

void SetConfig()
{
	//Sample rate
	SmpRate=Config.SmpRate;
	if (SmpRate<8000) SmpRate=8000;
	if (SmpRate>64000) SmpRate=64000;

	//Bits per sample
	BPS=Config.BPS;
	if (BPS!=16) BPS=8;
	SmpOpt.Smp8bit=(BPS>>3)&1;

	//Number of channels
	NChn=Config.NChn;
	if (NChn!=2) NChn=1;
	SmpOpt.SmpMono=NChn&1;

	//Interpolation type
	SmpOpt.IntType=Config.Interpolation;

	//Use low-pass filter?
	SmpOpt.LowPass=Config.LowPass;

	//Use old BRE?
	SmpOpt.OldBRE=Config.OldBRE;

	//Disable timer?
	NoTime=Config.NoTime;

	//Default song length
	DefSong=Config.DefSong;
	if (DefSong<1) DefSong=1;
	if (DefSong>959000) DefSong=959000;

	//Default fade length
	DefFade=Config.DefFade;
	if (DefFade<1) DefFade=1;
	if (DefFade>99000) DefFade=99000;

	//Automatic Pre-amplifications Reduction
	APR=Config.APR;
	if (APR<0) APR=0;
	if (APR>2) APR=2;

	//Pre-amplification level
	InitAmp=Config.Amp;
	if (InitAmp<1) InitAmp=1;
	if (InitAmp>MaxAmp) InitAmp=MaxAmp;
	Preamp=InitAmp;

	//APR Threshold
	Threshold=Config.Threshold;
	if (Threshold<0) Threshold=0;
	if (Threshold>32768) Threshold=32768;
	Threshold+=32767;

	SetSPUOpt(SmpRate,SmpOpt);
	FrameSize=(NChn-1)+(BPS>>4);

	if(Config.VisRate<10)Config.VisRate=10;
	NumSmp=SmpRate/Config.VisRate;

	if(Config.BufferLength<100)Config.BufferLength=100;
}

//*************************************************************************************************
// Initialize Plug-in
//
// Desc:
//    Allocates memory, initializes Winamp and the emulator, and sets up values.
//    Called when Winamp is opened.
// In:
//    nothing
// Out:
//    nothing

void Init()
{
	SPCBase=HeapAlloc(GetProcessHeap(),0,131072); //Allocate memory for SPC RAM
	Backup=(char*)HeapAlloc(GetProcessHeap(),0,66048);   //Allocate memory for backup .SPC
	DSPBase=(char*)HeapAlloc(GetProcessHeap(),0,16384*4); //Allocate memory for output

	SPCRAM=InitSPU(SPCBase);                 //Initialize SPU w/ ptr to SPC RAM (Call only once)

	//Check for MMX support
	__asm
	{
		pushfd
		pop	eax                             //EAX = EFLAGS
		mov	edx,eax
		xor	eax,0x200000                    //Flip ID flag
		push	eax
		popfd                                 //Restore EFLAGS
		pushfd
		pop	eax                             //EAX = New EFLAGS
		xor	eax,edx
		test	eax,0x200000                    //Does processor support the CPUID instruction?
		setz	al                              //  No, Use regular DSP emulation routine
		movzx	eax,al
		mov	MixType,eax
	}
	if (MixType==0)
	__asm
	{
		mov	eax,1
		cpuid
		bt		edx,23                          //Does processor support MMX instructions?
		setc	al                              //  Yes
		inc	al
		movzx	eax,al
		mov	MixType,eax
	}

	SmpOpt.MixRout=MixType;
}

//*************************************************************************************************
// Shutdown Plug-in
//
// Desc:
//    Deallocates memory, and saves the current pre-amp level.
//    Called when Winamp is closed.
// In:
//    nothing
// Out:
//    nothing

void Quit()
{
	ShutSPU();
	HeapFree(GetProcessHeap(),0,DSPBase);
	HeapFree(GetProcessHeap(),0,Backup);
	HeapFree(GetProcessHeap(),0,SPCBase);
}

//*************************************************************************************************
// Start Emulation
//
// Desc:
//    Loads an SPC700 dump, sets up Winamp for stream, and initializes preamp window.
// In:
//    Name of file to load
// Out:
//    0 if everything's cool

int Play(char *FN) 
{ 
	int maxlatency;
	unsigned long	thread_id,L;
	HANDLE	FH;                                //File handle

	APR&=3;
	if (APR)
	{
		Preamp=InitAmp;
		IncTime=0;
	}

	maxlatency=OW_Open(SmpRate,NChn,BPS,Config.BufferLength,Config.VisRate);
	if (maxlatency<0) return(1);             //Error opening device

	FH=CreateFile(FN,GENERIC_READ,FILE_SHARE_READ,NULL,OPEN_EXISTING,FILE_ATTRIBUTE_NORMAL,NULL);
	if (FH==INVALID_HANDLE_VALUE) return(1);
	ReadFile(FH,Backup,66048,&L,NULL);    //Read dump into backup memory
	CloseHandle(FH);
	
	//Fixup SPU for emulation
	ResetSPU(Preamp);                        //Reset SPU

	memcpy(&SPCCur,Backup,256);              //Header
	memcpy(SPCRAM,Backup+256,65536);         //64K RAM
	memcpy(&DSP,Backup+65792,128);           //DSP regs
	memcpy(&ExtraRAM,Backup+65984,64);       //Extra RAM

	FixSPC((short)((SPCCur.Regs.PC[1]<<8)+SPCCur.Regs.PC[0]),SPCCur.Regs.A,SPCCur.Regs.Y,SPCCur.Regs.X,SPCCur.Regs.PSW,SPCCur.Regs.SP);
	FixDSP();                                
	ID6Cur=SPCCur;
	if(bSetSongLength)
	{
		ID6Cur.Song_ms=Song_ms;
		ID6Cur.Fade_ms=Fade_ms;
		bSetSongLength=FALSE;
	}

	SetPreamp(Preamp);
	Paused=0;

	//Start thread
	SongTime=0;                              //Reset elapsed time
	LastKeyOnTime=0;                         //Reset time last key was pressed
	Seek=-1;                             //No need to seek
	Done=KillThread=0;                       //Thread is active
	THand=(HANDLE)CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)EmuSPCThread,(void*)&KillThread,0,&thread_id);
	SetThreadPriority(THand,nThreadPriority);

	return(0);
}

void Pause()
{
	Paused=1;
	OW_Pause(1);
}

void UnPause()
{
	Paused=0;
	OW_Pause(0);
}

int IsPaused()
{
	return(Paused);
}

//*************************************************************************************************
// Stop Emulation
//
// Desc:
//    Sets a flag to kill the thread, then waits for DSP output to complete
// In:
//    nothing
// Out:
//    nothing

void Stop()
{ 
	if (THand!=INVALID_HANDLE_VALUE)
	{
		KillThread=1;
		if (WaitForSingleObject(THand,3000)==WAIT_TIMEOUT)
		{
			MessageBox(NULL,"The emulation thread won't cooperate.  Press OK to terminate.","SNESAmp Error",MB_OK|MB_ICONEXCLAMATION);
			TerminateThread(THand,0);
		}
		CloseHandle(THand);
		THand=INVALID_HANDLE_VALUE;
	}

	OW_Close();
}

//*************************************************************************************************
// Set Preamplification Level
//
// Desc:
//    Sets the preamp level and updates the necessary controls
// In:
//    Preamp level
// Out:
//    nothing

void SetPreamp(int Level)
{
	SetDSPAmp(Level);
}

//*************************************************************************************************
// Emulation Thread
//
// Desc:
//    Emulates the sound module and passes output to the Winamp DSP buffer.
// In:
//    -> ???
// Out:
//    NULL

DWORD EmuSPCThread(void *K)
{
	int	MovSize;                           //Number of bytes sent to the buffer
	char	*DSPPtr=DSPBase;                   //Current position in DSPBase to store emulation output
	DOpt	NoMix=SmpOpt;                      

	NoMix.MixRout=0;                         //Copy DSP options, but disable output

	while (KillThread==0)
	{
		if(bSetThreadPriority)
		{
			SetThreadPriority(GetCurrentThread(),nThreadPriority);
			bSetThreadPriority=FALSE;
		}

		if (Seek!=-1)                         //Has thread been flagged to seek to a new position?
		{
			OW_Flush();     //Stop Winamp DSP output

			if (SongTime>Seek)                 //Is seek backwards?
			{                                  //  Yes, Emulation will have to be reset
				ResetSPU(Preamp);               //Reset SPU

				//Copy .SPC from backup
				memcpy(&SPCCur,Backup,256);
				memcpy(SPCRAM,Backup+256,65536); 
				memcpy(&DSP,Backup+65792,128);   
				memcpy(&ExtraRAM,Backup+65984,64);

				//Fixup SPU for emulation
				FixSPC((short)((SPCCur.Regs.PC[1]<<8)+SPCCur.Regs.PC[0]),SPCCur.Regs.A,SPCCur.Regs.Y,SPCCur.Regs.X,SPCCur.Regs.PSW,SPCCur.Regs.SP);
				FixDSP();

				SongTime=0;                     //Reset current position
			}

			//Emulate up to seek position
			SetSPUOpt(SmpRate,NoMix);          //Turn off mixing
			while (SongTime<Seek && KillThread==0)
			{
				EmuSPU(DSPPtr,204800);          //Emulate in .1 second steps
				SongTime+=100;
			}
			FixSeek();
			SetSPUOpt(SmpRate,SmpOpt);         //Turn mixing back on

			DSPPtr=DSPBase;
			OutputTime=SongTime;
			Done=0;
			Seek=-1;
		}

		if (Done)
		{
			if (!OW_IsPlaying())    //Is DSP no longer active?
				return(0);
			Sleep(10);
		}
		else                                                    //Can we write NumSmp samples to the DSP buffer?
		if (OW_CanWrite()>=(NumSmp<<FrameSize))
		{	
			//Emulate -------------------------
			for(int i=0;i<8;i++)
				VMMaxL=VMMaxR=Mix[i].VMaxL=Mix[i].VMaxR=0;		//Reset greatest output

			__asm fsave FPUState;                                //Winamp expects the FPU to remain unchanged
			while ((int)DSPPtr<(int)DSPBase+(2*NumSmp<<FrameSize))  //Emulate until double buffer is filled
				DSPPtr=(char*)EmuSPU(DSPPtr,16384);
			__asm frstor FPUState;

			OW_Write(DSPBase,NumSmp<<FrameSize);      //Send output to Winamp DSP buffer

			MovSize=(DSPPtr-DSPBase)-(NumSmp<<FrameSize);        //Move samples not sent to DSPBase
			memmove(DSPBase,DSPBase+(NumSmp<<FrameSize),MovSize);
			DSPPtr=DSPBase+MovSize;                              //-> last sample generated

			//Auto Preamp Reduction -----------
			if (APR)
			{                                                    //Compare output (before clipping)
				if (VMMaxL>(Threshold) || VMMaxR>(Threshold))
				{
					int	Gain=max(VMMaxL,VMMaxR); // Gain = max channel

					//Calculate new preamp level
					__asm
					{
						mov	eax,Threshold
						mul	Preamp
						div	Gain
						cmp	eax,Preamp
						cmc
						sbb	eax,0
						mov	Preamp,eax
					}

					SetPreamp(Preamp);
					APR|=4;
				}
				else
				if (APR==2)                                       //Increase, if below threshold
				{
					IncTime+=NumSmp;
					if (IncTime>(SmpRate>>2))                      //Has more than � second gone by?
					{
						if (++Preamp>=MaxAmp)
						{
							Preamp=MaxAmp;
							APR|=4;
						}
						SetPreamp(Preamp);
						IncTime-=SmpRate>>2;
					}
				}
			}

			//Calculate fade volume -----------
			SongTime+=(NumSmp*1000)/SmpRate;                     //Increase song time elapsed
			if ((SongTime>ID6Cur.Song_ms)&&(!NoTime))            //Has song length been reached?
			{                                                    //  Yes, Start fading
				if (SongTime<ID6Cur.Song_ms+ID6Cur.Fade_ms)       //Is song over?
					SetDSPVol(((ID6Cur.Fade_ms-(SongTime-ID6Cur.Song_ms))<<16)/ID6Cur.Fade_ms);
				else
				{
					SetDSPVol(0);
					if (SongTime>=ID6Cur.Song_ms+ID6Cur.Fade_ms)
						Done=1;
				}
			}
		}
		else Sleep(10);                        //Sleep for 10 ms while other processes take place
	}
	return(0);
}