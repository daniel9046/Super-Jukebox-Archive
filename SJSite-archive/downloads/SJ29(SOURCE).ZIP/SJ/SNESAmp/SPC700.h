/***************************************************************************************************
* Program:    Sony SPC700 Emulator
* Platform:   80386
* Programmer: Anti Resonance
*
* Taken from SPC Tool for use in Snes9x.
*
* Thanks to Michael Abrash.  It was reading the Graphics Programming Black Book that gave me the
* idea and inspiration to write this in the first place.
*
* Permission to use, copy, modify and distribute Snes9x in both binary and source form, for non-
* commercial purposes, is hereby granted without fee, providing that this license information and
* copyright notice appear with all copies and any derived work.
*
* This software is provided 'as-is', without any express or implied warranty. In no event shall the
* authors be held liable for any damages arising from the use of this software.
*
* Snes9x is freeware for PERSONAL USE only. Commercial users should seek permission of the copyright
* holders first. Commercial use includes charging money for Snes9x or software derived from Snes9x.
*
* The copyright holders request that bug fixes and improvements to the code should be forwarded to
* them so everyone can benefit from the modifications in future versions.
*
* Super NES and Super Nintendo Entertainment System are trademarks of Nintendo Co., Limited and its
* subsidiary companies.
*
* --------------------------------------------------------------------------------------------------
* Revision History:
*
* 2.11  04.05.2000 SNESAmp v1.2
*       - Control register is now set to 80h on reset
*
* 2.1   04.04.2000 SNESAmp v1.0
*       + Rearranged code so static branch prediction would be more accurate
*       + Clock cycles to emulate is passed on the stack to EmuSPC
*       + SPC700 registers are passed on the stack to the external debug routine
*       + Eliminated ORG directive and rewrote code to conform to MASM syntax
*       - Fixed some implementation bugs with the speed hack
*       - Fixed a bug in the 16-bit WrPost macro, again
*
* 2.0   17.03.2000 SNESAmp v0.9
*       + Rewrote for compatibility in a 32-bit C environment
*       + Added external functions to write to ports
*       - SLEEP wasn't erasing the port status on the first time through
*
* 1.51  22.02.2000 SPC Tool v0.6
*       - Fixed a bug in the 16-bit WrPost macro
*
* 1.5   01.02.2000 SPC Tool v0.51
*       + Added a hack to eliminate polling the counters
*       + Aligned many of the short jump destinations on paragraph boundaries
*       + Rewrote the opcode header macro to compile into table form instead of packed form.
*         (The compiled code is four times bigger, but it's now easier to align, port, and debug.)
*       + Store flags as dwords so accesses to the DP don't cause a partial register stall on PII's
*       - Fixed PCALL, STOP, and SLEEP
*
* 1.1   21.01.2000 SPC Tool v0.5
*	     + Reprogrammed PSW handling for faster entry/exit
*
* 1.0   27.12.1999 SPC Tool v0.2
*                                                             Copyright (C)2000 Alpha-II Productions
***************************************************************************************************/


//*************************************************************************************************
//Public Variables

struct SPCFlags
{
	char	C:1;                               //Carry
	char	Z:1;                               //Zero
	char	I:1;                               //Interrupts Enabled
	char	H:1;                               //Half-Carry (Auxiliary)
	char	B:1;                               //Software Break
	char	P:1;                               //Direct Page Selector
	char	V:1;                               //Overflow
	char	N:1;                               //Negative (Sign)
};

typedef void DebugSPC(unsigned char *PC,unsigned short YA,unsigned char X,SPCFlags PS,unsigned char *SP);

extern "C" unsigned char ExtraRAM[64];      //RAM used for storage if ROM reading is enabled
extern "C" unsigned char SPCOutP[4];        //Four out ports

//*************************************************************************************************
//External Functions

//*************************************************************************************************
// Initialize SPC700
//
// Desc:
//    This function is a remnant from assembly when dynamic code reallocation was used.  Now it
//    just initializes internal pointers.
// In:
//    -> 64KB of SPC RAM aligned on a 64K boundary
// Out:
//    nothing
// Destroys:
//    EAX

extern "C" void InitSPC(void*);


//*************************************************************************************************
// Reset SPC700
//
// Desc:
//    Clears all memory, resets function registers, and copies ROM into IPL region
// In:
//    nothing
// Out:
//    nothing
// Destroys:
//    nothing

extern "C" void ResetSPC();


//*************************************************************************************************
// Set SPC700 Debugging Routine
// 
// Desc:
//    Installs a vector that gets called between each opcode for debugging purposes.
//    Upon entrance to the function:
//       PC-> Current opcode (LOWORD = PC)
//       YA = YA
//       X  = X
//       PS = PSW
//       SP-> Current stack byte (LOWORD = SP)
//    Note:  'Debug' must be uncommented in the directives section
// In:
//    -> debug function (a null pointer turns off the debug call)
// Out:
//    nothing
// Destroys:
//    EAX

extern "C" void SetSPCDbg(DebugSPC*);


//*************************************************************************************************
// Fix SPC700 After Load
//
// Desc:
//    Loads timer steps with the values in the timer registers, resets the counters, sets up the
//    in/out ports, and stores the registers.
// In:
//    SPC internal registers
// Out:
//    nothing
// Destroys:
//    nothing

extern "C" void FixSPC(short PC,char A,char Y,char X,char PS,char S);


//*************************************************************************************************
// Get SPC700 Registers
//
// Desc:
//    Returns the registers stored in the CPU
// In:
//    nothing
// Out:
//    SPC internal registers
// Destroys:
//    nothing

extern "C" void GetSPCRegs(unsigned short &PC,unsigned char &A,unsigned char &Y,unsigned char &X,unsigned char &PS,unsigned char &S);


//*************************************************************************************************
// Write to SPC700 Port(s)
//
// Desc:
//    Writes a value to the SPC700 via the in ports
//    InPB writes a single byte value while InPW writes a 16-bit value to two ports.
// In:
//    Port = Port on which to write (0-3)
//    Val  = Value to write
// Out:
//    nothing
// Destroys:
//    nothing

extern "C" void SPCInPB(int Port,int Val);
extern "C" void SPCInPW(int Port,int Val);


//*************************************************************************************************
// Emulate SPC700
//
// Desc:
//    Emulates the SPC700 for the number of clock cycles specified.  If the speed hack is enabled,
//    emulation will also stop when a counter increases.
// In:
//    Cyc = Number of clock cycles to execute (1-2048000)
// Out:
//    Clock cycles left to execute (usually negative)
// Destroys:
//    nothing

extern "C" int EmuSPC(int Cyc);