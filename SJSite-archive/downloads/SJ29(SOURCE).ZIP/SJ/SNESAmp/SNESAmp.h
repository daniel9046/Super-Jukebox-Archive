#ifndef _SNESAMP_H_
#define _SNESAMP_H_

#include <windows.h>

#ifdef __cplusplus
extern "C"{
#endif

typedef struct
{
	INT SmpRate;				//Sample rate in Hertz
	INT BPS;					//Number of bits per sample
	INT NChn;					//Number of channels, 1=mono, 2=stereo
	INT Interpolation;			//Sound interpolation, 0=none, 1=linear, 2=cubic
	INT OldBRE;					//Use old style BRE, 0=no, 1=yes
	INT NoTime;					//Don't use time limits for songs, 0=no, 1=yes
	INT LowPass;				//Use low-pass filter, 0=no, 1=yes
	INT APR;					//Use auto preamp reduction, 0=no, 1=yes
	INT Amp;					//Preamp level, 1-100
	INT Threshold;				//APR threshold
	INT DefSong;				//Default length (in milliseconds) to use for songs that don't have an ID666 tag
	INT DefFade;				//Default fadeout length (in milliseconds) to use for songs that don't have an ID666 tag
	INT BufferLength;			//Sound output buffer length (in milliseconds) 100-10000
	INT VisRate;				//Rate of visualization in Hertz, 10-120
}SNESAMP_CONFIG,*PSNESAMP_CONFIG,FAR *LPSNESAMP_CONFIG;

typedef struct
{
	TCHAR Song[33];				//Title of song
	TCHAR Game[33];				//Name of game
	TCHAR Artist[33];			//Name of artist
	TCHAR Dumper[17];			//Name of dumper
	TCHAR Date[12];				//Date dumped
	TCHAR Emu;					//Emulator used to dump
	TCHAR Comment[33];			//Optional comment
	INT	Song_ms;			//Length of song
	INT	Fade_ms;			//Length of fadeout
	BOOL bHasID666;				//Indicates whether the SPC had an ID666 tag or not
}ID666_TAG,*PID666_TAG,FAR *LPID666_TAG;

//DSP registers ---------------------------
struct DSPChn
{
	char	VolL;                              //Volume Left
	char	VolR;                              //Volume Right
	short Pitch;                             //Pitch (Rate/32000) (3.11)
	char	Wave;                              //Wave form being played back
	char	ADSR[2];                           //Envelope rates: attack, decay, and sustain
	char	Gain;                              //Envelope gain rate (if not using ADSR)
	char	EnvX;                              //Current envelope height (.7)
	char	OutX;                              //Current sample being output (-.7)
	short	__r;
};

struct DSPRAM
{
	DSPChn	Chn1;
	char		MVolL;                          //Main Volume Left (-.7)
	char		EFB;                            //Echo Feedback (-.7)
	char		__r1;
	char		FC1;                            //Filter Coefficient
	DSPChn	Chn2;
	char		MVolR;                          //Main Volume Right (-.7)
	char		__r2a;
	char		__r2;
	char		FC2;
	DSPChn	Chn3;
	char		EVolL;                          //Echo Volume Left (-.7)
	char		PMod;                           //Pitch Modulation on/off for each channel
	char		__r3;
	char		FC3;
	DSPChn	Chn4;
	char		EVolR;                          //Echo Volume Right (-.7)
	char		NOn;                            //Noise output on/off for each channel
	char		__r4;
	char		FC4;
	DSPChn	Chn5;
	char		KOn;                            //Key On for each channel
	char		EOn;                            //Echo on/off for each channel
	char		__r5;
	char		FC5;
	DSPChn	Chn6;
	char		KOff;                           //Key Off for each channel (instantiates release mode)
	char		Dir;                            //Page containing source directory (wave table offsets)
	char		__r6;
	char		FC6;
	DSPChn	Chn7;
	char		Flg;                            //DSP flags and noise frequency
	char		ESA;                            //Starting page used to store echo waveform
	char		__r7;
	char		FC7;
	DSPChn	Chn8;
	char		EndX;                           //Waveform has ended
	char		EDel;                           //Echo Delay in ms >> 4
	char		__r8;
	char		FC8;
	char		extra[128];                     //Unused
};

struct Channel
{
	//Waveform ---------18
	int	SP1;                               //Last sample decompressed (prev1)
	int	SP2;                               //Second to last sample (prev2)
	void	*BCur;                             //-> current block
	void	*BLoop;                            //-> loop start block
	char	BHdr;                              //Block Header for current block
	char	MOpt;                              //Mixing options (MixO)
	//Envelope ---------22
	char	EMode;                             //Current mode (EnvM)
	char	ERIdx;                             //Index in RateTab (0-31)
	int	ERate;                             //Rate of envelope adjustment (16.16)
	int	EDec;                              //Rate Decimal (.16)
	int	EVal;                              //Current envelope value
	int	EAdj;                              //Amount to adjust envelope height
	int	EDest;                             //Envelope Destination (16.16)
	//Mixing -----------20
	int	ChnL;                              //Channel Volume (-24.7)
	int	ChnR;                              // "  "
	int	PRate;                             //Pitch Rate after modulation (16.16)
	int	PDec;                              //Pitch Decimal (.16) (used as delta for interpolation)
	int	PDSP;                              //Pitch rate converted from the DSP (16.16)
	//Visualization ----8
	int	VMaxL;                             //Maximum absolute sample output
	int	VMaxR;
	//Samples ----------56
	short	*SIdx;                             //-> current sample in SmpRAM
	int	SOut;                              //Last sample output before chn vol (used for pitch mod)
	int	SDC;                               //DC offset correction
	short SInt[4];                           //Samples used for interpolation
	short	SRAM2[4];                          //Last 4 samples from previous block
	short	SRAM[16];                          //32 bytes for decompressed sample blocks
};

typedef struct
{
	DSPRAM DSP;				//Data for the DSP
	Channel Mix[8];			//Data for the 8 DSP channels
	int VMMaxL,VMMaxR;		//Volume values for the main left and right channels
	void *PCMBuffer;		//Pointer to the PCM sound data
	int PCMBufferLength;	//Length of the PCM sound data in bytes
	DWORD dwCount;			//Keeps count of the visualization records
}VIS_PARAMS,*PVIS_PARAMS,FAR *LPVIS_PARAMS;

BOOL WINAPI SNESAmp_Play(LPCTSTR lpszFileName);
BOOL WINAPI SNESAmp_Pause();
BOOL WINAPI SNESAmp_UnPause();
BOOL WINAPI SNESAmp_Stop();
BOOL WINAPI SNESAmp_SetConfig(LPSNESAMP_CONFIG lpCfg);
BOOL WINAPI SNESAmp_GetConfig(LPSNESAMP_CONFIG lpCfg);
BOOL WINAPI SNESAmp_GetID666Tag(LPCTSTR lpszFileName,LPID666_TAG lpTag);
BOOL WINAPI SNESAmp_SetSongLength(INT nPlayLength,INT nFadeLength);
BOOL WINAPI SNESAmp_IsPlaying();
INT WINAPI SNESAmp_GetPlayTime();
BOOL WINAPI SNESAmp_SetPlayTime(INT nPlayTime);
BOOL WINAPI SNESAmp_MuteChannels(INT nChannels);
BOOL WINAPI SNESAmp_SetMixingThreadPriority(INT nPriority);
BOOL WINAPI SNESAmp_GetVisParams(LPVIS_PARAMS lpVisParams);

#ifdef __cplusplus
}
#endif
#endif