/***************************************************************************************************
* Program:    ID666 Tag Manager
* Platform:   C++
* Programmer: Anti Resonance
*
* A class for managing the ID666 tag in an .SPC file.
* 
*                                                            Copyright (C)2000 Alpha-II Productions
***************************************************************************************************/

//**************************************************************************************************
// Public Variables

//.SPC header structure
struct SPCHdr
{
	char		FTag[33];                       //File tag
	char		Term[3];                        //Tag terminator
	char		Ver;                            //Version #/100
	struct
	{
		unsigned char	PC[2];
		unsigned char	A;
		unsigned char	X;
		unsigned char	Y;
		unsigned char	PSW;
		unsigned char	SP;
	}Regs;										//SPC Registers
	short		__r1;
	char		Song[32];                       //Song title
	char		Game[32];                       //Game title
	char		Dumper[16];                     //Name of dumper
	char		Comment[32];                    //Comments
	char		Date[11];                       //Date dumped
	char		SongLen[3];                     //Song length (number of seconds to play before fading)
	char		FadeLen[5];                     //Fade length (milliseconds)
	char		Artist[32];                     //Artist of song
	char		ChnDis;                         //Channel Disabled
	char		Emulator;                       //Emulator dumped with
	char		__r2[45];
};

class ID666
{
private:
	//***********************************************************************************************
	// Is Number a String?
	//
	// Desc:
	//    Scans a string for characters other than 0-9 and NULL
	// In:
	//    Str-> Character string to scan
	//    Len = Length of string
	// Out:
	//    True if all characters are numerals

	bool	IsString(char*, int);

	//***********************************************************************************************
	// Fix ID666 Tag
	//
	// Desc:
	//    Splits up the ID666 tag into individual components
	// In:
	//    ID6-> ID6Info structure to store
	//    SPC-> .SPC header containing ID666 tag
	// Out:
	//    nothing

	void	FixID6(SPCHdr&);

	//Format tag saved in
	bool	Bin;

public:
	ID666();
	ID666(ID666&);
	ID666(SPCHdr&);
	~ID666();

	//Overloaded assignment operators -------
	ID666	operator=(ID666&);
	ID666	operator=(SPCHdr&);

	//***********************************************************************************************
	// Create ID666 Tag for .SPC Header
	//
	// Desc:
	//    Reduces the attributes of ID666 into a writeable form for the .SPC header
	// In:
	//    -> .SPC header containing ID666 tag
	// Out:
	//    nothing

	void	ToSPC(SPCHdr&);

	//***********************************************************************************************
	// Get ID666 Tag Format
	//
	// Desc:
	//    Returns true if numbers are stored in binary format
	// In:
	//    nothing
	// Out:
	//    type of tag

	bool	IsBin();

	//Values copied from ID666 tag ----------
	char	Song[33];                          //Song title
	char	Game[33];                          //Game title
	char	Artist[33];                        //Song Artist
	char	Dumper[17];                        //.SPC dumper
	char	Date[12];                          //Date dumped
	char	Emu;                               //Emulator used to dump
	char	Comment[33];                       //Comments
	char	SongStr[4];                        //Song in seconds
	char	FadeStr[6];                        //Fade in ms

	//Length broken up for editor -----------
	char	SongMin[3];                        //Song minutes
	char	SongSec[3];                        //Song seconds
	char	FadeSec[7];                        //Fade seconds

	//Length in binary form for emulator ----
	int	Song_ms;                           //Song in ms
	int	Fade_ms;                           //Fade in ms

	bool bHasID666;
};