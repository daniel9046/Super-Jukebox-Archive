#ifndef _DSP_H_
#define _DSP_H_

/***************************************************************************************************
* Program:    SNES Digital Signal Processor Emulator
* Platform:   80386 / MMX
* Programmer: Anti Resonance
* 
* --------------------------------------------------------------------------------------------------
* Revision History:
*
* 1.4  22.05.2000 SNESAmp v1.2
*      + Added a low-pass filter
*      + Added output monitor
*      + Optimized the waveform code in EmuDSPN
*      + Added FixSeek
*      + SetDSPVol now uses a 16-bit value
*      - FixDSP was marking channels as keyed even if the pitch was 0
*      - Correctly implemented echo volume (should be perfect now)
*
* 1.1  05.04.2000 SNESAmp v1.0
*      - Channels with a pitch of 0 can't be keyed on
*      - EnvH becomes 0 when channel is keyed off
*      - EnvH is set to 0 when envelope is in gain mode
*      - Account for sample blocks with a range greater than 16-bits (BRE still not correct)
*
* 1.0  17.03.2000 SNESAmp v0.9
*                                                             Copyright (C)2000 Alpha-II Productions
***************************************************************************************************/

#include "SNESAmp.h"

//**************************************************************************************************
//Public Variables

//DSP Options ------------------------------
enum	Inter
{
	IntN=1,                                  //None
	IntL,                                    //Linear
	IntC                                     //Cubic
};

struct DOpt
{
	char	IntType:2;                         //Interpolation type:
														  // 0 - None
														  // 1 - Linear
														  // 2 - Cubic
	char	Smp8bit:1;                         //Output 8-bit samples
	char	SmpMono:1;                         //Output monaural samples
	char	OldBRE:1;                          //Use old school method for bit-rate expansion
	char	MixRout:2;                         //Mixing routine: 0-No mixing  1-Integer  2-MMX
	char	LowPass:1;                         //Enable low pass filter on output
};

//Internal mixing settings -----------------
struct MixO
{
	char	IntType:2;                         //Interpolation type (not used)
	char	__r1:2;
	bool	Mute:1;                            //Channel is muted
	bool	__r2:1;
	bool	KeyOff:1;                          //Channel is keying off
	bool	Inactive:1;                        //Channel is inactive
};

enum	EnvM {Dec,Exp,Inc,Bent=6,Release=8,Sustain,Attack,Decay=13,Direct=15};

extern "C" DSPRAM DSP;                      //1 page of DSP RAM
extern "C" Channel Mix[8];
extern "C" int VMMaxL,VMMaxR;


//*************************************************************************************************
//External Functions

//**************************************************************************************************
// Initialize DSP
//
// Desc:
//    Initializes the DSP.  Creates the derivative table for cubic spline interpolation.
// In:
//    -> 64KB of SPC RAM aligned on a 64K boundary
// Out:
//    nothing
// Destroys:
//    ST(0-7)

extern "C" void InitDSP(void*);


//**************************************************************************************************
// Reset DSP
//
// Desc:
//    Resets the DSP registers, erases internal variables, and resets the volume
// In:
//    nothing
// Out:
//    nothing
// Destroys:
//    EAX

extern "C" void ResetDSP();


//**************************************************************************************************
// Set DSP Options
//
// Desc:
//    Recalculates tables, changes the output sample rate, and sets up the mixing routine.
// In:
//    Rate = Sample Rate (8000-64000)
//    Opt  = DOpt
// Out:
//    nothing
// Destroys:
//    EAX,EDX

extern "C" void SetDSPOpt(int Rate,DOpt Opt);


//**************************************************************************************************
// Fix DSP After Loading Saved State
//
// Desc:
//    Initializes the internal mixer variables
// In:
//    nothing
// Out:
//    nothing
// Destroys:
//    EAX,EDX

extern "C" void FixDSP();


//**************************************************************************************************
// Fix DSP After Seeking
// 
// Desc:
//    Puts all DSP channels in a key off state and erases echo region.  Call after using EmuDSPN.
// In:
//    nothing
// Out:
//    nothing
// Destroys:
//    nothing

extern "C" void FixSeek();


//**************************************************************************************************
// Set DSP Pre-amplification Level
//
// Desc:
//    Sets the amplification level
// In:
//    Amp = Amplification level (0-100)
// Out:
//    nothing
// Destroys:
//    EAX,EDX

extern "C" void SetDSPAmp(int Amp);


//**************************************************************************************************
// Set DSP Volume
//
// Desc:
//    Sets the volume level for fading
// In:
//    Vol = Volume (0-65536)
// Out:
//    nothing
// Destroys:
//    EAX,EDX

extern "C" void SetDSPVol(int Vol);


//**************************************************************************************************
// DSP Data Port
//
// Desc:
//    Writes a value to a specified DSP register and alters the DSP accordingly
// In:
//    BL = DSP Address
//    BH = DSP Data
// Out:
//    nothing
// Destroys:
//    EBX

extern "C" void DSPDataIn();


//**************************************************************************************************
// Emulate DSP
//
// Desc:
//    Emulates the DSP functions of the SNES
// In:
//    Buf-> Buffer to store output
//    Smp = Number of samples to create (0-2048)
// Out:
//    -> End of buffer
// Destroys:
//    EDX

extern "C" void* EmuDSP(void *Buf,int Smp);


//**************************************************************************************************
// Emulate DSP (use MMX instructions)
//
// Desc:
//    Emulates the DSP functions of the SNES
// In:
//    Buf-> Buffer to store output
//    Smp = Number of samples to create (0-2048)
// Out:
//    -> End of buffer
// Destroys:
//    EDX,MM4-MM7

extern "C" void* EmuDSPX(void *Buf,int Smp);


//**************************************************************************************************
// Emulate DSP (no mixing)
//
// Desc:
//    Emulates the DSP functions of the SNES, except sample decompression and mixing.
//    Buffer will not be changed, and OutW will not be modified.
// In:
//    EmuPtr-> Buffer to store output
//    EmuSmp = Number of samples to create (0-2048)
// Out:
//    EAX -> End of buffer
// Destroys:
//    EDX

extern "C" void* EmuDSPN(void *Buf,int Smp);

#endif