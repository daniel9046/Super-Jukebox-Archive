/***************************************************************************************************
* SNES Sound Module Emulator
*                                                             Copyright (C)2000 Alpha-II Productions
***************************************************************************************************/

#include <stdio.h>
#include "spc700.h"
#include "dsp.h"
#include "soundmod.h"

void*	(*DSPFunc)(void *,int);               //DSP emulation function
int	CycLeft;                              //Clock cycles left to emulate
int	SmpClk;                               //Number of clock cycles per sample (16.16)
int	SmpEmu;                               //Number of samples to output
int	SmpDec;                               //Sample decimal

void* InitSPU(void *SPCRAM)
{
	int	i;

	__asm {
		mov	eax,SPCRAM                      //Align SPC RAM on a 64K boundary
		and	eax,not 0xFFFF
		add	eax,0x10000
		mov	SPCRAM,eax
	}

	InitSPC(SPCRAM);
	InitDSP(SPCRAM);

	for (i=0;i<8;i++)                        //Unmute all channels
		Mix[i].MOpt=(unsigned char)0x80;

	return(SPCRAM);
}


void ResetSPU(int Amp)
{
	ResetSPC();
	ResetDSP();

	SetDSPAmp(Amp);
	CycLeft=0;
	SmpDec=0;
}


void FixSPU(short PC,char A,char Y,char X,char PS,char S)
{
	FixSPC(PC,A,Y,X,PS,S);
	FixDSP();
}

void SetSPUOpt(int Rate, DOpt Opt)
{
	int	i;
	
	__asm {                                  //Select emulation routine
		xor	eax,eax
		mov	al,byte ptr Opt
		and	al,60h
		shr	al,5
		mov	i,eax
	}
	switch(i)
	{
	case(0):
		DSPFunc=&EmuDSPN;
		break;
	case(1):
		DSPFunc=&EmuDSP;
		break;
	default:
		DSPFunc=&EmuDSPX;
	}

	//Calculate the number of clock cycles per sample
	__asm {
		mov	edx,0x1f4                       //edx:eax = 2.048MHz << 20
//		mov	edx,0x258                       //edx:eax = 2.4576MHz << 20
		xor	eax,eax
		div	Rate
		mov	SmpClk,eax
	}

	SetDSPOpt(Rate,Opt);                     //Set options in DSP emulator
	CycLeft=0;
	SmpDec=0;
}


void ShutSPU()
{
}


void* EmuSPU(void *Buf,int Cyc)
{
	CycLeft+=Cyc;
	while (CycLeft>12)
	{
		Cyc=CycLeft;

		//Emulate SPC700
		CycLeft=EmuSPC(CycLeft);

		//Calculate number of samples to create
		__asm {
			mov	eax,Cyc
			sub	eax,CycLeft
			xor	edx,edx
			shld	edx,eax,20
			shl	eax,20
			add	eax,SmpDec
			adc	edx,0
			div	SmpClk
			mov	SmpDec,edx
			mov	SmpEmu,eax                   //SmpEmu = (CycEmu << 20) / SmpClk
		}

		//Emulate DSP
		if (SmpEmu>0) Buf=DSPFunc(Buf,SmpEmu);
	}

	return(Buf);
}