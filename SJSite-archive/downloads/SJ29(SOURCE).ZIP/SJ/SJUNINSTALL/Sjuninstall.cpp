#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <shlobj.h>
#include <stdio.h>
#include <stdlib.h>

#define szAppName "Super Jukebox Uninstall"
#define CSIDL_PROGRAM_FILES 0x26
#define SHGFP_TYPE_CURRENT 0
#define MCI_SUPPORT 1
#define PL_SUPPORT 2
#define SPC_SUPPORT 4
#define DESKTOP_SUPPORT 8
#define STARTMENU_SUPPORT 16

typedef BOOL (CALLBACK* SHGETSPECIALFOLDERPATHPROC)(HWND,LPTSTR,int,BOOL);

struct
{
	char szName[MAX_PATH];
	int iInstDir;
}InstallationFiles[]=
{
	"Super Jukebox.EXE",0,
	"UnInstall.EXE",0,
	"My Thoughts.DOC",0,
	"Super Jukebox.HLP",0,
	"SNESAmp.HTML",0,
	"SNESAmp.H",0,
	"SNESAmp.LIB",0,
	"SPC700EMU.TXT",0,
	"SPC700EMU.H",0,
	"SPC700EMU.LIB",0,
	"MCISPC.TXT",0,
	"MCISPC.H",0,
	"ZLIB.DLL",0,
	"UNRAR.DLL",0,
	"UNACE.DLL",0,
	"FFT.DLL",0,
	"SNESAmp.DLL",2,
	"SPC700EMU.DLL",2,
	"IN_SPC.DLL",2,
	"OUT_WAVE.DLL",2,
	"MCISPC.DRV",2,
	"MCISPCDLG.DLL",2,
};

void _SHGetSpecialFolderPath(HWND hwndOwner,LPTSTR lpszPath,int nFolder,BOOL fCreate)
{
	char szBuf[MAX_PATH];
	HINSTANCE hInstDll;

	switch(nFolder)
	{
	case CSIDL_DESKTOP:
		strcpy(lpszPath,"C:\\WINDOWS\\Desktop");
		break;
	case CSIDL_PROGRAM_FILES:
		strcpy(lpszPath,"C:\\Program Files");
		break;
	case CSIDL_PROGRAMS:
		strcpy(lpszPath,"C:\\WINDOWS\\Start Menu\\Programs");
		break;
	}
	hInstDll=LoadLibrary("SHELL32.DLL");
	if(hInstDll)
	{
		SHGETSPECIALFOLDERPATHPROC pSHGetSpecialFolderPath;
		pSHGetSpecialFolderPath=(SHGETSPECIALFOLDERPATHPROC)GetProcAddress(hInstDll,"SHGetSpecialFolderPathA");
		if(pSHGetSpecialFolderPath)
		{
			BOOL bRes;
			bRes=(*pSHGetSpecialFolderPath)(hwndOwner,szBuf,nFolder,fCreate);
			if(bRes==TRUE)
				strcpy(lpszPath,szBuf);
		}
		FreeLibrary(hInstDll);
	}
}

int WINAPI WinMain(HINSTANCE hInst,HINSTANCE hPrevInst,LPSTR lpCmdLine,int nShowCmd)
{
	int iTotalFiles=sizeof(InstallationFiles)/sizeof(InstallationFiles[0]);
	char szBuffer[MAX_PATH],szBuffer1[MAX_PATH],szBuffer2[MAX_PATH];
	char szInstDir[MAX_PATH],szWinDir[MAX_PATH],szSysDir[MAX_PATH];
	char szDesktopDir[MAX_PATH],szStartMenuDir[MAX_PATH];
	DWORD dwInstOptions,dwSize=sizeof(DWORD);
	HKEY hKey;

	if(MessageBox(NULL,"Are you sure you want to remove Super Jukebox?",szAppName,MB_YESNO|MB_ICONQUESTION|MB_DEFBUTTON2)==IDNO)
		return 0;
	RegOpenKeyEx(HKEY_LOCAL_MACHINE,"SOFTWARE\\Marius Fodor\\Super Jukebox",0,KEY_ALL_ACCESS,&hKey);
	RegQueryValueEx(hKey,"Installation options",NULL,NULL,(LPBYTE)&dwInstOptions,&dwSize);
	dwSize=sizeof(szInstDir);
	RegQueryValueEx(hKey,"Installation directory",NULL,NULL,(LPBYTE)szInstDir,&dwSize);
	RegCloseKey(hKey);
	GetWindowsDirectory(szWinDir,MAX_PATH);
	GetSystemDirectory(szSysDir,MAX_PATH);

	if(dwInstOptions&MCI_SUPPORT)
	{
		WritePrivateProfileString("mci","spc700emu",NULL,"system.ini");
		WritePrivateProfileString("mci extensions","spc",NULL,"win.ini");
		WritePrivateProfileString("mci extensions","sp0",NULL,"win.ini");
		WritePrivateProfileString("mci extensions","sp1",NULL,"win.ini");
		WritePrivateProfileString("mci extensions","sp2",NULL,"win.ini");
		WritePrivateProfileString("mci extensions","sp3",NULL,"win.ini");
		WritePrivateProfileString("mci extensions","sp4",NULL,"win.ini");
		WritePrivateProfileString("mci extensions","sp5",NULL,"win.ini");
		WritePrivateProfileString("mci extensions","sp6",NULL,"win.ini");
		WritePrivateProfileString("mci extensions","sp7",NULL,"win.ini");
		WritePrivateProfileString("mci extensions","sp8",NULL,"win.ini");
		WritePrivateProfileString("mci extensions","sp9",NULL,"win.ini");
		RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Marius Fodor\\MCISPC");
	}
	else iTotalFiles-=2;

	if(dwInstOptions&PL_SUPPORT)
	{
		RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Classes\\.pl");
		RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Classes\\plfile");
	}

	if(dwInstOptions&SPC_SUPPORT)
	{
		RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Classes\\.spc");
		RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Classes\\.sp0");
		RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Classes\\.sp1");
		RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Classes\\.sp2");
		RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Classes\\.sp3");
		RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Classes\\.sp4");
		RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Classes\\.sp5");
		RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Classes\\.sp6");
		RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Classes\\.sp7");
		RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Classes\\.sp8");
		RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Classes\\.sp9");
		for(int i=0;i<=9;i++)
		{
			char szBuffer[500];
			sprintf(szBuffer,"SOFTWARE\\Classes\\.sp%d",i);
			RegDeleteKey(HKEY_LOCAL_MACHINE,szBuffer);
		}
		RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Classes\\spcfile");
		RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Classes\\MIME\\Database\\Content Type\\audio/spc");
	}
	RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Marius Fodor\\Super Jukebox");
	RegDeleteKey(HKEY_LOCAL_MACHINE,"SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Uninstall\\Super Jukebox");

	if(dwInstOptions&DESKTOP_SUPPORT)
	{
		_SHGetSpecialFolderPath(NULL,szDesktopDir,CSIDL_DESKTOP,FALSE);
		sprintf(szBuffer,"%s\\Super Jukebox.lnk",szDesktopDir);
		DeleteFile(szBuffer);
	}
	if(dwInstOptions&STARTMENU_SUPPORT)
	{
		_SHGetSpecialFolderPath(NULL,szStartMenuDir,CSIDL_PROGRAMS,FALSE);
		sprintf(szBuffer1,"%s\\Super Jukebox",szStartMenuDir);
		for(int i=0;i<4;i++)
		{
			_splitpath(InstallationFiles[i].szName,NULL,NULL,szBuffer2,NULL);
			strcat(szBuffer2,".lnk");
			sprintf(szBuffer,"%s\\%s",szBuffer1,szBuffer2);
			DeleteFile(szBuffer);
		}
		RemoveDirectory(szBuffer1);
	}

	for(int i=0;i<iTotalFiles;i++)
	{
		switch(InstallationFiles[i].iInstDir)
		{
		case 0:sprintf(szBuffer,"%s\\%s",szInstDir,InstallationFiles[i].szName);break;
		case 1:sprintf(szBuffer,"%s\\%s",szWinDir,InstallationFiles[i].szName);break;
		case 2:sprintf(szBuffer,"%s\\%s",szSysDir,InstallationFiles[i].szName);break;
		}
		DeleteFile(szBuffer);
	}
	RemoveDirectory(szInstDir);

	MessageBox(NULL,"Uninstallation complete. Note, however, that Windows does not allow programs to delete themselves (commit suicide). So you will have to remove the \"UnInstall.exe\" file. Sorry it had to come to this.",szAppName,MB_ICONINFORMATION);
	return 0;
}
