#ifndef _MAIN_H_
#define _MAIN_H_

#include <windows.h>
#include <stdio.h>
#include "spc700emu.h"
#include "port.h"
#include "apu.h"
#include "spc700.h"
#include "soundux.h"

#endif