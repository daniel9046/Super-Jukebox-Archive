                                       SPC700EMU.DLL
                                      by Marius Fodor
                                  (marius.fodor@usa.net)


	This DLL for the most part is just a rip out of Citizen X's WinSPC program, but with a
few modifications/improvements by me. I used Microsoft Visual C++ 6.0 to compile it, but any
32-bit Windows compiler should do. The driver doesn't really contain much in the way of comments,
so you will have to do your best in deciphering its workings.

	For more information on how to use the DLL you can read SPC700EMU.TXT. Well, anyway,
drop me a line if you have any questions. Bye.