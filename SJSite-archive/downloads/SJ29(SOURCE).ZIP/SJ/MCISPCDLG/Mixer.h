UINT GetMixerIDForWaveMapper();
DWORD GetMixerControlID(UINT uMixerID,DWORD dwComponentType,DWORD dwControlType);
DWORD GetMixerControlValue(UINT uMixerID,DWORD dwControlID);
DWORD SetMixerControlValue(UINT uMixerID,DWORD dwControlID,DWORD dwControlValue);