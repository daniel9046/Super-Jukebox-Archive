//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by MCISPCDLG.rc
//
#define IDD_DIALOG1                     101
#define IDC_COMBO1                      1015
#define IDC_RADIO1                      1016
#define IDC_RADIO2                      1017
#define IDC_RADIO3                      1018
#define IDC_RADIO4                      1019
#define IDC_COMBO2                      1020
#define IDC_RADIO5                      1021
#define IDC_RADIO6                      1022
#define IDC_RADIO7                      1023
#define IDC_EDIT1                       1024
#define IDC_COMBO3                      1025
#define IDC_SPIN1                       1027
#define IDC_EDIT2                       1028
#define IDC_SPIN2                       1029
#define IDC_CHECK1                      1030

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        102
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
